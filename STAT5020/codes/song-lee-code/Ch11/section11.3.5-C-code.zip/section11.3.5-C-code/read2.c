         
void   read2(rp,EMU,ELD,ETHE,EGA,ETHZ,EMUZ,EPHI,
                     omga,Gomg,YY,EALP,LL,UU)

int      rp, LL[NO];
float    EMU[NI];
float    ELD[NI][MO], ETHE[NI];
float    EGA[NE][NS], ETHZ[NE];
float    EMUZ[NK], **EPHI;

float    omga[NO][MO],YY[NO][NI];
float    UU[NO][NY2][KT];
float    Gomg[NO][NS];
float    *EALP;
{
   int     i,j,k,l,id;
   long    idum;
   float   unif, PROB,Arg;
   float   AA[NI][NC0];
   float   ELDS[NI][NE+NK];
   double  wgt[NG],vv[NG];
   FILE   *fp;
   
   for (j=0;j<NI;j++) ETHE[j]=1.0;
                   
   if (REP  > 1 && REP < 4)  {
       if (rp == 1)
           fp=fopen("start1.dat","r");
       if (rp == 2)
           fp=fopen("start2.dat","r");
       if (rp == 3)
           fp=fopen("start3.dat","r");
       }
   else    fp=fopen("start2.dat","r");
  
   fscanf(fp,"%f",&Arg);          
   for (j=0;j<NI;j++) EMU[j]=Arg;
  
   for (j=0;j<NI;j++)
        for (k=0;k<NC0;k++)
             fscanf(fp,"%f",&AA[j][k]);
    
   for (j=0;j<NI;j++)
        for (k=0;k<NE+NK;k++)
             fscanf(fp,"%f",&ELDS[j][k]);
      
   fscanf(fp,"%f",&Arg);
   for (j=0;j<NY1;j++) ETHE[j]=Arg;
   
   for (j=0;j<NE;j++)
        for (k=0;k<NS;k++)
             fscanf(fp,"%f",&EGA[j][k]);

   fscanf(fp,"%f",&Arg);
   for (j=0;j<NE;j++) ETHZ[j]=Arg;
  
   for (j=1;j<=NK;j++)
        for(k=1;k<=j;k++)
   	    fscanf(fp,"%f",&EPHI[j][k]);
   for (j=0;j<NK;j++)
        fscanf(fp,"%f",&EMUZ[j]);
   fclose(fp);

   for (j=1;j<=NK;j++)
        for(k=j;k<=NK;k++)
   	   EPHI[j][k]=EPHI[k][j];
   
   for (j=0;j<NI;j++) {
        for (k=0; k<NC;k++)  ELD[j][k]= AA[j][k];
        for (k=NC;k<MO;k++)  ELD[j][k]=ELDS[j][k-NC];
        }

   /*////// Read  nonparametric suparameter/////*/

        for (i=0;i<NO;i++) LL[i]=0;
   

       *EALP=rGamma(4.0,2.0);
               
        for (k=0;k<NG-1;k++) 
             vv[k]=betadev(1.0,*EALP);
        vv[NG-1]=1.0;

        wgt[0]=vv[0];
        for (k=2;k<=NG;k++){
             wgt[k-1]=vv[k-1];
             for (j=1;j<=k-1;j++)
                  wgt[k-1]*=(1.0-vv[j-1]);
             }
        for (i=0;i<NO;i++) {
             idum=rand();  unif=ran3(&idum);
             PROB=0.00; 
             for (k=0;k<NG;k++) {
                  PROB+=wgt[k]; 
                  if (unif < PROB) { LL[i]=k+1;break;}
                  }
             }

   for (i=0;i<NO;i++)
        for (j=0;j<NE+NK;j++) omga[i][NC+j]=0.5;
   for (i=0;i<NO;i++)
        for (j=0;j<NE+NK;j++) Gomg[i][NB+j]=omga[i][NC+j];


   for (i=0;i<NO;i++)
        for (j=0;j<NY2;j++)
             for (k=0;k<KT;k++) UU[i][j][k]=0.0;  
            
   for (i=0;i<NO;i++)
        for (j=NY1;j<NI;j++)
             if ((int)YY[i][j] == 0) 
                 for (k=0;k<KT;k++) 
                       UU[i][j-NY1][k]=-200.0;
             else
                 for (k=0;k<KT;k++) 
                       UU[i][j-NY1][k]=0.00;
  /*
  fp=fopen("KKobs.dat","w");
   for (j=0;j<NO;j++) 
        fprintf(fp,"%d\n",LL[j]);
   fclose(fp);
    exit(1); */
}/* End of Program  */
