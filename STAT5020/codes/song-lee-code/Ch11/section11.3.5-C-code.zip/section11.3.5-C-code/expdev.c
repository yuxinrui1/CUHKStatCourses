/* X  exp(-x)*/

#include <math.h>

float expdev(idum)
long *idum;
{
	float ran3();
	float dum;

	do
		dum=ran3(idum);
	while (dum == 0.0);
	return -log(dum);
}
/* (C) Copr. 1986-92 Numerical Recipes Software . */
