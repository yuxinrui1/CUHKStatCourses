
void     DAT_est(IDXLD,IDXGA,EMU,ELD,ETHE,EGA,ETHZ,EPH,EALP)

int      IDXLD[NI][MO],IDXGA[NE][NS];
float    EMU[NI];
float    ELD[NI][MO], ETHE[NI];
float    EGA[NE][NS], ETHZ[NE];
float    **EPH;
float    EALP;
{
   int   j, k;
   FILE  *fp1,*fp2,*fp3;
   FILE  *fp4,*fp5,*fp6;
                 
  if (NC == 0) {
   fp1=fopen("mu_n.dat","a");
   for (j=0;j<NI;j++)
        fprintf(fp1,"%6.2f ",EMU[j]);
   fprintf(fp1,"\n");
   fclose(fp1);
   }

   if (NC != 0 ) {
   fp2=fopen("Aa_n.dat","a");
   for (k=0;k<NC;k++)
        for (j=0;j<NI;j++)
            fprintf(fp2,"%8.3f ",ELD[j][k]);
   fprintf(fp2,"\n");
   fclose(fp2);  
   }

   fp2=fopen("lbd_n.dat","a");
   for (k=NC;k<MO;k++)
        for (j=0;j<NI;j++)
             if (IDXLD[j][k] == 1 )
                 fprintf(fp2,"%8.3f ",ELD[j][k]);
   fprintf(fp2,"\n");
   fclose(fp2);  
                
   if (NY1 > 0) {
   fp3=fopen("tht_n.dat","a");
   for (j=0;j<NY1;j++)
        fprintf(fp3,"%8.3f ",ETHE[j]);
   fprintf(fp3,"\n");
   fclose(fp3);
   } 

   fp4=fopen("pi_n.dat","a");
   for (j=0;j<NE;j++)
        for (k=0;k<NS;k++)
             if (IDXGA[j][k] == 1)
                 fprintf(fp4,"%8.3f ",EGA[j][k]);
   fprintf(fp4,"\n");
   fclose(fp4);  
     
   fp5=fopen("psi_n.dat","a");
   for (j=0;j<NE;j++)
        fprintf(fp5,"%8.3f ",ETHZ[j]);
   fprintf(fp5,"\n");
   fclose(fp5);
    
   if (PRA == 1){   
   fp6=fopen("phi_n.dat","a");
   for (j=1;j<=NK;j++)
        for (k=1;k<=j;k++)
             fprintf(fp6,"%8.3f ",EPH[j][k]);
   fprintf(fp6,"\n"); 
   fclose(fp6);
   }
    
   if (PRA == 0){
   fp1=fopen("alp_n.dat","a");
   fprintf(fp1,"%8.4f ",EALP);
   fprintf(fp1,"\n"); 
   fclose(fp1);
   }
}
