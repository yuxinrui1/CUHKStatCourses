void     draw_ALP(b1,b2,bb,alp)
double   bb;
float    b1,b2;
float    *alp;
{ 
  float  a, bt;
  
  a=b1+(float)NG-1.0;   bt=1.0/(b2-bb);
  *alp=gammdev(a,bt);

}
