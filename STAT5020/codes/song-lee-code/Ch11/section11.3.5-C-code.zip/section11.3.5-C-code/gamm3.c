/*****************************************************************************
To sample Z randomyl from a gamma distribution g(a,1) with a>1,cheng and feast
1979,GKM2(a>2.5) f(a,beta)=x^{a-1}e^{-x/beta}/(gamma(a)*beta^alp)
******************************************************************************/

float gamm3(float a,float beta)
{ float x1,u1,u2,a1, b, m, f,d,v;
   long id;
   a1=a-1.0;b=(a-1.0/(6.0*a))/a1;
   m=2.0/a1;d=m+2.0;f=sqrt(a);
   do{ 
       do{ 
       id=rand();
       u1=ran3(&id);
       id=rand();
       u2=ran3(&id);
       x1=u2+(1.0-1.857764*u1)/f;
       }while(x1<=0||x1>=1); 
      v=b*u2/x1;
       if (m*x1-d+v+1.0/v<=0) break;
       if (m*log(x1)-log(v)+v-1.0<=0) break;
    }while(1);
  return a1*v*beta;
}
      
