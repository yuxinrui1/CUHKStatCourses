/*///////////////////////////////////////////////////
//f(a,beta)=x^{a-1}e^{-x/beta}/(gamma(a)*beta^alp) //
///////////////////////////////////////////////////*/

#include   "gamm1.c"
#include   "gamm2.c"
#include   "gamm3.c"
#include   "expdev.c"

float  gammdev(float a, float beta)

{
         float  rnd;
         long   number;

         if ( a > 0 && a < 1 )
              rnd=gamm1(a,beta);
         else if (a==1)
                 { number=rand();
                   rnd=expdev(&number)*beta;
                 }
         else if (a > 1 && a <= 2.5)
                   rnd=gamm2(a,beta);
         else 
                   rnd=gamm3(a,beta);

  return (rnd);
}
