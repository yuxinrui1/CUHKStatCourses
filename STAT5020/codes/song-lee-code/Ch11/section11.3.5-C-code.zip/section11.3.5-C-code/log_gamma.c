float  log_gamma(alp,beta,y)
float  alp, beta;
float  y;
{
   float lg;
   lg=alp*log(beta)+(alp-1.0)*log(y)-beta*y-gammln(alp);
   return lg;
}
