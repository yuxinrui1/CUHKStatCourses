#define  PP0  -0.322232431088
#define  PP1  -1.0
#define  PP2  -0.342242088547
#define  PP3  -.204231210245E-1
#define  PP4  -.453642210148E-4   
#define  DD0   .993484626060E-1
#define  DD1   .588581570495
#define  DD2   .531103462366
#define  DD3   .103537752850
#define  DD4   .38560700634E-2
#define  ZERO  0.0
#define  ONE   1.0
#define  HALF  0.5
#define  ALIMIT 1.0E-20
   
double  gauinv(p)
double  p;    
{
  double c,ps,yi;
   ps = p;
   if (ps >= HALF)   ps=ONE-ps;
   if (ps < ALIMIT)  ps=ALIMIT;
   yi = sqrt(log(ONE/(ps*ps)));
   c= yi+((((yi*PP4+PP3)*yi+PP2)*yi+PP1)*yi+PP0)/((((yi*DD4
             +DD3)*yi+DD2)*yi+DD1)*yi+DD0);
   if (p <= HALF ) c=-c;
     
   #undef PP0 
   #undef PP1  
   #undef PP2 
   #undef PP3  
   #undef PP4     
   #undef DD0  
   #undef DD1  
   #undef DD2  
   #undef DD3  
   #undef DD4  
   #undef ZERO 
   #undef ONE 
   #undef HALF 
   #undef ALIMIT 
   return (c);
}
