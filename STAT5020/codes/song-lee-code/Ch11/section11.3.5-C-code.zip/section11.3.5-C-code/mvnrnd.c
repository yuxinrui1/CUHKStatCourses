    /*//////////////////////////////////////////////////////////////////
    //      This subrountine is used to generate n-dimension          //
    //      multivariable normal distribution N(mu, cov), mu is       //
    //      the mean before the program begins, then mu is the random //
    //      number after the program ends                             //
    //////////////////////////////////////////////////////////////////*/


void   mvnrnd(nn,mu,cov,xx)
int     nn;
float   mu[],**cov,xx[];
{
    int      i, j;
    long     number;
    float    **piry;
    float    xx1[nn];
    float    xx2[nn];

    piry=matrix(1,nn,1,nn);

    for (i=0; i<nn; i++) {
         number=rand();
         xx1[i]=gasdev(&number);  
         }

        /* xx is the standard normal 
        distribution's random number */
 
     choldc(cov,nn,piry); 

     for (i=0; i<nn; i++)  {
          xx2[i]=0; 
          for (j=0; j<nn; j++)
               xx2[i]+=piry[i+1][j+1]*xx1[j];
          }

     for (i=0; i<nn; i++)
          xx[i]=mu[i]+xx2[i];

     free_matrix(piry,1,nn,1,nn);
}/*End Of the Programm. Jun.2003.*/ 
      
   
  
