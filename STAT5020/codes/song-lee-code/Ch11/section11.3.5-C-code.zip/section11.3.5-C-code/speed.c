void   speed(np,IDXLD,IDXGA,EMU,ELD,ETHE,EGA,ETHZ,EPHI,EST)

int      np;
int      IDXLD[NI][MO], IDXGA[NE][NS];
 
float    EMU[NI];
float    ELD[NI][MO],  ETHE[NI];
float    EGA[NE][NS],  ETHZ[NE];
float    **EPHI;
float    EST[NP];
{
  int   j,k, id=0;

  for (j=0;j<np;j++) EST[j]=0.0;

  if (NC == 0)
       for (j=0;j<NI;j++){
            EST[id]=EMU[j]; id++;}
      
  for (k=0;k<MO;k++)
       for (j=0;j<NI;j++)
            if (IDXLD[j][k] == 1) {
                EST[id]=ELD[j][k]; id++;}
           
  if ( NY1 > 0 )          
  for (j=0;j<NY1;j++) {
       EST[id]=ETHE[j]; id++;}
         
  for (j=0;j<NE;j++)
       for (k=0;k<NS;k++)
            if (IDXGA[j][k]==1) {
                EST[id]=EGA[j][k]; id++;}      

  for (j=0;j<NE;j++) {
       EST[id]=ETHZ[j]; id++;}

  if(PRA == 1)
  for (j=1;j<=NK;j++)
       for (k=j;k<=NK;k++){
            EST[id]=EPHI[j][k]; id++;}      

  if (id != np) {
      printf("%d  %d\n",id,np); 
      nrerror("dimen of Para is wrong!"); 
      }
}
