void    draw_omg(EMU,ELD,ETHEv,EGA,ETHZ,EMUZ,EPHI,YY,omga,Gomg)

float    EMU[NI];
float    ELD[NI][MO], ETHEv[NI];
float    EGA[NE][NS], ETHZ[NE];
float    EMUZ[NK],**EPHI;

float     YY[NO][NI];
float     omga[NO][MO],Gomg[NO][NS];
{
  int      i, j, k, l;
  void     cov_str();
  float    Ys[NO][NI];
  float    Regx[NW][NI];
  float    Regz[NW][NW]; 
  float    mean[NW], temp;
  float    ave[NW],zz[NW];
  float    PBE[NE][NB],muu[NI];
  float    **B0, **B0v,**Omg;

  B0  =matrix(1,NE,1,NE);
  B0v =matrix(1,NE,1,NE);
  Omg =matrix(1,NW,1,NW);

  for (j=1;j<=NE;j++) {
       for (k=1;k<=NE;k++) B0[j][k]=-EGA[j-1][NB+k-1];
       B0[j][j]+=1.0; }
  inv(B0,NE,B0v);
  cov_str(ELD,ETHEv,EGA,ETHZ,EPHI,B0v,Regx,Regz,Omg);
  /*///////////////////////////////////////////*/                      
  for (j=0;j<NE;j++)
       for (k=0;k<NB;k++){PBE[j][k]=0.0;
            for (l=0;l<NE;l++)
                 PBE[j][k]+=B0v[j+1][l+1]*EGA[l][k];
            }
                
  for (i=0; i<NO; i++) {

       for (j=0;j<NW;j++) { mean[j]=0.0;
            for (k=0; k<NI; k++) {  
                 temp=0.00;
                 for (l=0;l<NC;l++) 
                      temp+=ELD[k][l]*omga[i][l];
                 mean[j]+=Regx[j][k]*(YY[i][k]-EMU[k]-temp);
                 } 
            }
       for (j=0;j<NW;j++) ave[j]=0.0; 
       for (j=0;j<NE;j++){ave[j]=0.0; 
            for (k=0;k<NB;k++)
                 ave[j]+=PBE[j][k]*Gomg[i][k];
            }    
       for (j=0;j<NW;j++)
            for (k=0;k<NW;k++)
                 mean[j]+=Regz[j][k]*ave[k];
       mvnrnd(NW,mean,Omg,zz);
       for (j=0;j<NW;j++)
            omga[i][NC+j]=zz[j];
       for (j=0;j<NW;j++)
            Gomg[i][NB+j]=zz[j];
       }
  free_matrix(B0, 1,NE,1,NE);
  free_matrix(B0v,1,NE,1,NE);
  free_matrix(Omg,1,NW,1,NW);
} 

void   cov_str(lbd,Thtv,pi,Psi,Phi,B0v,Regx,Regz,Omg)

float   lbd[NI][MO],Thtv[NI]; 
float   pi[NE][NS],Psi[NE];
float   **Phi, **B0v;
float   Regx[][NI], Regz[][NW];
float   **Omg;
{
   int    j,k,l,m;
   float  SAD[NE][NE];
   float  **Omgv, **Cov, **Var;

   Cov =matrix(1,NW,1,NW);
   Var =matrix(1,NW,1,NW);
   Omgv=matrix(1,NW,1,NW);

   for (j=0;j<NE;j++)
        for (k=0;k<NE;k++) {SAD[j][k]=0.0;
             for (l=0;l<NK;l++)
                  for (m=0;m<NK;m++)
                       SAD[j][k]+=pi[j][NB+NE+l]*Phi[l+1][m+1]
                                 *pi[k][NB+NE+m];
            }
  for (j=0;j<NE;j++)
       SAD[j][j]+=Psi[j];
  /*/////////////////////////////////////////////*/
  for (j=1;j<=NW;j++)
       for (k=1;k<=NW;k++) Cov[j][k]=0.0;
                        
  for (j=1;j<=NE;j++)
       for (k=1;k<=NE;k++) { Cov[j][k]=0.0;
            for (l=1;l<=NE;l++)
                 for (m=1;m<=NE;m++)
                      Cov[j][k]+=B0v[j][l]*SAD[l-1][m-1]*B0v[k][m];
            }
  for (j=1;j<=NE;j++)
       for (k=1;k<=NK;k++) { Cov[j][NE+k]=0.0;
            for (l=1;l<=NE;l++)
                 for (m=1;m<=NK;m++)
                      Cov[j][NE+k]+=B0v[j][l]*pi[l-1][NB+NE+m-1]
                                   *Phi[m][k];
            }
  for (j=1;j<=NK;j++)
       for (k=1;k<=NE;k++) Cov[NE+j][k]=Cov[k][NE+j];
  for (j=1;j<=NK;j++)
       for (k=1;k<=NK;k++)
            Cov[NE+j][NE+k]=Phi[j][k];
  inv(Cov,NW,Var);
  /*///////////////////////////////*/
                 
  for (j=0;j<NW;j++)
       for (k=0;k<NW;k++) { Omgv[j+1][k+1]=0.0;
            for (l=0;l<NI;l++)
                 Omgv[j+1][k+1]+=lbd[l][NC+j]*lbd[l][NC+k]*Thtv[l];
            }
   for (j=1;j<=NW;j++)
       for (k=1;k<=NW;k++) Omgv[j][k]+=Var[j][k];
  inv(Omgv,NW,Omg);
  /*/////////////////////////////////////*/
  for (j=0;j<NW;j++)
       for (k=0;k<NI;k++) { Regx[j][k]=0.0;
            for (l=0;l<NW;l++)
       Regx[j][k]+=Omg[j+1][l+1]*lbd[k][NC+l]*Thtv[k];
            }
  for (j=0;j<NW;j++)
       for (k=0;k<NW;k++) { Regz[j][k]=0.0;
            for (l=0;l<NW;l++)
                 Regz[j][k]+=Omg[j+1][l+1]*Var[l+1][k+1];
            }
  /*///////////////////////////////////////////////////*/
  free_matrix(Cov, 1,NW,1,NW);
  free_matrix(Var, 1,NW,1,NW);
  free_matrix(Omgv,1,NW,1,NW);
} /* End of Programm  */
