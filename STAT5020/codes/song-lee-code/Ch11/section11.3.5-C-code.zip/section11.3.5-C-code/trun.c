        /*_____________this program will simulate observation from 
          normal N(mu,sig) truncated at al (left) ar(right)_______*/

#include  "gauinv.c"

double trun(mu,sig,ind,al,ar)
int    ind;
float  mu, sig; 
float  al, ar;
{ 
  double tem; 
  double trun_l();
  double trun_r();
  double trun_0();

   if ( ind == 0)       tem=trun_0(mu,sig,al,ar);
   else if ( ind == 1 ) tem=trun_r(mu,sig,ar);    /* <=ar, truncate at right */
   else                 tem=trun_l(mu,sig,al);    /* >=al  truncate at left  */
   return (tem);
}

double PHI(x)
float  x;
{
  double b;
  b=0.5*(1.0+erf(x/sqrt(2.0)));
  return(b);
}

	/*_____ this program will simulate observation from
         normal N(mu,sig) truncated at a (left) ( > a )_____ */
                            
double trun_l(mu,sig,a)
float mu, sig;
float  a;
{ 
  double tem,c; 
  long d;

  d=rand();  tem=ran3(&d);
  c=mu+sqrt(sig)*gauinv(tem*PHI((a-mu)/sqrt(sig))+(1.0-tem));
  return (c);
}

          /*______ this program will simulate observation from  
           normal N(mu,sig) truncated at al (left) and ar (right)___ */
    
double trun_0(mu,sig,al,ar)
float mu, sig;
float  al, ar;
{ 
  double tem,c,a1,b1;
  long d;
  
  d=rand(); tem=ran3(&d);
  a1=PHI((al-mu)/sqrt(sig));
  b1=PHI((ar-mu)/sqrt(sig));
  c=mu+sqrt(sig)*gauinv(tem*a1+(1.0-tem)*b1);
  
  return (c);
}

		/*___________ this program will simulate observation from
		  normal N(mu,sig) truncated at b(right)( < b )__________*/
                         
double trun_r(mu,sig,b)
float  mu, sig;
float  b;
{ 
  double tem,c;
  long d;

  d=rand(); tem=ran3(&d);
  c=mu+sqrt(sig)*gauinv((1.0-tem)*PHI((b-mu)/sqrt(sig)));

  return (c);
}
