void    draw_MUU(mu0,SGM0v,omega,YY,lbd,Thtv,mu)

float   mu0[NI], **SGM0v;
float   YY[NO][NI];
float   omega[NO][MO];
float   lbd[NI][MO],Thtv[NI];
float   mu[NI];
{
      int    i, j, k;
      float  mean0[NI], mean1[NI];
      float  mean[NI], mbar[NI], ybar[NI];
      float  **Cov,**Var;
      float  abar[NK];
         
      Var =matrix(1,NI,1,NI);   
      Cov =matrix(1,NI,1,NI);   
                  
      for (j=1;j<=NI;j++) { 
       	   for (k=1;k<=NI;k++) Var[j][k]=SGM0v[j][k];
           Var[j][j]+=(float)NO*Thtv[j-1];
           }
      inv(Var,NI,Cov);
      /*//////////////////////////////////////////*/
         
      for (j=0;j<NI;j++) { ybar[j]=0.0;
           for (i=0;i<NO;i++)  
                ybar[j]+=YY[i][j];
           }

      for (j=0;j<NI;j++) { mbar[j]=0.0;
           for (k=0;k<MO;k++)
                for (i=0;i<NO;i++)  
                     mbar[j]+=lbd[j][k]*omega[i][k];
                }
      /*      
      for (j=0;j<NK;j++) { abar[j]=0.0;
           for (i=0;i<NO;i++)  
                abar[j]+=omega[i][NC+NE+j];
           }
      for (j=0;j<NK;j++) abar[j]=0.0;

      for (j=0;j<NI;j++) { mbar[j]=0.0;
           for (k=0;k<NC+NE;k++)
                for (i=0;i<NO;i++)  
                     mbar[j]+=lbd[j][k]*omega[i][k];
           for (k=0;k<NK;k++)
                for (i=0;i<NO;i++)  
                     mbar[j]+=lbd[j][NC+NE+k]*(omega[i][NC+NE+k]-abar[k]);
           }
       */ 
      /*/////////////////////////////////////////////*/
      for (j=0;j<NI;j++) { mean0[j]=0.0;
       	   for (k=0;k<NI;k++)
                mean0[j]+=SGM0v[j+1][k+1]*mu0[k];
           }
      for (j=0;j<NI;j++) 
            mean1[j]=Thtv[j]*(ybar[j]-mbar[j]);
         
      /*////////////////////  Draw mu ////////////////*/
      for (j=0;j<NI;j++) { mean[j]=0.0;
           for (k=0;k<NI;k++)
                mean[j]+=Cov[j+1][k+1]*(mean0[k]+mean1[k]);
           }
      mvnrnd(NI,mean,Cov,mu);
   /*//////////////////////*/
   free_matrix(Cov,1,NI,1,NI);   
   free_matrix(Var,1,NI,1,NI);   
}/*/////////////////////////*/
