
void   read1(idx_lbd,idx_pi,mu,lbd,Tht,pi,Psi,muz,Phi)

int    idx_lbd[NI][MO], idx_pi[NE][NS];
float  mu[NI];
float  lbd[NI][MO],Tht[NI];
float  pi[NE][NS], Psi[NE];
float  muz[NK], **Phi;
{
  int   j,k;
  FILE  *fp; 
  
  fp=fopen("idicat.dat","r");
  for (j=0;j<NI;j++)
       for (k=0;k<MO;k++)
            fscanf(fp,"%d",&idx_lbd[j][k]);
  for (j=0;j<NE;j++)
       for (k=0;k<NS;k++)
            fscanf(fp,"%d",&idx_pi[j][k]);
  fclose(fp);
  /*///////////////////////////////////////*/
  fp=fopen("true.dat","r");
     for (j=0;j<NI;j++)
          fscanf(fp,"%f",&mu[j]);

     for (j=0;j<NI;j++)
          for (k=0;k<MO;k++)
               fscanf(fp,"%f",&lbd[j][k]);                 
     for (j=0;j<NI;j++)
          fscanf(fp,"%f",&Tht[j]);
                   
     for (j=0;j<NE;j++)
          for (k=0;k<NS;k++)
               fscanf(fp,"%f",&pi[j][k]);                 
     for (j=0;j<NE;j++)
          fscanf(fp,"%f",&Psi[j]);
                           
     for (j=1;j<=NK;j++)
          for (k=1;k<=NK;k++)
               fscanf(fp,"%f",&Phi[j][k]);
     for (j=0;j<NK;j++)
          fscanf(fp,"%f",&muz[j]);
  fclose(fp);
}/*/////////////////////////////*/
