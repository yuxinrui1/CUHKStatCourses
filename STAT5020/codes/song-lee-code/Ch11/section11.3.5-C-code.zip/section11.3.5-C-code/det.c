float     det(nn,A)

int       nn;
float     **A;

{

  int    j, k, *indx;
  float  **a, d;

  indx=ivector(1,nn);
  a=matrix(1,nn,1,nn);

  for (j=1; j<=nn; j++)
       for (k=1; k<=nn; k++)
            a[j][k]=A[j][k];

  ludcmp(a,nn,indx,&d);
  for (j=1; j<=nn; j++)
       d*=a[j][j];
  free_ivector(indx,1,nn);
  free_matrix(a,1,nn,1,nn);
  
  return (d);
}

