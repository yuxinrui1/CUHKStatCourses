# include "math.h"

float onetn(as)
    float as;
{

float aa, rz, zz, uu, vv;
long idum;
int flag=0;

if(as>=0.0)
   while(flag==0)
     { 
     aa=0.5*as+0.5*sqrt(as*as+4.0);
     idum=rand();
     zz=expdev(&idum)/aa+as;
     rz=-(zz-aa)*(zz-aa)/2.0;
     uu=rand()/(RAND_MAX+1.0);
     if(uu<=0.0) vv=uu;
     else  vv=log(uu);
     if(vv<=rz)  flag=1;
     }
     else 
       while(flag==0) 
          {
           idum=rand();
           zz=gasdev(&idum);
           if(zz>as) flag=1;
          }

  return(zz); 
}
