void    draw_MSS(IYY,EMU,ELD,ETHE,omga,YY)

int     IYY[NO][NI];
float   EMU[NI];
float   ELD[NI][MO], ETHE[NI];
float   omga[NO][MO];
float   YY[NO][NI];
{
  int    i, j, k;
  long   idum;
  float  temp;
              
  for (i=0;i<NO;i++)
       for (j=0;j<NY1;j++)
            if (IYY[i][j] == 1) { temp=0.00;
                for (k=0;k<MO;k++)
                     temp+=ELD[j][k]*omga[i][k];
                idum=rand();
                YY[i][j]=temp+gasdev(&idum)*sqrt(ETHE[j]);
                }
}/*/////// End of Programm //////////*/
