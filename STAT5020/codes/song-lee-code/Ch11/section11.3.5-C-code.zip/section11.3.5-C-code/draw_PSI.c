void   draw_PSI(IDXGA,pi0,G0,alp1,bta1,omga,Gomg,EGA,ETHZ)

int     IDXGA[NE][NS];

float   omga[NO][MO];
float   Gomg[NO][NS];

float   pi0[NE][NS], G0[NS][NS];
float   alp1[NE], bta1[NE];

float   EGA[NE][NS], ETHZ[NE];
{ 
   int     i,j,k,l,m,s,t;
   int     cord,dim[NE];
   float   cc[NS],F[NS][NS];
   float   pi_str[NS];
   float   eta[NO],GG[NS][NS];
   float   temp,alf,bt;
   float   aa0,aa1,aa2;
   float   mean[NS], mean1[NS];
   float   star0[NS],mean0[NS];
   float   **AA,**AAv,**VAR;
   float   **HH0,**H0v;
        
   HH0=matrix(1,NS,1,NS);
   H0v=matrix(1,NS,1,NS);
   AA =matrix(1,NS,1,NS);
   AAv=matrix(1,NS,1,NS);
   VAR=matrix(1,NS,1,NS);
   
   /*///////////////////////////*/
   for (j=0;j<NE;j++) dim[j]=0;
   for (j=0;j<NE;j++)
        for (k=0;k<NS;k++)
             dim[j]+=IDXGA[j][k];
   for (l=0;l<NS;l++)
        for (m=0;m<NS;m++) {GG[l][m]=0.0;
             for (i=0;i<NO;i++)
                  GG[l][m]+=Gomg[i][l]*Gomg[i][m];
             }
   /*//////////////////////////////////////////*/
   for (k=0;k<NE;k++)
        if (dim[k] !=  0) {  
                   
            for (l=0;l<NS;l++)
                 for (m=0;m<NS;m++) F[l][m]=0.0;
            cord=0;
            for (j=0;j<NS;j++)
                 if (IDXGA[k][j] == 1) {
                     F[cord][j]=1;cord++;}

            for (l=0;l<dim[k];l++)
                 for (m=0;m<dim[k];m++){ AAv[l+1][m+1]=0.0;
                      for (s=0;s<NS;s++)
                            for (t=0;t<NS;t++) 
                                 AAv[l+1][m+1]+=F[l][s]*GG[s][t]*F[m][t];
                      }
            for (l=0;l<dim[k];l++)
                 for (m=0;m<dim[k];m++){ HH0[l+1][m+1]=0.0;
                      for (s=0;s<NS;s++)
                            for (t=0;t<NS;t++) 
                                 HH0[l+1][m+1]+=F[l][s]*G0[s][t]*F[m][t];
                      }
            for (j=0;j<dim[k];j++){ star0[j]=0.0;
                 for (l=0;l<NS;l++)
                      star0[j]+=F[j][l]*pi0[k][l];
                 }
            inv(HH0,dim[k],H0v);
            for (l=1;l<=dim[k];l++)
                 for (m=1;m<=dim[k];m++) AAv[l][m]+=H0v[l][m];
            inv(AAv,dim[k],AA);               
            for (j=0;j<NS;j++)
                 if (IDXGA[k][j] == 1) cc[j]=0.0;
                 else                  cc[j]=EGA[k][j]; 
            for (i=0;i<NO;i++) {temp=0.0;
                 for (j=0;j<NS;j++)
                      temp+=cc[j]*Gomg[i][j];
                 eta[i]=Gomg[i][NB+k]-temp;
                 }
            for (l=0;l<dim[k];l++) { mean0[l]=0.0;
                 for (m=0;m<dim[k];m++)
                      mean0[l]+=H0v[l+1][m+1]*star0[m];
                 }
            for (l=0;l<dim[k];l++) { mean1[l]=0.0;
                 for (m=0;m<NS;m++)
                      for (i=0;i<NO;i++)
                           mean1[l]+=F[l][m]*Gomg[i][m]*eta[i];
                 }
            for (l=0;l<dim[k];l++) { mean[l]=0.0;
                 for (m=0;m<dim[k];m++)
                      mean[l]+=AA[l+1][m+1]*(mean0[m]+mean1[m]);
                 }
            /*////////////////////////////////////////////////*/
            aa0=0.0;                         
            for (l=0;l<dim[k];l++)
                 for (m=0;m<dim[k];m++)
                      aa0+=star0[l]*H0v[l+1][m+1]*star0[m];
            aa1=0.0;
            for (i=0;i<NO;i++) aa1+=eta[i]*eta[i];
            aa2=0.0;
            for (l=0;l<dim[k];l++)
                 for (m=0;m<dim[k];m++)
                      aa2+=mean[l]*AAv[l+1][m+1]*mean[m];
            /*/////////////////////////////////////////*/
            alf=0.5*NO+alp1[k];
            bt=1.0/(bta1[k]+0.5*(aa0+aa1-aa2));
            ETHZ[k]=1.0/gammdev(alf,bt);
            /*////////////////////////////////////////*/
            for (l=1;l<=dim[k];l++)
                 for (m=1;m<=dim[k];m++)
                      VAR[l][m]=AA[l][m]*ETHZ[k];
            mvnrnd(dim[k],mean,VAR,pi_str);
                            
            for (j=0;j<NS;j++) { EGA[k][j]=0.0;
                 for (l=0;l<dim[k];l++)
                      EGA[k][j]+=F[l][j]*pi_str[l];
                 EGA[k][j]+=cc[j];
                 }
           }
      else {
            for (i=0;i<NO;i++) { temp=0.0;
                 for (j=0;j<NS;j++)
                      temp+=EGA[k][j]*Gomg[i][j];
                 eta[i]=Gomg[i][NB+k]-temp;
                 }
            aa1=0.0;
            for (i=0;i<NO;i++) aa1+=eta[i]*eta[i];
            alf=0.5*NO+alp1[k];  
            bt=1.0/(0.5*aa1+bta1[k]);
            ETHZ[k]=1.0/gammdev(alf,bt);
            }

 free_matrix(HH0,1,NS,1,NS);
 free_matrix(H0v,1,NS,1,NS);
 free_matrix(AA, 1,NS,1,NS);
 free_matrix(AAv,1,NS,1,NS);
 free_matrix(VAR,1,NS,1,NS);
}
