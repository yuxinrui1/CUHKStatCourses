#define    IDX   2   /* IDX==1 COD1   IDX2==COD2 */ 
#define    MS    1   /* 1 == MISS    0 == NOMSS  */

#define    NO0   766
#define    NO    353  /*
#define    NO    411  */

#define    NG    50

#define    NI0   16
#define    NC0   2
#define    NB0   2


#define    NI    13
#define    NY1   7
#define    NY2  (NI-NY1)

#define    NC    2
#define    NB    2
#define    KT    2

#define    NE    1
#define    NK    4
#define    NF    NK

#define    NW   (NE+NK)
#define    MO   (NC+NE+NK)
#define    NS   (NB+NE+NF)

#define    NP    45

#define    REP   1
      
#define    MCAX  20000
#define    GNUM  10000

#define    ITER   10000
