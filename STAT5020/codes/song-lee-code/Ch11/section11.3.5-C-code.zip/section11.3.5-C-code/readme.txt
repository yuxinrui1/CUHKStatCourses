 A: The estimation program is given in   main.c
    

 B:  PARA denote the fitting procedure:

          PRA == 1  parametric mode ( normal)  
          PRA == 0  semparametric mode 
 
  
 C:  BLOKED GIBBS SAMPLER given in GIBBS.c
    
 
 D: Headfile  is given in  def_sm.h; 

    REP  ---- No. of replication
    MCAX ---- No. of iteration in BG.
    GNUM --- -burn-in of iteration in BG.

    NO  --- size  of sample
    NI  --- dim   of  y
    NY1 --- dim of contin. var. in y. 
    NY2 --- dim of categorical var. in y. 

    KT  --- dim of latent vector corresponding to categorical var.  
    NP  --- dim  of total para.

    NK  ----dim  of xi
    NE  ----dim  of eta
    MO  ----dim  of (x, eta, xi)=omga   : x is covariate of meas. eq.
    NS  ----dim  of (z, eta, F(xi))=Gomg: z is covariate of stru. eq.
 
    NG  --- truncated level in Ishwaran and James procedure    
    NNG --- truncated level in modified Ishwaran and James procedure    
 
