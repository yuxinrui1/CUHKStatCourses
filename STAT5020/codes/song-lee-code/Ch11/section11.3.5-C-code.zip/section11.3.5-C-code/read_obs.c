void   read_obs(IDXLD,IDXGA,YSD,CVX,CVZ,IYY)

int    IDXLD[NI][MO], IDXGA[NE][NS];
int    IYY[NO][NI];
float  YSD[NO][NI];
float  CVX[NO][NC+1];
float  CVZ[NO][NB+1];
{
  int    i,j,k, num[NI];
  int    IDXLDs[NI][NW];

  float  code[NO0];
  float  OXs[NO0][NC0];
  float  OZs[NO0][NB0];
  float  OYs[NO0][NI0];

  float  Ys[NO][NI];
  float  YY[NO][NI];
     
  float  Xs[NO][NC0];
  float  Zs[NO][NB0];

  float  cvxbar[NC0+1],cvxss[NC0+1];
  float  cvzbar[NB0+1],cvzss[NB0+1];

  float  ybar[NI],yss[NI];
  int    cunt0,cunt1,cunt2;
  float  temp;
  FILE  *fp; 
  
  fp=fopen("idicat.dat","r");  
  for (j=0;j<NI;j++)
       for (k=0;k<NE+NK;k++)
            fscanf(fp,"%d",&IDXLDs[j][k]);
  for (j=0;j<NE;j++)
       for (k=0;k<NS;k++)
            fscanf(fp,"%d",&IDXGA[j][k]);
  fclose(fp);

  for (j=0;j<NI;j++) {
       for (k=0; k<NC;k++) IDXLD[j][k]=1;
       for (k=NC;k<MO;k++) IDXLD[j][k]=IDXLDs[j][k-NC];
       }
  fp=fopen("cod.txt","r");
  for (i=0;i<NO0;i++)
       fscanf(fp,"%f",&code[i]);
   fclose(fp);

   /*____________read  Yobs________*/
   fp=fopen("realdata.txt","r");
   for (i=0;i<NO0;i++)
        for (j=0;j<NI0;j++)
             fscanf(fp,"%f",&OYs[i][j]);
   fclose(fp);
   
   fp=fopen("AD.txt","r");
   for (i=0;i<NO0;i++)
        for (j=0;j<NC0;j++)
             fscanf(fp,"%f",&OXs[i][j]);
   fclose(fp);
   
   fp=fopen("BD.txt","r");
   for (i=0;i<NO0;i++)
        for (j=0;j<NB0;j++)
             fscanf(fp,"%f",&OZs[i][j]);
   fclose(fp);
   /*//// choose Group Code 2 ////////*/
   /*
   cunt0=0;
   for (i=0;i<NO0;i++) 
        if ( (int)code[i] == IDX ) {
              for (j=0;j<NY1;j++)
                   Ys[cunt0][j]=OYs[i][j];
              for (j=NY1;j<NI;j++)
                   Ys[cunt0][j]=OYs[i][j+3];
                      
              for (j=0;j<NC0;j++)
                   Xs[cunt0][j]=OXs[i][j];
              for (j=0;j<NB0;j++)
                   Zs[cunt0][j]=OZs[i][j];
              cunt0++;
              }
   */
   cunt0=0;
   for (i=0;i<NO0;i++) 
        if ( (int)code[i]== IDX )
             if( (int)OYs[i][13] != 1 && (int)OYs[i][15] != 1 ){
                  for (j=0;j<NY1;j++)
                       Ys[cunt0][j]=OYs[i][j];
                  for (j=NY1;j<NI;j++)
                       Ys[cunt0][j]=OYs[i][j+3];
                  for (j=0;j<NC0;j++)
                       Xs[cunt0][j]=OXs[i][j];
                  for (j=0;j<NB0;j++)
                       Zs[cunt0][j]=OZs[i][j];
                  cunt0++;
                  }
      
   /*/////////////Missing case ////////*/          
   
   for (i=0;i<NO;i++)
        for (j=0;j<NI;j++)
             if (Ys[i][j] == 9999.0) 
                     IYY[i][j]=1;
             else    IYY[i][j]=0;
    
   /*///////////ln ACR, lnPcR, lnTG/////*/
   for (i=0;i<NO;i++)
        for (j=0;j<NY1;j++)
             if ( j==0 || j==1 || j == 4 )
                  if ( Ys[i][j] == 9999.0)
                       YY[i][j]=Ys[i][j];
                  else YY[i][j]=log(Ys[i][j]);
             else      YY[i][j]=Ys[i][j];
   for (i=0;i<NO;i++)
        for (j=NY1;j<NI;j++)
             YY[i][j]=Ys[i][j];

   /*/////// Transform to multinomial variable /////*/
            
   for (i=0;i<NO;i++)
        for (j=NY1;j<NI;j++)
             if (Ys[i][j] == 9999.0)
                   YY[i][j]=Ys[i][j];
             else  YY[i][j]=Ys[i][j]+1;

   /*///////////// standardized variables /////////*/              
   for (j=0;j<NC0;j++) { 
        cvxbar[j]=0.00;
        for (i=0;i<NO;i++)
             cvxbar[j]+=Xs[i][j]/(NO*1.0);
        }
   for (j=0;j<NC0;j++) {
        cvxss[j]=0.00;
        for (i=0;i<NO;i++)
             cvxss[j]+=SQR(Xs[i][j]-cvxbar[j])/(NO-1.0);
        }
   for (i=0;i<NO;i++)
        for (j=0;j<NC+1;j++) CVX[i][j]=0.00;
   for (i=0;i<NO;i++)
        for (j=0;j<NC;j++)
             CVX[i][j]=(Xs[i][j]-cvxbar[j])/sqrt(cvxss[j]);
             
   for (j=0;j<NB0;j++) { 
        cvzbar[j]=0.00;
        for (i=0;i<NO;i++)
             cvzbar[j]+=Zs[i][j]/(NO*1.0);
        }
   for (j=0;j<NB0;j++) {
        cvzss[j]=0.00;
        for (i=0;i<NO;i++)
             cvzss[j]+=SQR(Zs[i][j]-cvzbar[j])/(NO-1.0);
        }
   for (i=0;i<NO;i++)
        for (j=0;j<NB+1;j++) CVZ[i][j]=0.00;
   for (i=0;i<NO;i++)
        for (j=0;j<NB;j++)
              CVZ[i][j]=(Zs[i][j]-cvzbar[j])/sqrt(cvzss[j]);
    /*
   for (i=0;i<NO;i++)
        for (j=0;j<NC;j++)
             CVX[i][j]=Xs[i][j];
   for (i=0;i<NO;i++)
        for (j=0;j<NB;j++)
             CVZ[i][j]=Zs[i][j];
   */
   /*__________Standardized Continous DATA______*/
  
   for (j=0;j<NY1;j++) { num[j]=0;
        for (i=0;i<NO;i++)
             if (IYY[i][j] == 0 ) num[j]++;
        }
   for (j=0;j<NY1;j++) {
        ybar[j]=0.0;
        for (i=0;i<NO;i++)
             if (IYY[i][j] == 0)
                ybar[j]+=YY[i][j]/(num[j]*1.0);
        }
   for (j=0;j<NY1;j++) {
        yss[j]=0.0;
        for (i=0;i<NO;i++)
             if (IYY[i][j] == 0)
                 yss[j]+=SQR(YY[i][j]-ybar[j])/(num[j]-1.0);
        }
   for (i=0;i<NO;i++)
        for (j=0;j<NY1;j++)
             if (IYY[i][j] == 0)
                 YSD[i][j]=(YY[i][j]-ybar[j])/sqrt(yss[j]);
             else  
                 YSD[i][j]=YY[i][j];
                          
   for (i=0;i<NO;i++)
        for (j=NY1;j<NI;j++)
             YSD[i][j]=YY[i][j];
    
   /*/// Exchange YY[13], YY[14]///////*/
    
   for (i=0;i<NO;i++) {
        temp=YSD[i][10]; YSD[i][10]=YSD[i][11];
        YSD[i][11]=temp; }
      
  /*//////////////////////////////////////////////*/ 
  /*
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y1.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][0] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][0]);
  fclose(fp);
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y2.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][1] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][1]);
  fclose(fp);

  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y3.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][2] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][2]);
  fclose(fp);
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y4.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][3] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][3]);
  fclose(fp);

  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y5.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][4] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][4]);
  fclose(fp);

  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y6.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][5] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][5]);
  fclose(fp);
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y7.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][6] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][6]);
  fclose(fp);
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y8.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][7] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][7]);
  fclose(fp);
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y9.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][8] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][8]);
  fclose(fp);
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/Y10.dat","w");
     for (i=0;i<NO;i++)
          if (IYY[i][9] == 0) 
     fprintf(fp,"%8.4f\n",YSD[i][9]);
  fclose(fp);
  fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/MUL.dat","w");
    fprintf(fp,"y:    %6.1d   %6.1d  %6.1d\n",0,1,2);
  fclose(fp);
                  
  for (j=NY1;j<NI;j++) {
       cunt0=0; cunt1=0; cunt2=0; 
       for (i=0;i<NO;i++) {
            if ((int)YSD[i][j] == 0) cunt0++;
            if ((int)YSD[i][j] == 1) cunt1++;
            if ((int)YSD[i][j] == 2) cunt2++;
            } 
      fp=fopen("/data2/student/ym_xia/xym/NW_MUL/EXAM/ORIGDAT/MUL.dat","a");
      fprintf(fp,"[%d]:  %6.1d   %6.1d  %6.1d\n",j,cunt0,cunt1,cunt2);
      fclose(fp);
      }
  exit(1);
  */ 
}/*//////////////////////////*/
