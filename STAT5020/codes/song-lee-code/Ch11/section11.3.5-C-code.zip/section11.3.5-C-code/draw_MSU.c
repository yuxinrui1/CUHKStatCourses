                      /*///////////  draw  V ////////////*/
#include   "trun.c"
#include   "onetn.c"
#include   "trunom.c"

void    draw_MSU(IYY,EMU,ELD,omga,YY,UU,YYs)
            
int     IYY[NO][NI];
float   EMU[NI];
float   ELD[NI][MO];
float   omga[NO][MO],YY[NO][NI];
float   YYs[NO][NI];
float   UU[NO][NY2][KT];
{
   int    i,j,k,l,m,z;
   long   idum;
   float  max_arr();
   float  incp,arg;
   float  vv[KT],al;

   for (i=0;i<NO;i++) 
        for (j=NY1;j<NI-2;j++){
                  
             incp=0.00;
             for (l=0;l<MO;l++)
                  incp+=ELD[j][l]*omga[i][l];
                
             if (IYY[i][j] == 1) {
                 for (l=0;l<KT;l++){ idum=rand();
                      UU[i][j-NY1][l]=incp+gasdev(&idum);} 
                 }                    
             else{ z=(int)YY[i][j];
                   if (z  !=  0 ) { 
                       for (l=0;l<KT;l++) 
                            if (l+1 == z) {
                                for (m=0;m<KT;m++) 
                                     vv[m]=UU[i][j-NY1][m];
                                vv[z-1]=-1.0e4;
                                arg=max_arr(KT,vv);
                                al=(arg > 0.0 ? arg : 0.0);
                                al+=-incp;
                                UU[i][j-NY1][l]=trunom(al,200.0)+incp;
                                }
                           else{arg=UU[i][j-NY1][z-1];
                                al=(arg > 0.0 ? arg : 0.0);
                                al+=-incp;
                                UU[i][j-NY1][l]=trunom(-200.0,al)+incp;
                                }
                       }
                  else {
                         for (l=0;l<KT;l++) { al=-incp;   
                              UU[i][j-NY1][l]=trunom(-200.0,al)+incp;
                              }
                       }
                  }
             }  
                
   for (i=0;i<NO;i++) 
        for (j=NI-2;j<NI;j++)  { 
                             
             incp=0.00;
             for (l=0;l<MO;l++)
                  incp+=ELD[j][l]*omga[i][l];
                                      
             if (IYY[i][j] == 1) {
                 idum=rand();
                 UU[i][j-NY1][0]=incp+gasdev(&idum);
                 }    
               
             if (IYY[i][j] == 0) {
                   
                 z=(int)YY[i][j];  al=-incp; 
                 if ( z > 0 )
                      UU[i][j-NY1][0]=trunom(al,100.0)+incp;
                 else 
                      UU[i][j-NY1][0]=trunom(-100.0,al)+incp;
                 }
             }       
                   
   for (i=0;i<NO;i++)
        for (j=0;j<NY1;j++)  YYs[i][j]=YY[i][j];
    
   for (i=0;i<NO;i++) {
        for (j=NY1;j<NI-2;j++) { 
             incp=0.00;
             for (l=0;l<KT;l++)
                  incp+=UU[i][j-NY1][l];
             YYs[i][j]=incp/(KT*1.0);
             }
        YYs[i][NI-2]=UU[i][NY2-2][0];  
        YYs[i][NI-1]=UU[i][NY2-1][0];  
        }
        
}  /* Copyrights (C). by Song, X. Y. (2005) */ 

float  max_arr(p,y)
int    p;
float  y[p];
{
    int    t=0;
    float  maxarg;
    if (p == 0)  nrerror("dimension of vec is zero");
    else { maxarg=y[0];
           while(t < p-1) {
                 if (y[t+1] > maxarg) maxarg=y[t+1];
                 t++;
                 }
           return (maxarg);  
         }
} /*//// End of Program //////*/
