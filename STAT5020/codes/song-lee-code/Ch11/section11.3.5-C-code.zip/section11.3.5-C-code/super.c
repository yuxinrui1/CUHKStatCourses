void  super(mu0,SGM0v,lbd0,H0,alp0,bta0,
            pi0,G0,alp1,bta1,rho0,R0v,
            sgm0,a1,a2,b1,b2)

float  mu0[NI],**SGM0v;
float  lbd0[NI][MO],H0[MO][MO];
float  pi0[NE][NS], G0[NS][NS];
float  alp0[NI], bta0[NI];
float  alp1[NE], bta1[NE];
float  *sgm0, *b1,*b2;
float  a1[NK],a2[NK];
float  **R0v,*rho0;
{
   int    i,j,k,l;
   float  arg1, arg2;
   float  Tht[NI], Psi[NE];
   float  Aa0[NC0],lbds[NI][NW];
   FILE   *fp;
           
   for (j=1;j<=NI;j++) {
      	for (k=1;k<=NI;k++) SGM0v[j][k]=0.0;
             SGM0v[j][j]+=1.0;}
               
   for (j=0;j<NI;j++) Tht[j]=1.0;
                             
   fp=fopen("hiarch.dat","r");
      
      for (j=0;j<NI;j++)
	   fscanf(fp,"%f",&mu0[j]);
          
      for (j=0;j<NC0;j++)
	   fscanf(fp,"%f",&Aa0[j]);
                
      for (j=0;j<NI;j++)
	   for (k=0;k<NE+NK;k++)
	        fscanf(fp,"%f",&lbds[j][k]);
            
      for (j=0;j<NY1;j++)  
	   fscanf(fp,"%f",&Tht[j]);
             
      for (j=0;j<NE;j++)
	   for (k=0;k<NS;k++)
	        fscanf(fp,"%f",&pi0[j][k]);
      for (j=0;j<NE;j++)  
	   fscanf(fp,"%f",&Psi[j]);
              
      fscanf(fp,"%f",rho0);
      for (j=1;j<=NK;j++) 
	   for (k=1;k<=j;k++)
 	        fscanf(fp,"%f",&R0v[j][k]);
      for (j=1;j<=NK;j++) 
	   for (k=j;k<=NK;k++)
 	        R0v[j][k]=R0v[k][j];

      fscanf(fp,"%f  %f",b1,b2);
      fscanf(fp,"%f",sgm0);         
      fscanf(fp,"%f  %f",&arg1,&arg2);
      for (j=0;j<NK;j++) {
           a1[j]=arg1; a2[j]=arg2;}
    fclose(fp);

    for (j=0;j<NI;j++) 
	 for (k=0;k<NC;k++) lbd0[j][k]=Aa0[k];
    for (j=0;j<NI;j++) 
	 for (k=NC;k<MO;k++)lbd0[j][k]=lbds[j][k-NC];

    for (j=0;j<NI;j++)  { alp0[j]=20.0;
         bta0[j]=(alp0[j]-1.0)*Tht[j];
         }
      
    for (j=0;j<NE;j++)  { alp1[j]=20.0;
         bta1[j]=(alp1[j]-1.0)*Psi[j];
         }   

    for (k=0;k<MO;k++) {
	 for (l=0;l<MO;l++) H0[k][l]=0.0;
	 H0[k][k]+=1.0;}
                       
    for (k=0;k<NS;k++) {
	 for (l=0;l<NS;l++) G0[k][l]=0.0;
         G0[k][k]+=1.0;}
                       
    for (j=1;j<=NK;j++) 
	 for (k=1;k<=NK;k++)
	      R0v[j][k]*=(*rho0-NK-1.0);
} /*End of subroutine */

