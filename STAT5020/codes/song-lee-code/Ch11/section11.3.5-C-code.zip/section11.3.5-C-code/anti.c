void     anti(np,IDXLD,IDXGA,EMU,ELD,ETHE,EGA,ETHZ,EPH,EST,STD)

int      np;
int      IDXLD[NI][MO],IDXGA[NE][NS];
 
float    EMU[NI];
float    ELD[NI][MO], ETHE[NI];
float    EGA[NE][NS], ETHZ[NE];
float    **EPH;
float    EST[NP],STD[NP];
{
  int   j,k, id=0;
  FILE  *fp;

  for (k=0;k<MO;k++)
       for (j=0;j<NI;j++)
            if (IDXLD[j][k] == 1) {
                ELD[j][k]=EST[id]; id++;}

  if ( NY1 > 0 )          
  for (j=0;j<NY1;j++) {
       ETHE[j]=EST[id]; id++;}
         
  for (j=0;j<NE;j++)
       for (k=0;k<NS;k++)
            if (IDXGA[j][k]==1) {
                EGA[j][k]=EST[id]; id++;}      

  for (j=0;j<NE;j++) {
       ETHZ[j]=EST[id]; id++;}

  if(PRA == 1)
  for (j=1;j<=NK;j++)
       for (k=j;k<=NK;k++){
            EPH[j][k]=EST[id]; id++;} 

  if (id != np) {
      printf("%d\n",id); 
      nrerror("dimen of Para is wrong!"); 
      }

   fp=fopen("SUMMARY.dat","w");
   id=0;
   for (j=0;j<NI;j++) {
        for (k=0;k<NC;k++){
            fprintf(fp,"%6.3f (%4.3f)    ",ELD[j][k],STD[id]); id++;}
        fprintf(fp,"\n");
        }
   fprintf(fp,"\n");

   for (j=0;j<NI;j++) {
        for (k=NC;k<MO;k++)
             fprintf(fp,"%6.3f  ",ELD[j][k]);
        fprintf(fp,"\n");
        }
   fprintf(fp,"\n");


   for (j=0;j<NY1;j++) {
        fprintf(fp,"%6.3f (%4.3f)",ETHE[j],STD[id]); id++;}
   fprintf(fp,"\n");
   fprintf(fp,"\n");

   for (j=0;j<NE;j++) {
        for (k=0;k<NS;k++) 
             fprintf(fp,"%4.3f  ",EGA[j][k]);
        fprintf(fp,"\n");
        }
   fprintf(fp,"\n");

   for (j=0;j<NE;j++) {
        fprintf(fp,"%6.3f(%4.3f)  ",ETHZ[j],STD[id]); id++;}
   fprintf(fp,"\n");
   fprintf(fp,"\n");

   if (PRA == 1){
   for (j=1;j<=NK;j++) {
        for (k=1;k<=j;k++) {
             fprintf(fp,"%6.3f(%4.3f)  ",EPH[j][k],STD[id]); id++;}
        fprintf(fp,"\n");
        }
   }
  fclose(fp);

}
