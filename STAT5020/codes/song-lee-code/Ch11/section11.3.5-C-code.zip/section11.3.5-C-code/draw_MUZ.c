void    draw_MUZ(sgm0,a1,a2,ZZ,EMUZ,EPH)
float   ZZ[NG][NK];
float   sgm0,a1[NK],a2[NK];
float   EMUZ[NK], **EPH;
{
   int    i, j, k, l;
   long   idum;
   float  cov[NK], mean[NK];
   float  alf, bt, temp;
         
   for (j=0;j<NK;j++) 
        cov[j]=(sgm0*EPH[j+1][j+1])/(sgm0*NG+EPH[j+1][j+1]);              
         
   for (j=0;j<NK;j++) { mean[j]=0.0;
        for (k=0;k<NG;k++)
             mean[j]+=cov[j]*ZZ[k][j]/EPH[j+1][j+1];}
   for (j=0;j<NK;j++) { idum=rand();
        EMUZ[j]=mean[j]+sqrt(cov[j])*gasdev(&idum);}
       
   for (j=0;j<NK;j++) {
        alf=a1[j]+0.5*(float)NG;
        temp=0.00;
        for (k=0;k<NG;k++)
             temp+=SQR(ZZ[k][j]-EMUZ[j]);
        bt=1.0/(a2[j]+0.5*temp);
        EPH[j+1][j+1]=1.0/gammdev(alf,bt);
        }
}/*//// End of Programm ///*/
