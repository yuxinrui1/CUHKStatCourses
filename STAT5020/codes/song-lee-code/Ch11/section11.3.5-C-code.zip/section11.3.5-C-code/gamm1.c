/*****************************************************************************
 propose generate random sample from gamma(a,1), where 0<a<=1) GS , Ahrens and
Dieter 1974  f(a,beta)=x^{a-1}e^{-x/beta}/(gamma(a)*beta^alp)
******************************************************************************/
/*#include "ran3.c"*/
#define e   2.7182818
float gamm1(float a,float beta)
{ float b,x,y,u1,u2, w,z;
  long d;
  b=(a+e)/e;
  do{   d=rand();
        u1=ran3(&d);
        d=rand();
        u2=ran3(&d);
        y=b*u1;
        if(y<=1){ z=pow(y,1.0/a);
                  if(u2<=exp(-z)) break;}
                   
         else{ z=-log((b-y)/a);
               if(z<=pow(u2,1.0/(a-1.0))) break;}
      }while(1);
    return(z*beta);
}       
#undef e
