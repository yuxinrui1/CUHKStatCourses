#include  "draw_MSS.c"
#include  "draw_MSU.c"
#include  "draw_MUU.c"
#include  "draw_LBD.c"
#include  "draw_PSI.c"

#include  "draw_ETA.c"
#include  "draw_ZWL.c"
#include  "draw_MUZ.c"
#include  "draw_ALP.c"

#include  "draw_omg.c"
#include  "draw_PHI.c"

void   Lv(np,rp,IYY,IDXLD,IDXGA,omga,Gomg,YY,UU,
             mu0,SGM0v,lbd0,H0,alp0,bta0,
             pi0,G0,alp1,bta1,R0v,rho0,
             sgm0,a1,a2,b1,b2,EALP,LL,
             EMU,ELD,ETHE,EGA,ETHZ,EMUZ,EPH,Lq)
             
int     np,rp,IYY[NO][NI],LL[NO];
int     IDXLD[NI][MO], IDXGA[NE][NS];

float   mu0[NI], **SGM0v;
float   lbd0[NI][MO],H0[MO][MO];
float   pi0[NE][NS], G0[NS][NS];
float   alp0[NI], bta0[NI];
float   alp1[NE], bta1[NE];
float   **R0v, rho0;
float   sgm0,a1[NK],a2[NK],b1,b2;

float   YY[NO][NI];
float   omga[NO][MO], Gomg[NO][NS];
float   UU[NO][NY2+1][KT];

float   EALP;
float   EMU[NI];
float   ELD[NI][MO], ETHE[NI];
float   EGA[NE][NS], ETHZ[NE];
float   EMUZ[NK], **EPH;
float  *Lq;
{   
    int     i,j,k,t,l, GIB;
    float   YUs[NO][NI];
    float   ETHEv[NI];
    double  wgt[NG], bb;
    float   ave[NO][NI], muu[NI];
    float   dia[NO][NI], cov[NI];
    float   mss,trs, rss;
    
    void    Lmeas();
    
    float   ZZ[NG][NK];
    FILE   *fp;

    for (j=0;j<NI-2;j++) ETHEv[j]=1.0/ETHE[j];
    ETHEv[NI-2]=1.0;  ETHEv[NI-1]=1.0;

    for (i=0;i<NO;i++)
         for (j=0;j<NI;j++) YUs[i][j]=0.0;
    for (i=0;i<NG;i++) wgt[i]=0.0;
    for (i=0;i<NG;i++)
         for (j=0;j<NK;j++) ZZ[i][j]=0.0;
           
    for (i=0;i<NO;i++) 
         for (j=0;j<NI;j++) {
              ave[i][j]=0.00; dia[i][j]=0.00;}

    for (GIB=1; GIB<=MCAX; GIB++) {

         draw_MSS(IYY,EMU,ELD,ETHE,omga,YY);
         draw_MSU(IYY,EMU,ELD,omga,YY,UU,YUs);
         draw_LBD(IDXLD,lbd0,H0,alp0,bta0,
                         omga,YUs,EMU,ELD,ETHE,ETHEv);
         if (NC == 0)
         draw_MUU(mu0,SGM0v,omga,YUs,ELD,ETHEv,EMU);
         draw_PSI(IDXGA,pi0,G0,alp1,bta1,
                               omga,Gomg,EGA,ETHZ);
         /*///////////// NONPARA BAY ////////////*/

         if (PRA == 0) {
             draw_ETA(EMU,ELD,ETHEv,EGA,ETHZ,EPH,YUs,omga,Gomg);
             draw_ZWL(EALP,EMU,ELD,ETHEv,EGA,ETHZ,EMUZ,EPH,
                      omga,Gomg,YUs,UU,wgt,&bb,ZZ,LL);
             draw_MUZ(sgm0,a1,a2,ZZ,EMUZ,EPH);
             draw_ALP(b1,b2,bb,&EALP);
             }
            /*///////////////PARA BAY/////////////*/ 
          if (PRA == 1 ) {
              draw_omg(EMU,ELD,ETHEv,EGA,ETHZ,EMUZ,EPH,YUs,omga,Gomg);
              draw_PHI(rho0,R0v,omga,EPH);
              }
          if (GIB > GNUM) {
                      
                for (i=0;i<NO;i++) { 
                            
                     for (j=0;j<NI;j++) muu[j]=0.00; 
                     for (j=0;j<NI;j++) cov[j]=0.00;
                           
                     Lmeas(IYY[i],EMU,ELD,ETHE,omga[i],muu,cov);
                     for (j=0;j<NI;j++)
                          ave[i][j]+=muu[j]/((MCAX-GNUM)*1.0); 
                     for (j=0;j<NI;j++)
                          dia[i][j]+=cov[j]/((MCAX-GNUM)*1.0); 
                     }
	        }
            }

   *Lq=0.00;
    for (i=0;i<NO;i++) {
         mss=0.00;
         for (j=0;j<NI;j++)
              if (IYY[i][j] == 0) 
                  mss+=SQR(ave[i][j]);
         trs=0.00;
         for (j=0;j<NI;j++)
              if (IYY[i][j] == 0) 
                  trs+=dia[i][j];
         rss=0.00;
         for (j=0;j<NI;j++)
              if (IYY[i][j] == 0)
                  rss+=SQR(YY[i][j]-ave[i][j]);
        *Lq+=trs-mss+0.5*rss;
         } 
            
} /*////// End Of Programm //////*/

void    Lmeas(IYY,EMU,ELD,ETHE,omga,muu,cov)

int     IYY[NI];
float   EMU[NI];
float   omga[MO];
float   ELD[NI][MO],ETHE[NI];
float   muu[NI],cov[NI];
{
   int    j,k,l;
   float  aa, temp, prob;
   float  mean[NI];

   for (k=0;k<NI;k++) { mean[k]=0.0;
        for (l=0;l<MO;l++)
             mean[k]+=ELD[k][l]*omga[l];
        }       
   for (k=0;k<NY1;k++)
        if (IYY[k] == 0 ){
            muu[k]=mean[k];
            cov[k]=ETHE[k]+mean[k]*mean[k];
            }
   for (k=NY1;k<NI-2;k++) 
        if (IYY[k] == 0) {
             aa=1.0-PHI(mean[k]);
             prob=(1.0-exp(KT*log(aa)))/(KT*1.0);
             muu[k]=KT*(KT+1.0)*prob*0.5;
             temp=0.0; 
             for (l=1;l<=KT;l++) 
                  temp+=(float)(l*l);
             cov[k]=temp*prob; 
             }
            
   for (k=NI-2;k<NI;k++)           
        if (IYY[k] == 0) {
             muu[k]=PHI(mean[k]);
             cov[k]=PHI(mean[k]);
             }  
}
