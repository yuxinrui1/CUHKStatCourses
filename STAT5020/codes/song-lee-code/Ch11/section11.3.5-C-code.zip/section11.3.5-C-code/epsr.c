void  epsr(re,np,nl)
int re,np, nl;
{
    int    i,j,k,l,m,n;
    float  ***seq;
    float  B, W, mean, var;
    float  ave[re], RR[np][nl-1];
                      
    FILE  *fp;

    seq=f3tensor(1,re,1,nl,1,np);

    fp=fopen("Est_n.dat","r");
    for (j=1; j<=re; j++)  
         for (k=1; k<=nl; k++) 
              for (l=1; l<=np; l++)
                   fscanf(fp,"%f",&seq[j][k][l]);
    fclose(fp);
              
    for (l=1; l<=np; l++) {
         for (k=0; k<nl-1; k++)
              RR[l-1][k]=0.00;
         n=2;
         do  {
              mean=0.00;               
              for (j=1; j<=re; j++) {
                   ave[j-1]=0.00;
                   for (m=1; m<=n; m++) {
                        ave[j-1]+=seq[j][m][l]/n;
                        mean+=seq[j][m][l]/(n*re);
                        }
                   } 
              B=0.00;   
              for (j=1; j<=re; j++) 
                   B+=n*SQR(ave[j-1]-mean)/(re-1);
              W=0.00; 
              for (j=1; j<=re; j++) 
                   for (m=1; m<=n; m++)
                        W+=SQR(seq[j][m][l]-ave[j-1])/((n-1)*re); 
              var=(B+W*(n-1))/n; 
              RR[l-1][n-2]=sqrt(var/W);
              n++;
             }while (n <= nl);            
         }
         fp=fopen("EPSR.dat","w");
         for (j=0; j<np; j++) {
              for (k=0; k<nl-1; k++)
                   fprintf(fp,"%8.4f ",RR[j][k]);
              fprintf(fp,"\n");
              }
         fclose(fp); 
 free_f3tensor(seq,1,re,1,nl,1,np);
} /* End of Programm */

