      /*////////////////////////////////////////
      // Modified Choleshy decompose Rountine //
      ////////////////////////////////////////*/

void    choldc(A,n,L)
float   **A, **L;
int n;
{
    int   i, j, k;
    float sum;
    float **a;
    float p[n];

    a=matrix(1,n,1,n);

        for (i=1;i<=n;i++)  
             for (j=1;j<=n;j++) a[i][j]=A[i][j];

	for (i=1;i<=n;i++)  
             for (j=i;j<=n;j++)  {
                  for (sum=a[i][j], k=i-1; k>=1; k--) 
                       sum-= a[i][k]*a[j][k];
	          if (i == j)  { 
                      if (sum <= 0.0) {
                          printf("choldc failed\n");
                          break;
	    	     	  }
                      p[i]=sqrt(sum);
	  	      } 
                  else a[j][i]=sum/p[i];
	   	  }

        for (i=1;i<=n;i++) {
             for (j=1;j<=n;j++)
                  if (i < j)  a[i][j]=0;
             a[i][i]=p[i];
             }

        for (i=1;i<=n;i++)
             for (j=1;j<=n;j++) L[i][j]=a[i][j];

 free_matrix(a,1,n,1,n);
}
/* (C) Copr. 1986-92 Numerical Recipes Software . */
