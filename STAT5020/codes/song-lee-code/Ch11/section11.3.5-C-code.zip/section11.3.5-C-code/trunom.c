float trunom(as, bl)
float as, bl;
{
  float  rz, zz, uu, vv;
  int flag=0; 

  if(as>bl){  
     printf("as=%14f, bl=%14f\n", as, bl);
     nrerror("Error: as>bl\n");  }
  if(bl>=8)  
   while(flag==0)
      {
       zz=onetn(as); 
       if(zz<= bl){ 
          flag=1;  return(zz);  }
      }
if(as<=-8) 
   while(flag==0)
      {
       zz=-1.0*onetn(-1.0*bl); 
       if(zz>as){ 
          flag=1;  return(zz);  }
      }
         
if(as>-8 && bl<8.0)
  while(flag==0)
   {
   zz=as+(bl-as)*rand()/(RAND_MAX+1.0);
   if(bl<0.0)
     rz=(bl*bl-zz*zz)/2.0;
   else
     if(as>0.0)  rz=(as*as-zz*zz)/2.0;
       else   rz=-zz*zz/2.0;
   uu=rand()/(RAND_MAX+1.0);
   if(uu<=0.0)  vv=0.0;
     else   vv=log(uu);
   if(vv<=rz){  
        flag=1;
        return(zz);
      }
   }  
   
 }/* end */
