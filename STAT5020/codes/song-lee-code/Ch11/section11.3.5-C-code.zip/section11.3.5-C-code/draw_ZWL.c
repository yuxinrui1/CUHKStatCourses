          /*//   Draw (W,Z) under linear structure ///*/

#include  "sort.c"

void     draw_ZWL(EALP,EMU,ELD,ETHEv,EGA,ETHZ,EMUZ,EPH,
                  omga,Gomg,YY,UU,wgt,bb,ZZ,LL)
int      LL[NO];
float    EALP;
float    EMU[NI];
float    ELD[NI][MO],ETHEv[NI];
float    EGA[NE][NS], ETHZ[NE];
float    EMUZ[NK], **EPH;

float    omga[NO][MO],Gomg[NO][NS];
float    YY[NO][NI];
float    UU[NO][NY2][KT];
double   wgt[NG], *bb;
float    ZZ[NG][NK];
{
   int     i,j,k,l,m,t;
   long    idum;
   void    order();
   int     num[NG], Ls[NG];
   int     UNIQ, DIM;

   float    an,bn;
   double   vv[NG];
                   
   float   muu[NI], nwz[NK];
   float   ave0[NK],ave1[NK];
   float   Omg[NK][NK], mean[NK]; 
   float   AR[NK][NI],AQ[NK][NE];
   float   sum, temp;
   double  dis1, dis2, dis3;
             
   float   Ys[NO][NI],ETs[NO][NE];
   float   gys[NI], geta[NE];
                  
   double  prop[NG],aa[NG];
   float   unif;         
   float   **Cov, **ivCov;
   float   **ivPH;
           
   Cov  =matrix(1,NK,1,NK); 
   ivCov=matrix(1,NK,1,NK);
   ivPH =matrix(1,NK,1,NK);

   /*//////  Update  weights ///////*/
         
   for (k=0;k<NG;k++) { num[k]=0;
        for (i=0;i<NO;i++)
             if (LL[i]==k+1)  num[k]++;}
   /*
   for (k=1;k<=NG-1;k++) {
        bn[k-1]=EALP;
        for (j=k+1;j<=NG;j++)
             bn[k-1]+=num[j-1];
        an[k-1]=1.0+num[k-1]; 
        }                
   for (k=0;k<NG-1;k++) vv[k]=betadev(an[k],bn[k]);
   vv[NG-1]=1.0;

   wgt[0]=vv[0]; 
   for (k=2;k<=NG;k++) { wgt[k-1]=vv[k-1];
        for (j=1;j<=k-1;j++) wgt[k-1]*=(1.0-vv[j-1]);
        }
   */

   for (k=0;k<NG-1;k++) {
        bn=EALP;
        for (j=k+1;j<NG;j++)
             bn+=num[j];
        an=1.0+num[k]; 
        vv[k]=betadev(an,bn);
        }
   vv[NG-1]=1.0;
   
   wgt[0]=vv[0]; 
   for (k=1;k<=NG-1;k++) { 
        wgt[k]=vv[k];
        for (j=0;j<=k-1;j++) 
             wgt[k]*=(1.0-vv[j]);
        }
  *bb=log(wgt[NG-1]);
          
   /*//////////////////////////////////////////////*/
                /*  Updata ZZ_K */
   /*//////////////////////////////////////////////*/
    
   for (j=0;j<NK;j++)
        for (k=0;k<NK;k++) { Omg[j][k]=0.00;
             for (l=0;l<NI;l++)
                  Omg[j][k]+=ELD[l][NC+NE+j]*ELD[l][NC+NE+k]*ETHEv[l];
             for (l=0;l<NE;l++)
                  Omg[j][k]+=EGA[l][NB+NE+j]*EGA[l][NB+NE+k]/ETHZ[l];
             } 
         
   for (j=0;j<NK;j++) {
        for (k=0;k<NI;k++) 
             AR[j][k]=ELD[k][NC+NE+j]*ETHEv[k];
        for (k=0;k<NE;k++) 
             AQ[j][k]=EGA[k][NB+NE+j]/ETHZ[k];
        }
   for (j=0;j<NK;j++) 
        ave0[j]=EMUZ[j]/EPH[j+1][j+1];
             
   /*/////////////////////////////////////*/                    
   for (j=0;j<NG;j++) { Ls[j]=0; num[j]=0;}
   order(LL,NO,Ls,num,&DIM);
                     
   for (UNIQ=0; UNIQ<DIM; UNIQ++) { t=Ls[UNIQ]-1;
                
        for (l=1;l<=NK;l++)
             for (m=1;m<=NK;m++) 
                  ivCov[l][m]=num[UNIQ]*Omg[l-1][m-1];
        for (l=1;l<=NK;l++)
             ivCov[l][l]+=1.0/EPH[l][l];
        inv(ivCov,NK,Cov);
                     
        for (l=0;l<NI;l++) { gys[l]=0.0;
             for (i=0;i<NO;i++)
                  if (LL[i] == Ls[UNIQ]) {
                      temp=0.00;
                      for (k=0;k<NC+NE;k++)
                           temp+=ELD[l][k]*omga[i][k];
                      gys[l]+=YY[i][l]-temp;
                      }
             }        
        for (l=0;l<NE;l++) { geta[l]=0.0;
             for (i=0;i<NO;i++)
                  if (LL[i] == Ls[UNIQ]) {
                      temp=0.00;
                      for (m=0;m<NB+NE;m++)
                           temp+=EGA[l][m]*Gomg[i][m];
                      geta[l]+=Gomg[i][NB+l]-temp;
                      } 
             }        
        for (l=0;l<NK;l++) { ave1[l]=0.0; 
             for (m=0;m<NI;m++)
                  ave1[l]+=AR[l][m]*gys[m];    
             for (m=0;m<NE;m++)
                  ave1[l]+=AQ[l][m]*geta[m];    
             }
        for (l=0;l<NK;l++) { 
             mean[l]=0.0;
             for (m=0;m<NK;m++)
                  mean[l]+=Cov[l+1][m+1]*(ave0[m]+ave1[m]); 
             }
        mvnrnd(NK,mean,Cov,ZZ[t]);
        }
    /*////////////Update ZZ_[K] /////////*/       
          
    k=0;
    for (j=0;j<NG;j++) 
         if (j+1 == Ls[k]) k++;
         else{ for (l=0;l<NK;l++) {idum=rand();
                    ZZ[j][l]=EMUZ[l]+sqrt(EPH[l+1][l+1])
                             *gasdev(&idum);} 
             }
   /*////////////////// Draw LL //////////////////*/
               
   for (i=0;i<NO;i++) { sum=0.0;
        for (j=0;j<NG;j++) { 
                     
             dis1=0.00; 
             for (l=0;l<NY1;l++) {
                  temp=0.00; 
                  for (m=0;m<NC+NE;m++)
                       temp+=ELD[l][m]*omga[i][m];
                  for (m=0;m<NK;m++)
                       temp+=ELD[l][NC+NE+m]*ZZ[j][m];
                  dis1+=SQR(YY[i][l]-temp)*ETHEv[l]; 
                  }
             dis2=0.00;  
             for (l=NY1;l<NI-2;l++) {
                  temp=0.00; 
                  for (m=0;m<NC+NE;m++)
                       temp+=ELD[l][m]*omga[i][m];
                  for (m=0;m<NK;m++)
                       temp+=ELD[l][NC+NE+m]*ZZ[j][m];
                  for (m=0;m<KT;m++)
                       dis2+=SQR(UU[i][l-NY1][m]-temp);
                  }
             for (l=NI-2;l<NI;l++) {
                  temp=0.00; 
                  for (m=0;m<NC+NE;m++)
                       temp+=ELD[l][m]*omga[i][m];
                  for (m=0;m<NK;m++)
                       temp+=ELD[l][NC+NE+m]*ZZ[j][m];
                  dis2+=SQR(UU[i][l-NY1][0]-temp);
                  }
                                                   
             dis3=0.00; 
             for (l=0;l<NE;l++) {
                  temp=0.00; 
                  for (m=0;m<NB+NE;m++)
                       temp+=EGA[l][m]*Gomg[i][m];
                  for (m=0;m<NK;m++)
                       temp+=EGA[l][NB+NE+m]*ZZ[j][m];
                  dis3+=SQR(Gomg[i][NB+l]-temp)/ETHZ[l]; 
                  }
             aa[j]=exp(-0.5*(dis1+dis3+dis2))*wgt[j];
             sum+=aa[j];
             }
        for (k=0;k<NG;k++) prop[k]=aa[k]/sum;
                   
        idum=rand();  unif=ran3(&idum);
        temp=0.00;  
        for (k=0;k<NG;k++) {
             temp+=prop[k];
             if (unif <= temp) {
                  LL[i]=k+1; break;}
             }
        }
              
   for (i=0;i<NO;i++) { k=LL[i]-1;
        for (j=0;j<NK;j++)
             omga[i][NC+NE+j]=ZZ[k][j];
        for (j=0;j<NK;j++)
             Gomg[i][NB+NE+j]=ZZ[k][j];
        }
           
   /* I will kill it if someone suspects my programm */

   /*////////////////////////////////*/
   free_matrix(Cov,  1,NK,1,NK);
   free_matrix(ivCov,1,NK,1,NK);
   free_matrix(ivPH, 1,NK,1,NK);
} /* End of Program   */

void  order(LL,nn,Ls,Int,mm)
int   LL[nn],nn;
int   Ls[],Int[];
int   *mm;
{
  int   j,k,l,s,t;
  int   *aa;
  aa=ivector(1,nn);

  for (j=1;j<=nn;j++) aa[j]=LL[j-1];
  sort(nn,aa);

  s=0; t=0;
  do {    Ls[t]=aa[s+1];
          l=s; j=0;
          do {  if (aa[l+1] == aa[s+1]) j++;
                else break;
                l++;
               }while(l < nn);
          Int[t]=j;  s=l;  t++;
         }while(s < nn);
 *mm=t;
 free_ivector(aa,1,nn);
} 
