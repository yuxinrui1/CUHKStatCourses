/*************************************************************************
To sample Z randomyl from a gamma distribution g(a,1) with a>1,cheng and feast
1979,GKM1 a<2.5, f(a,beta)=x^{a-1}e^{-x/beta}/(gamma(a)*beta^alp)
***************************************************************************/
float gamm2(float a,float beta)
{ float u1,u2,a1, b, m, d,v;
   long id;
   a1=a-1.0;b=(a-1.0/(6.0*a))/a1;
   m=2.0/a1;d=m+2.0;
   do{ id=rand();
       u1=ran3(&id);
       id=rand();
       u2=ran3(&id);
       v=b*u2/u1;
       if (m*u1-d+v+1.0/v<=0) break;
       if (m*log(u1)-log(v)+v-1.0<=0) break;
    }while(1);
  return a1*v*beta;
}
      
