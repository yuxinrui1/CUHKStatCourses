  /*//////////////////////////////////////////////////////////////
  //  W -Wishart(B,m), then  W^{-1} --IWishart( B^{-1},m)       //
  //////////////////////////////////////////////////////////////*/

#include  "wishart.c"

void   draw_PHI(rho0,R0v,omega,Phi)

float  omega[NO][MO];
float  **R0v, rho0;
float  **Phi;
{          
	  int    i, j, k;
	  float  **RR, **RRv,**Phiv;
                         
	  RRv =matrix(1,NK,1,NK);
	  RR  =matrix(1,NK,1,NK);
	  Phiv=matrix(1,NK,1,NK);

	  for (j=1;j<=NK;j++)
	       for (k=1;k<=NK;k++) {
	            RR[j][k]=0.00; 
	            for (i=0;i<NO;i++)
	                 RR[j][k]+=omega[i][NC+NE+j-1]
	                          *omega[i][NC+NE+k-1];
	            RR[j][k]+=R0v[j][k];
	            }                
	  inv(RR,NK,RRv);
	  wishart(RRv,NO+(int)rho0,NK,Phiv);
	  inv(Phiv,NK,Phi);

    free_matrix(RRv, 1,NK,1,NK);
    free_matrix(RR,  1,NK,1,NK);
    free_matrix(Phiv,1,NK,1,NK);
}
