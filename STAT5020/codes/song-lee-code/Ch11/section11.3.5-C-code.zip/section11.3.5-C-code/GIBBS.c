#include  "draw_MSS.c"
#include  "draw_MSU.c"
#include  "draw_MUU.c"
#include  "draw_LBD.c"
#include  "draw_PSI.c"

#include  "draw_omg.c"
#include  "draw_PHI.c"

#include  "draw_ETA.c"
#include  "draw_ZWL.c"
#include  "draw_MUZ.c"
#include  "draw_ALP.c"

void   GIBBS(np,rp,IYY,IDXLD,IDXGA,omega,Gomg,YY,UU,
             mu0,SGM0v,lbd0,H0,alp0,bta0,
             pi0,G0,alp1,bta1,R0v,rho0,
             sgm0,a1,a2,b1,b2,ALP,LL,
             MU,LD,THE,GA,PSI,MUZ,PH,EST,STD)

int     np,rp,IYY[NO][NI], LL[NO];
int     IDXLD[NI][MO], IDXGA[NE][NS];

float   mu0[NI], **SGM0v;
float   lbd0[NI][MO],H0[MO][MO];
float   pi0[NE][NS], G0[NS][NS];
float   alp0[NI], bta0[NI];
float   alp1[NE], bta1[NE];
float   **R0v, rho0;
float   sgm0,a1[NK],a2[NK],b1,b2;

float   YY[NO][NI];
float   omega[NO][MO], Gomg[NO][NS];
float   UU[NO][NY2][KT];

float   ALP;
float   MU[NI];
float   LD[NI][MO], THE[NI];
float   GA[NE][NS], PSI[NE];
float   MUZ[NK], **PH;

float   EST[NP],STD[NP];
{   
    int     i,j,k,t,l, GIB;
    float   YUs[NO][NI];
    float   VEC[ITER][NP];
    float   THEv[NI];
    float   COV[NP], vcc[NP];
    double  wgt[NG], bb;
    float   ZZ[NG][NK];
    float   Eomg[NO][MO];
    float   mean[NK];
    FILE   *fp1, *fp;

    for (j=0;j<NI-2;j++) THEv[j]=1.0/THE[j];
    THEv[NI-2]=1.0;  THEv[NI-1]=1.0;
            
    for (i=0;i<NO;i++)
         for (j=0;j<NI;j++) YUs[i][j]=0.0;
               
    for (i=0;i<NG;i++) wgt[i]=0.0;            
    for (i=0;i<NG;i++)
         for (j=0;j<NK;j++) ZZ[i][j]=0.0;            
              
    for (j=0;j<NP;j++){
         EST[j]=0.00; STD[j]=0.00;}

    for (i=0;i<NO;i++)
         for (j=0;j<MO;j++)
              Eomg[i][j]=0.00;
             
    for (GIB=1; GIB<=MCAX; GIB++) {
           
         DAT_est(IDXLD,IDXGA,MU,LD,THE,GA,PSI,PH,ALP);
              
         draw_MSS(IYY,MU,LD,THE,omega,YY);
	 draw_MSU(IYY,MU,LD,omega,YY,UU,YUs);
         draw_LBD(IDXLD,lbd0,H0,alp0,bta0,
                         omega,YUs,MU,LD,THE,THEv);
         draw_PSI(IDXGA,pi0,G0,alp1,bta1,
                               omega,Gomg,GA,PSI);
         /*///////////// NONPARA BAY ////////////*/ 

         if (PRA == 0) {
             draw_ETA(MU,LD,THEv,GA,PSI,PH,YUs,omega,Gomg);
             draw_ZWL(ALP,MU,LD,THEv,GA,PSI,MUZ,PH,
                      omega,Gomg,YUs,UU,wgt,&bb,ZZ,LL);
             draw_MUZ(sgm0,a1,a2,ZZ,MUZ,PH);
             draw_ALP(b1,b2,bb,&ALP);
             } 
          /*///////////////PARA BAY/////////////*/ 
          if (PRA == 1 ) {
              draw_omg(MU,LD,THEv,GA,PSI,MUZ,PH,YUs,omega,Gomg);
              draw_PHI(rho0,R0v,omega,PH);
              }
                                    
          if (REP > 0 && REP < 4  ) {
              speed(np,IDXLD,IDXGA,MU,LD,THE,GA,PSI,PH,vcc);
              fp=fopen("Est_n.dat","a");
              for (j=0;j<np;j++)
                   fprintf(fp,"%8.3f",vcc[j]);
              fprintf(fp,"\n");
              fclose(fp);
              }
                
          if (GIB > GNUM) { t=(int)(GIB-GNUM-1);
              for (i=0;i<NO;i++)
                   for (j=0;j<MO;j++)
                        Eomg[i][j]+=omega[i][j]/(MCAX-GNUM);
/*                
               speed(np,IDXLD,IDXGA,MU,LD,THE,GA,PSI,PH,vcc);
               for (j=0;j<np;j++)
                     VEC[t][j]=vcc[j];        
               for (j=0;j<np;j++)
	            EST[j]+=vcc[j]/(float)(MCAX-GNUM);
*/                          
               if (GIB % 2000 == 0) {
                   fp=fopen("obs_omg1.dat","a");
                   for (i=0;i<NO;i++)
                        fprintf(fp,"%8.4f",Eomg[i][NC+NE]);
                   fprintf(fp,"\n");
                   fclose(fp);
                   fp=fopen("obs_omg2.dat","a");
                   for (i=0;i<NO;i++)
                        fprintf(fp,"%8.4f",Eomg[i][NC+NE+1]);
                   fprintf(fp,"\n");
                   fclose(fp);
                   fp=fopen("obs_omg3.dat","a");
                   for (i=0;i<NO;i++)
                        fprintf(fp,"%8.4f",Eomg[i][NC+NE+2]);
                   fprintf(fp,"\n");
                   fclose(fp);
                   fp=fopen("obs_omg4.dat","a");
                   for (i=0;i<NO;i++)
                        fprintf(fp,"%8.4f",Eomg[i][NC+NE+3]);
                   fprintf(fp,"\n");
                   fclose(fp);
                   for (i=0;i<NO;i++)
                        for (j=0;j<MO;j++)
                              Eomg[i][j]=0.00;
                   }  
               }
          }
/*   exit(1);  */
   for (j=0;j<np;j++) { 
        COV[j]=0.00;
        for (t=0;t<MCAX-GNUM;t++)
             COV[j]+=SQR(VEC[t][j]-EST[j])/(MCAX-GNUM-1.0);
        STD[j]=sqrt(COV[j]);
        }
} /*////// End Of Programm //////*/
