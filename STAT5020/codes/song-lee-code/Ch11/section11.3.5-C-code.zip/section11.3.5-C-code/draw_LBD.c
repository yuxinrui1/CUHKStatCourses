void     draw_LBD(IDXLD,lbd0,H0,alp0,bta0,
                  omga,YY,EMU,ELD,ETHE,ETHEv)
    
int      IDXLD[NI][MO];
float    lbd0[NI][MO], H0[MO][MO];
float    alp0[NI], bta0[NI];
          
float    omga[NO][MO],YY[NO][NI];
          
float    EMU[NI], ELD[NI][MO];
float    ETHE[NI], ETHEv[NI];
{ 
  int     i,j,k,l,m,s,t;
  int     cord, dim[NI];

  float   YK[NO],gg[MO][MO];
  float   b[MO],  E[MO][MO]; 
  float   lbd_str[MO];
  float   temp,alf,bta;
  float   aa0, aa1,aa2;
  float   mean1[MO], mean[MO];
  float   star0[MO],mean0[MO]; 
  float   **Sgm, **AA,**AAv;
  float   **HH0,**H0v;
                
  HH0=matrix(1,MO,1,MO);
  H0v=matrix(1,MO,1,MO);
  AA =matrix(1,MO,1,MO);
  AAv=matrix(1,MO,1,MO);
  Sgm=matrix(1,MO,1,MO);
  
  /*//////////////////////////*/
  for (j=0;j<NI;j++) { dim[j]=0;
       for (k=0;k<MO;k++)
            dim[j]+=IDXLD[j][k];
       }  
  for (l=0;l<MO;l++)
       for (m=0;m<MO;m++) { gg[l][m]=0.0;
            for (i=0;i<NO;i++)
                 gg[l][m]+=omga[i][l]*omga[i][m];
            }

  for (k=0;k<NY1;k++)
       if (dim[k] != 0) {  
                        
           for (l=0;l<MO;l++)
                for (m=0;m<MO;m++) E[l][m]=0.0;
           cord=0;
           for (j=0;j<MO;j++)
                if (IDXLD[k][j] == 1) { 
                    E[cord][j]=1;cord++;}
           for (l=0;l<dim[k];l++) 
                for (m=0;m<dim[k];m++) { AAv[l+1][m+1]=0.0; 
                     for (s=0;s<MO;s++)
                          for (t=0;t<MO;t++) 
                               AAv[l+1][m+1]+=E[l][s]*gg[s][t]*E[m][t];
                    }
           for (l=0;l<dim[k];l++) 
                for (m=0;m<dim[k];m++) { HH0[l+1][m+1]=0.0; 
                     for (s=0;s<MO;s++)
                          for (t=0;t<MO;t++) 
                               HH0[l+1][m+1]+=E[l][s]*H0[s][t]*E[m][t];
                     }
           inv(HH0,dim[k],H0v);
           for (l=1;l<=dim[k];l++) 
               for (m=1;m<=dim[k];m++) 
                    AAv[l][m]+=H0v[l][m];
           inv(AAv,dim[k],AA);
             
           for (j=0;j<dim[k];j++) { star0[j]=0.0;
                for (l=0;l<MO;l++)
                     star0[j]+=E[j][l]*lbd0[k][l];
                }
           for (j=0;j<MO;j++)  
                if (IDXLD[k][j] == 1) b[j]=0.0;
                else                  b[j]=ELD[k][j];                  
           for (i=0;i<NO;i++) { temp=0.0;
                for (j=0;j<MO;j++)
                     temp+=b[j]*omga[i][j];
                YK[i]=YY[i][k]-temp;
                }
           for (l=0;l<dim[k];l++) { mean0[l]=0.0;
                for (m=0;m<dim[k];m++)
                     mean0[l]=H0v[l+1][m+1]*star0[m];
                }
           for (l=0;l<dim[k];l++) { mean1[l]=0.0;
                for (m=0;m<MO;m++)
                     for (i=0;i<NO;i++)
                          mean1[l]+=E[l][m]*omga[i][m]*YK[i];
                }
           for (l=0;l<dim[k];l++) { mean[l]=0.0;
                for (m=0;m<dim[k];m++)
                     mean[l]+=AA[l+1][m+1]*(mean0[m]+mean1[m]);
                }                         
           aa0=0.0;
           for (l=0;l<dim[k];l++) 
                for (m=0;m<dim[k];m++)
                     aa0+=star0[l]*H0v[l+1][m+1]*star0[m];
           aa1=0.0;
           for (i=0;i<NO;i++) aa1+=YK[i]*YK[i];
           aa2=0.0;                       
           for (l=0;l<dim[k]; l++) 
                for (m=0;m<dim[k];m++)
                     aa2+=mean[l]*AAv[l+1][m+1]*mean[m];
           alf=0.5*NO+alp0[k];   
           bta=1.0/(bta0[k]+0.5*(aa0+aa1-aa2));  
           ETHE[k]=1.0/gammdev(alf,bta);
           /*////////////////////////////////////////*/
           for (l=1;l<=dim[k];l++)  
                for (m=1;m<=dim[k];m++)
                     Sgm[l][m]=AA[l][m]*ETHE[k];
           mvnrnd(dim[k],mean,Sgm,lbd_str);
                 
           for (j=0;j<MO;j++) { ELD[k][j]=0.0;
                for (l=0;l<dim[k];l++)
                     ELD[k][j]+=E[l][j]*lbd_str[l]; 
                ELD[k][j]+=b[j];
                }
           }   
      else{ aa1=0.0;
            for (i=0;i<NO;i++) { temp=0.0;
                 for (l=0;l<MO;l++)
                      temp+=ELD[k][l]*omga[i][l];
                 aa1+=SQR(YY[i][k]-temp);
                 }
            alf=0.5*NO+alp0[k];  
            bta=1.0/(0.5*aa1+bta0[k]);   
            ETHE[k]=1.0/gammdev(alf,bta);
            } 
  
  for (k=NY1;k<NI;k++)   
       if (dim[k] != 0) { 
                 
            for (l=0;l<MO;l++)
                 for (m=0;m<MO;m++) E[l][m]=0.0;
            cord=0;
            for (j=0;j<MO;j++)
                 if (IDXLD[k][j] == 1) {
                     E[cord][j]=1; cord++;}
            for (l=0;l<dim[k];l++) 
                 for (m=0;m<dim[k];m++) { AAv[l+1][m+1]=0.0;
                      for (s=0;s<MO;s++)
                           for (t=0;t<MO;t++) 
                                AAv[l+1][m+1]+=E[l][s]*gg[s][t]*E[m][t]
                                              *ETHEv[k];
                      }
            for (l=0;l<dim[k];l++) 
                 for (m=0;m<dim[k];m++) { HH0[l+1][m+1]=0.0; 
                      for (s=0;s<MO;s++)
                           for (t=0;t<MO;t++) 
                                HH0[l+1][m+1]+=E[l][s]*H0[s][t]*E[m][t];
                      }
            inv(HH0,dim[k],H0v);
            for (l=1;l<=dim[k];l++) 
                 for (m=1;m<=dim[k];m++) AAv[l][m]+=H0v[l][m];
            inv(AAv,dim[k],AA);
            for (j=0;j<dim[k];j++) {star0[j]=0.0;
                 for (l=0;l<MO;l++)
                      star0[j]+=E[j][l]*lbd0[k][l];
                 }  
            for (j=0;j<MO;j++)  
                 if (IDXLD[k][j] == 1) b[j]=0.0;
                 else                  b[j]=ELD[k][j];
            for (i=0;i<NO;i++) { temp=0.0;   
                 for (j=0;j<MO;j++) 
                      temp+=b[j]*omga[i][j];
                 YK[i]=(YY[i][k]-temp)*ETHEv[k];
                 }
            for (l=0;l<dim[k];l++) { mean0[l]=0.0;
                 for (m=0;m<dim[k];m++)   
                      mean0[l]=H0v[l+1][m+1]*star0[m];
                 }    
            for (l=0;l<dim[k];l++) { mean1[l]=0.0;
                 for (m=0;m<MO;m++)
                      for (i=0;i<NO;i++)
                           mean1[l]+=E[l][m]*omga[i][m]*YK[i];
                 }
            for (l=0;l<dim[k];l++) { mean[l]=0.0;
                 for (m=0;m<dim[k];m++)
                      mean[l]+=AA[l+1][m+1]*(mean0[m]+mean1[m]);
                 }
            /*///////////////////////////////////////////////*/
            mvnrnd(dim[k],mean,Sgm,lbd_str);
            for (j=0;j<MO;j++) { ELD[k][j]=0.0;
                 for (l=0;l<dim[k];l++)
                      ELD[k][j]+=E[l][j]*lbd_str[l]; 
                 ELD[k][j]+=b[j]; 
                 }
            }              
            
   for (j=0;j<NI-2;j++) ETHEv[j]=KT*1.0;
    
   ETHEv[NI-2]=1.0; ETHEv[NI-1]=1.0;
      
   if (NY1 > 0)
       for (j=0;j<NY1;j++) ETHEv[j]=1.0/ETHE[j];
 /*///////////////////////*/
 free_matrix(HH0,1,MO,1,MO);
 free_matrix(H0v,1,MO,1,MO);
 free_matrix(AA, 1,MO,1,MO);
 free_matrix(AAv,1,MO,1,MO);
 free_matrix(Sgm,1,MO,1,MO);
}/*///////////////////////*/
