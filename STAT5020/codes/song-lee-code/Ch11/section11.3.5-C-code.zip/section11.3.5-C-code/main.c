#define    PRA   0   

#include  <math.h>
#include  <stdio.h>
#include  "nrutil.h"
#include  "nrutil.c"
#include  "def_sm.h"
#include  "inv.c"
#include  "det.c"
#include  "ran2.c"
#include  "ran3.c"
#include  "gasdev.c"
#include  "choldc.c"
#include  "mvnrnd.c"
#include  "gammdev.c"
#include  "betadev.c"
#include  "rGamma.c"

#include  "read_obs.c"
#include  "read2.c"
#include  "super.c"
#include  "DAT_est.c"
#include  "speed.c" 
#include  "GIBBS.c"
#include  "anti.c"
#include  "epsr.c"

main()
{
   int    i,j,k,l,m,n,s,np,id,dim;
   int    rp,LL[NO], IYY[NO][NI];
   int    IDXLD[NI][MO], IDXGA[NE][NS];
   long   idum;

   float  mu0[NI], **SGM0v;
   float  lbd0[NI][MO],H0[MO][MO];
   float  pi0[NE][NS], G0[NS][NS];
   float  alp0[NI], bta0[NI];
   float  alp1[NE], bta1[NE];
   float  **R0v,rho0;

   float  a1[NK],a2[NK],b1,b2,sgm0;
   float  prb, EALP;

   float  EMU[NI];
   float  ELD[NI][MO], ETHE[NI];
   float  EGA[NE][NS], ETHZ[NE];
   float  EMUZ[NK], **EPH;
                 
   float  YY[NO][NI], omga[NO][MO];
   float  UU[NO][NY2][KT];
   float  Gomg[NO][NS];
   float  CVX[NO][NC+1];
   float  CVZ[NO][NB+1];
                 
   float  BIA[NP],RMS[NP],STD[NP];
   float  EST[NP], std[NP];

   float  vv[ITER][NP], pre;
   float  *vs;
   FILE  *fp;
    
   vs   =vector(1,   ITER);                   
   EPH  =matrix(1,NK,1,NK); 
   SGM0v=matrix(1,NI,1,NI); 
   R0v  =matrix(1,NK,1,NK); 
                            
   read_obs(IDXLD,IDXGA,YY,CVX,CVZ,IYY);
     
   super(mu0,SGM0v,lbd0,H0,alp0,bta0,
         pi0,G0,alp1,bta1,&rho0,R0v,
         &sgm0,a1,a2,&b1,&b2); 
          
   for (i=0;i<NO;i++) 
        for (j=0;j<MO;j++) omga[i][j]=0.0;
   for (i=0;i<NO;i++) 
        for (j=0;j<NC;j++) omga[i][j]=CVX[i][j];
   for (i=0;i<NO;i++) 
        for (j=0;j<NS;j++) Gomg[i][j]=0.0;
   for (i=0;i<NO;i++) 
        for (j=0;j<NB;j++) Gomg[i][j]=CVZ[i][j];
     
   if ( PRA == 1 ) np=NP;
   if ( PRA == 0 ) np=(int)(NP-NK*(NK+1)/2);
   /*//////////////////////////////////////////
                    Iteration
   //////////////////////////////////////////*/
   for (j=0;j<NP;j++) {
        std[j]=0.0; EST[j]=0.0;}

   for (rp=1;rp<=REP;rp++) {
                        
        read2(rp,EMU,ELD,ETHE,EGA,ETHZ,EMUZ,EPH,
                      omga,Gomg,YY,&EALP,LL,UU);
                             
        for (j=0;j<NI;j++)
             for (k=1;k<NC;k++) {
                  IDXLD[j][k]=0; ELD[j][k]=0.0; }
        for (i=0;i<NO;i++)
             for (k=1;k<NC;k++)
                  omga[i][k]=0.0;
                                         
        GIBBS(np,rp,IYY,IDXLD,IDXGA,omga,Gomg,YY,UU,
              mu0,SGM0v,lbd0,H0,alp0,bta0,
              pi0,G0,alp1,bta1,R0v,rho0,
              sgm0,a1,a2,b1,b2,EALP,LL,
              EMU,ELD,ETHE,EGA,ETHZ,EMUZ,EPH,EST,std);
        }
/*   exit(1);  */ 
   fp=fopen("Est_n.dat","r");
   for (j=0;j<ITER;j++)
        for (k=0;k<np;k++)
             fscanf(fp,"%f",&vv[j][k]);
   fclose(fp);

   id=(int)(0.95*ITER);
                   
   fp=fopen("DPH.dat","w");
       
   for (j=0;j<np;j++) {
 
        for (k=0;k<ITER;k++)
             vs[k+1]=vv[k][j];
                                
        sort(ITER,vs);
        pre=vs[1+id]-vs[1];  /* (vv[1] vv[1+id])*/         
        s=1; 
        for (k=2; k<=ITER-id; k++)
             if ( vs[k+id]-vs[k] < pre) {
                  pre=vs[k+id]-vs[k]; 
                  s++;
                  }
               
        fprintf(fp,"[ %5.3f    %5.3f]",vs[s],vs[s+id]);
        fprintf(fp,"\n");
        }
  fclose(fp);
 exit(1);
 if (REP > 1 && REP < 4) epsr(REP,np,MCAX);

 free_matrix(EPH,  1,NK,1,NK);
 free_matrix(R0v,  1,NK,1,NK); 
 free_matrix(SGM0v,1,NI,1,NI);
 free_vector(vs,   1,   ITER);
}

