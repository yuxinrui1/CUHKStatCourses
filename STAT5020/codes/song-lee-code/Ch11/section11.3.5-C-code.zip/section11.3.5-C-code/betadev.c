/*generate a random number from Beta(a,b) distribution*/
 
#include <math.h> 

double betadev(float a,float b)
{
   double  t,p,z,z1,d1,d2,d3,d4,d5,d6,d7;
   double  u1,u2,v,w,r,s;
   double  flag,u,y,y1,y2,c;
   long lnum;

   flag=0.0;

   if(a<1 && b<1){
     t=1.0/(1.0+sqrt(b*(1.0-b)/(a*(1.0-a))));
     p=b*t/(b*t+a*(1.0-t));
     do{
        lnum=rand(); u=ran2(&lnum);
        lnum=rand(); y=expdev(&lnum);
        if(u<p){
           z=t*pow(u/p,1.0/a);
           if(y>=(1.0-b)*(t-z)/(1.0-t)){flag=1.0;}
           }
       else{
          z=1.0-(1.0-t)*pow((1.0-u)/(1.0-p),1.0/b);
          if(y>=(1.0-a)*(z/t-1.0)){flag=1.0;}
          }
      }while(flag<=0.0);
   }
   else if(a>1 && b>1){
     d1=(a<=b)?a:b;
     d2=(a>=b)?a:b;
     d3=d1+d2;
     d4=sqrt((d3-2.0)/(2.0*d1*d2-d3));
     d5=d1+1.0/d4;
     do{
       lnum=rand();
       u1=ran2(&lnum);
       lnum=rand();
       u2=ran2(&lnum);
       v=d4*log(u1/(1.0-u1));
       w=d1*exp(v);
       z1=u1*u1*u2;
       r=d5*v-1.38629436;
       s=d1+r-w;
       if(s+2.60943791>5.0*z1){
         if(d1==a)z=w/(d2+w);
         else z=d2/(d2+w);
         flag=1.0;
       }
       else{
         t=log(z1);
         if(s>=t){
           if(d1==a)z=w/(d2+w);
           else z=d2/(d2+w);
           flag=1.0;
         }
         else{
           if(r+d3*log(d3/(d2+w))>=t){
             if(d1==a)z=w/(d2+w);
             else z=d2/(d2+w);
             flag=1.0;
           }
         }
       }
     }while(flag<=0);
   }
   else{
     if(a<=b)flag=1.0;
     else{
        c=a; a=b; b=c; flag=0.0;
     }
     t=(1.0-a)/(b+1.0-a);
     r=b*t/(b*t+a*pow((1.0-t),b));
     s=pow(t,(a-1.0));
     /*printf("r and s and t = %f and %f and %f\n",r,s,t);*/
     do{
       lnum=rand();
       u1=ran2(&lnum);
       lnum=rand();
       u2=ran2(&lnum);
       if(u1<=r){
         z=t*pow(u1/r,1.0/a);
         if(u2<=pow((1.0-z),b-1.0)) break;
       }
       else{
         z=1.0-(1.0-t)*pow((1.0-u1)/(1.0-r),1.0/b);
         if(s*u2<=pow(z,a-1.0)) break;
       }
     }while(1);
     if(flag==0.0)z=1-z;
   }
   return(z);

}/*end*/
