  /*///////////////////// Draw ETA in omega ///////////////*/

void      draw_ETA(EMU,ELD,ETHEv,EGA,ETHZ,EPH,YY,omga,Gomg)

float     EMU[NI];
float     ELD[NI][MO], ETHEv[NI];
float     EGA[NE][NS], ETHZ[NE];
float     **EPH;

float     YY[NO][NI];
float     omga[NO][MO],Gomg[NO][NS];
{            
  int      i,j,k,l,m;
  float    B0[NE][NE];
  float    Ax[NE][NI],Az[NE][NE];
  float    ETAs[NE],YYs[NI];
  float    eta[NE],mean[NE];
  float    muu[NI];
  float    **Omg, **Omgv;

  Omg =matrix(1,NE,1,NE);
  Omgv=matrix(1,NE,1,NE);
               
  for (j=0;j<NE;j++) {
       for (k=0;k<NE;k++) B0[j][k]=-EGA[j][NB+k];
       B0[j][j]+=1.0;
       }
  for (j=0;j<NE;j++)
       for (k=0;k<NE;k++) { Omgv[j+1][k+1]=0.0;
	    for (l=0;l<NI;l++)
                 Omgv[j+1][k+1]+=ELD[l][NC+j]*ELD[l][NC+k]*ETHEv[l];
            for (l=0;l<NE;l++)
                 Omgv[j+1][k+1]+=B0[l][j]*B0[l][k]/ETHZ[l];
            }
  inv(Omgv,NE,Omg);
  /*////////////////////////////////////////////////////////*/
  for (j=0;j<NE;j++) 
       for (k=0;k<NI;k++) { Ax[j][k]=0.0;
            for (l=0;l<NE;l++)
                 Ax[j][k]+=Omg[j+1][l+1]*ELD[k][NC+l]*ETHEv[k];
            }
  for (j=0;j<NE; j++) 
       for (k=0;k<NE;k++) { Az[j][k]=0.0;
            for (l=0;l<NE;l++)  
                 Az[j][k]+=Omg[j+1][l+1]*B0[k][l]/ETHZ[k];
            }
  /*///////////////////// Update  Eta /////////////////*/
      
  for (i=0;i<NO;i++) {
       
       for (j=0;j<NI;j++) { muu[j]=0.00;
            for (k=0;k<NC;k++)
                 muu[j]+=ELD[j][k]*omga[i][k];
            for (k=0;k<NK;k++)
                 muu[j]+=ELD[j][NC+NE+k]*omga[i][NC+NE+k];
            YYs[j]=YY[i][j]-muu[j];
            }
            
       for (j=0; j<NE; j++) { ETAs[j]=0.0;
            for (k=0;k<NB;k++)
                 ETAs[j]+=EGA[j][k]*Gomg[i][k];
            for (k=0;k<NF;k++)
                 ETAs[j]+=EGA[j][NB+NE+k]*Gomg[i][NB+NE+k];
            }
       /*/////////////////////////////////////////*/
       for (j=0;j<NE;j++) { mean[j]=0.0;
            for (k=0;k<NI;k++)
                 mean[j]+=Ax[j][k]*YYs[k];       
            for (k=0;k<NE;k++)
                 mean[j]+=Az[j][k]*ETAs[k]; 
            }
       mvnrnd(NE,mean,Omg,eta);
         
       for (j=0;j<NE;j++) omga[i][NC+j]=eta[j]; 
       }

  for (i=0;i<NO;i++) 
       for (j=0;j<NE;j++)  
            Gomg[i][NB+j]=omga[i][NC+j]; 

  /*///////////////////////////////////*/
  free_matrix(Omg, 1,NE,1,NE);
  free_matrix(Omgv,1,NE,1,NE);
              
}  /*///////End of Programm ///////*/
/*
       for (i=0; i<NO; i++)  { 
            for (j=0; j<MO; j++)  
                 printf("%8.4f ",omega[i][j]);
            printf("\n");
            for (j=0; j<NS; j++)  
                 printf("%8.4f ",Gomg[i][j]);
            printf("\n--------------------\n");
            }
exit(1);
*/
