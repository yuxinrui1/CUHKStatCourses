R version 2.8.0 or after.


*******************
LIST OF R FUNCTION
*******************

run.R		     ---- main program
mixture. R	 ---- mixture function

*******************
LIST OF dll file
*******************
GIBBS.dll	---- compiled C code	

*****
USAGE
*****

step 1: In run.R: 	Change constants, priors, initial vaules, tuning parameters, and so on according to model.
                        Please follow the remarks of the program.

step 2: Run the run.R.

*******
Results
*******
The acceptance rates and DIC value will be printed on R screen.

Estimation of parameters are written in txt files with names begin with 'E' in the working directory.

Standard error of parameters are written in txt files with names begin with 'S' in the working directory.