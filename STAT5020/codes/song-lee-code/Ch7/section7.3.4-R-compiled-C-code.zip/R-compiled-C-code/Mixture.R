Mixture=function(Data, Dim, Gibbs, Init, Ind, Prior, Accept, Direc) {

    #Get the Dimension of the Parameter
    NO=Dim$NO; NC=Dim$NC; NY=Dim$NY; NK=Dim$NK; NX=Dim$NX; ND=Dim$ND; NM=Dim$NM; NZ=Dim$NZ
    NG=Dim$NG; NB=Dim$NB; NU=Dim$NU; NP=Dim$NP
    
    #write the data
    name=paste(Direc, "XO_R.txt", sep="")
    write("", name)
    temp=Data$YO
    write(t(temp), name, ncolumns=NY, sep="\t") #YO
    
    name=paste(Direc, "AZ_R.txt", sep="")
    temp=Data$AZ
    write(t(temp), name, ncolumns=NX, sep="\t") #AZ
    
    name=paste(Direc, "BZ_R.txt", sep="")
    temp=Data$BZ
    write(t(temp), name, ncolumns=ND, sep="\t") #BZ

    #write the indicator matrix and calculate the number of parameters
    name=paste(Direc, "/ind.txt", sep="")
    write("", name)
    temp=Ind$IDY
    write(t(temp), name, ncolumns=NK, sep="\t", append=T) #IDY
    
    temp=Ind$IDB
    write(t(temp), name, ncolumns=NB, sep="\t", append=T) #IDB
    
    DIM=as.integer(c(NO, NC, NY, NK, NX, ND, NM, NZ, NG, NB, NU, NP)) #DIM for GIBBS
    
    #write the initial values and the priors
    name=paste(Direc, "int1.txt", sep="")
    write("", name)
    for (i in 1:NC) {
    	  temp=Init$PHIY[,i]
    	  write(temp, name, ncolumns=NY+1, sep="\t", append=T) #PHIY
    }

    for (i in 1:NC) {
    	  temp=Prior$PHIY[,i]
    	  write(temp, name, ncolumns=NY+1, sep="\t", append=T) #PHIY
    }
        
    for (i in 1:NC) {
        temp=Init$LY[,,i]
        write(t(temp), name, ncolumns=NK, sep="\t", append=T) #LY
    }
    
    for (i in 1:NC) {
        temp=Prior$LY[,,i]
        write(t(temp), name, ncolumns=NK, sep="\t", append=T) #PLY
    }
    
    for (i in 1:NC) {
        temp=Init$MU[,i]
        write(temp, name, ncolumns=NY, sep="\t", append=T) #MU
    }
    
    for (i in 1:NC) {
        temp=Init$PSX[,i]
        write(temp, name, ncolumns=NY, sep="\t", append=T) #PSX 
    }
    
    for (i in 1:NC) {
        temp=Init$DELTA[,i]
        write(temp, name, ncolumns=NX+1, sep="\t", append=T) #DELTA
    }
    
    for (i in 1:NC) {
        temp=Prior$DELTA[,i]
        write(temp, name, ncolumns=NX+1, sep="\t", append=T) #PDELTA
    }    
    
    temp=Init$PHIAZ
    write(temp, name, ncolumns=NX+1, sep="\t", append=T) #PHIAZ
    
    temp=Prior$PHIAZ
    write(temp, name, ncolumns=NX+1, sep="\t", append=T) #PPHIAZ
    
    temp=Init$NUAZ
    write(t(temp), name, ncolumns=NU, sep="\t", append=T) #NUAZ
    
    name=paste(Direc, "int2.txt", sep="")
    write("", name)
    for (i in 1:NC) {
        temp=Init$BI[,,i]
        write(t(temp), name, ncolumns=NB, sep="\t", append=T) #BI

        temp=Init$PSD[,i]
        write(temp, name, ncolumns=NM, sep="\t", append=T) #PSD        
    }

    for (i in 1:NC) {
        temp=Prior$BI[,,i]
        write(t(temp), name, ncolumns=NB, sep="\t", append=T) #PBI
    }
    
    for (i in 1:NC) {
        length=NZ*(NZ+1)/2
        temp=numeric(length)
        l=1
        for (j in 1:NZ) { for (k in 1:j) { temp[l]=Init$PHI[j,k,i]; l=l+1 } }
        write(temp, name, ncolumns=length, sep="\t", append=T) #PHI
    }
    
    for (i in 1:NC) {
        temp=Prior$PHIBZ[,i]
        write(temp, name, ncolumns=ND+1, sep="\t", append=T) #PHIBZ
    }
    
    for (i in 1:NC) {
        temp=Prior$PHIBZ[,i]
        write(temp, name, ncolumns=ND+1, sep="\t", append=T) #PPHIBZ
    }
    
    for (i in 1:NC) {
        temp=Init$NUBZ[,,i]
        write(t(temp), name, ncolumns=NU, sep="\t", append=T) #NUBZ
    }
    
    name=paste(Direc, "Prior.txt", sep="")
    write("", name)
    for (i in 1:NC) {
        temp=Prior$ALPA[,i]
        write(temp, name, ncolumns=NY, sep="\t", append=T) #PALPA
        
        temp=Prior$BETA[,i]
        write(temp, name, ncolumns=NY, sep="\t", append=T) #PBETA

        temp=Prior$ALP[,i]
        write(temp, name, ncolumns=NM, sep="\t", append=T) #PALP

        temp=Prior$BE[,i]
        write(temp, name, ncolumns=NM, sep="\t", append=T) #PBE
        
        temp=Prior$Rho[i]
        write(temp, name, ncolumns=1, sep="\t", append=T) #RHO

        length=NZ*(NZ+1)/2
        temp=numeric(length)
        l=1
        for (j in 1:NZ) { for (k in 1:j) { temp[l]=Prior$RH[j,k,i]; l=l+1 } }
        write(temp, name, ncolumns=length, sep="\t", append=T) #RH
    }
    
    #write the Tuning Parameters
    name=paste(Direc, "Accept.txt", sep="")
    write("", name)
    for (i in 1:NC) {
        write(Accept$xi[i], name, append=T) #xi
        write(Accept$y[i], name, append=T) #y
        write(Accept$bz[i], name, append=T) #bz
        write(Accept$del[i], name, append=T) #del
        write(Accept$phiy[i], name, append=T) #phiy
        write(Accept$phibz[i], name, append=T) #phibz 
    }

    write(Accept$az, name, append=T) #az
    write(Accept$phiaz, name, append=T) #phiaz
    
    #prior for GIBBS
    prior=c(1/Prior$sigbi, 1/Prior$sigly, 1/Prior$sigphiy, 1/Prior$sigphiaz, 1/Prior$sigphibz, 1/Prior$sigdel)
    
    #Gibbs for GIBBS
    gibbs=as.integer(c(Gibbs$iteration, Gibbs$burnin, Gibbs$skip, Gibbs$tmax))
    
    name=paste(Direc, "GIBBS.dll", sep="")
    dyn.load(name)
    path=c(Direc)
    .Call("GIBBS", path, DIM, gibbs, prior)
    dyn.unload(name)    
    
    name=paste(Direc, "/ind.txt", sep="")
    file.remove(name)
    name=paste(Direc, "/int1.txt", sep="")
    file.remove(name)
    name=paste(Direc, "/int2.txt", sep="")
    file.remove(name)
    name=paste(Direc, "/Accept.txt", sep="")
    file.remove(name)  
    name=paste(Direc, "/XO_R.txt", sep="")
    file.remove(name)
    name=paste(Direc, "/AZ_R.txt", sep="")
    file.remove(name)
    name=paste(Direc, "/BZ_R.txt", sep="")
    file.remove(name)
    name=paste(Direc, "/Prior.txt", sep="")
    file.remove(name)    
}
