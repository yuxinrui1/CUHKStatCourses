#Working Directory                 
Direc="F:/RunReal/"

#load the mixture function
name=paste(Direc, "mixture.R", sep="")
source(name)

#specify the dimensions
NO=1588 #no. of observations
NC=2    #no. of components
NY=6    #dimension of y
NK=3    #dimension of latent variables, $\omega$
NM=1    #dimension of dependent latent vairables, $\eta$
NZ=2    #dimension of independent latent variables, $\xi$
NG=2    #dimension of the function, $F(\xi)$
NB=6    #no. of parameters in structural equation
NX=3    #no. of fixed covariates in x
ND=3    #no. of fixed covariates in c
NU=5    #no. of nuisance parameters in $\tau$
NP=76   #no. of total parameters

Dim=list(NO=NO, NC=NC, NY=NY, NK=NK, NX=NX, ND=ND, NM=NM, NZ=NZ, NG=NG, NB=NB, NU=NU, NP=NP)
#specify the dimension list

Gibbs=list(iteration=16000, burnin=8000, skip=1, tmax=50)
#specify the number of iterations, burn-ins, thinning rate, and sample size in calculating the DIC value

Ind=list(IDY=matrix(c(0,0,0,
                      0,0,0,
                      0,1,0,
                      0,0,0,
                      0,0,1,
                      0,0,1), nrow=NY, byrow=T),
         IDB=matrix(c(1,1,1,0,1,1), nrow=NM, byrow=T))
         #indicator matrix
#IDY (NY*NK), indicator matrix of $\Lambda$, 1 means the element needs to be estimated, 0 means the element is fixed
#IDB (NM*NB), indicator matrix of $\Pi$, 1 means the element needs to be estimated, 0 means the element is fixed

#specify the initial values          
LY=array(NA, dim=c(NY, NK, NC))   #Loading matrix, $\Lambda$
BI=array(NA, dim=c(NM, NB, NC))   #Coefficients in structural equation, $\Pi$
PHI=array(NA, dim=c(NZ, NZ, NC))  #Covariance matrix of independent latent variables, $\Phi$
NUBZ=array(NA, dim=c(ND, NU, NC)) #Niusance parameters in $\tau_c$

MU=matrix(rep(0, NY*NC), ncol=NC, byrow=T)        #Intercept, $\mu$
PSX=matrix(rep(0.1, NY*NC), ncol=NC, byrow=T)     #Measurement error, $\psi$
PSD=matrix(rep(0.5, NM*NC), ncol=NC, byrow=T)     #Structural error, $\psi_\delta$
DELTA=matrix(rep(0, (NX+1)*NC), ncol=NC, byrow=T) #coeffients in the logistic regression, $\delta$
PHIY=matrix(rep(0, (NY+1)*NC), ncol=NC, byrow=T)  #nonignorable missing coefficients for y, $\varphi_y$
PHIAZ=rep(0, (NX+1))                              #nonignorable missing coefficients for x, $\varphi_x$
PHIBZ=matrix(rep(0, (ND+1)*NC), ncol=NC, byrow=T) #nonignorable missing coefficients for c, $\varphi_c$

NUAZ=matrix(c(0, 1,-1,-1,-1,
              3,-1,-1,-1,-1,
              3,-1,-1,-1,-1), nrow=NX, byrow=T) #Niusance parameters in $\tau_x$

NUBZ[,,1]=matrix(rep(0.2, ND*NU), nrow=ND, byrow=T)
NUBZ[,,2]=matrix(rep(0.2, ND*NU), nrow=ND, byrow=T)

LY[,,1]=matrix(c(1,0,0,
                 0,1,0,
                 0,0,0,
                 0,0,1,
                 0,0,0,
                 0,0,0), nrow=NY, byrow=T)

LY[,,2]=matrix(c(1,0,0,
                 0,1,0,
                 0,0,0,
                 0,0,1,
                 0,0,0,
                 0,0,0), nrow=NY, byrow=T)

BI[,,1]=matrix(rep(0, NM*NB), nrow=NM, byrow=T)

BI[,,2]=matrix(rep(0, NM*NB), nrow=NM, byrow=T)

PHI[,,1]=matrix(c(1,0,0,1), nrow=NZ, byrow=T)

PHI[,,2]=matrix(c(1,0,0,1), nrow=NZ, byrow=T)                    

#specify initial values list                                                     
Init=list(MU=MU, LY=LY, PSX=PSX, BI=BI, PSD=PSD, PHI=PHI, DELTA=DELTA, PHIY=PHIY, PHIAZ=PHIAZ, PHIBZ=PHIBZ, 
          NUAZ=NUAZ, NUBZ=NUBZ)

#Prior information
PLY=array(NA, dim=c(NY, NK, NC)) #prior mean for $\Lambda$
PBI=array(NA, dim=c(NM, NB, NC)) #prior mean for $\Pi$

PLY[,,1]=matrix(c(1,0,0,
                  0,1,0,
                  0,0,0,
                  0,0,1,
                  0,0,0,
                  0,0,0), nrow=NY, byrow=T)

PLY[,,2]=matrix(c(1,0,0,
                  0,1,0,
                  0,0,0,
                  0,0,1,
                  0,0,0,
                  0,0,0), nrow=NY, byrow=T)


PBI[,,1]=matrix(rep(0, NM*NB), nrow=NM, byrow=T)

PBI[,,2]=matrix(rep(0, NM*NB), nrow=NM, byrow=T)                 

PDELTA=matrix(rep(0, (NX+1)*NC), ncol=NC, byrow=T)  #prior mean for $\delta$
PPHIY=matrix(rep(0, (NY+1)*NC), ncol=NC, byrow=T)   #prior mean for $\varphi_y$
PPHIAZ=rep(0, (NX+1))                               #prior mean for $\varphi_x$
PPHIBZ=matrix(rep(0, (ND+1)*NC), ncol=NC, byrow=T)  #prior mean for $\varphi_c$

PALPA=matrix(rep(9, NC*NY), ncol=NC, byrow=T) #$\alpha_{kj0}$
PBETA=matrix(rep(4, NC*NY), ncol=NC, byrow=T) #$\beta_{kj0}$
PALP=matrix(rep(9, NC*NM), ncol=NC, byrow=T)  #$\tilde \alpha_{kl0}$
PBE=matrix(rep(4, NC*NM), ncol=NC, byrow=T)   #$\tilde_\beta_{kl0}$
RHO=matrix(rep(4, NC), ncol=NC, byrow=T)      #\rho_{k0}$
RH=array(NA, dim=c(NZ, NZ, NC))               #$V_{k0}$

RH[,,1]=matrix(c(1,0,0,1), nrow=NZ, byrow=T)

RH[,,2]=matrix(c(1,0,0,1), nrow=NZ, byrow=T)

sigly=10     #prior variance for $\Lambda$
sigbi=10     #prior variance for $\Pi$
sigphiy=10   #prior variance for $\varphi_y$
sigphiaz=10  #prior variance for $\varphi_x$
sigphibz=10  #prior variance for $\varphi_c$
sigdel=10    #prior variance for $\delta$

#specify the prior list
Prior=list(LY=PLY, BI=PBI, PHIBZ=PHIBZ, DELTA=PDELTA, PHIY=PPHIY, PHIAZ=PPHIAZ, PHIBZ=PPHIBZ,
           ALPA=PALPA, BETA=PBETA, ALP=PALP, BE=PBE, Rho=RHO, RH=RH,
           sigmu=sigbi, sigly=sigly, sigphiy=sigphiy, 
           sigphiaz=sigphiaz,  sigphibz=sigphibz, sigdel=sigdel)

#read the data
name=paste(Direc, "YO.txt", sep="")      
YO=matrix(scan(name), nrow=NO, byrow=T)
#observations, $y$, please note that 999 stands for missing data

name=paste(Direc, "AZ.txt", sep="")  
AZ=matrix(scan(name), nrow=NO, byrow=T)
#fixed covariates in logistic regression, $x$,  please note that 999 stands for missing data

name=paste(Direc, "BZ.txt", sep="")  
BZ=matrix(scan(name), nrow=NO, byrow=T)
#fixed covariates in structural equation, $c$, please note that 999 stands for missing data

#specify data list
Data=list(YO=YO, AZ=AZ, BZ=BZ)

#specify the tuning parameters
xi=c(2,2) #tuning parameter for $\omega$
y=c(16,15) #tuning parameter for missing y
bz=c(1,1) #tuning parameter for missing c
del=c(2,1) #tuning parameter for $\delta$
phiy=c(5,3) #tuning parameter for $\varphi_y$
phibz=c(61,61) #tuning parameter for $\varphi_c$
az=12 #tuning parameter for missing x
phiaz=23 #tuning parameter for $\varphi_x$

#specify the tuning parameters list
Accept=list(xi=xi, y=y, bz=bz, del=del, phiy=phiy, phibz=phibz, az=az, phiaz=phiaz)

Mixture(Data, Dim, Gibbs, Init, Ind, Prior, Accept, Direc)
