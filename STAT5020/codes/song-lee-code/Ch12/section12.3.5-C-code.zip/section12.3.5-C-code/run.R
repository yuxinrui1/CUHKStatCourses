Prior=list(sigmu=1, sigly=1)
#Prior Variance for intercepts and factor loadings

#prior for GIBBS
prior=c(1/Prior$sigmu, 1/Prior$sigly)

Gibbs=list(iteration=20000, burnin=10000, skip=1)
#Gibbs sampler: Total itertaions, burn-in phase, space

#Gibbs for GIBBS
gibbs=as.integer(c(Gibbs$iteration, Gibbs$burnin, Gibbs$skip))

#Dim
DIM=as.integer(c(1660, 15, 0, 5, 1, 4, 7, 3, 84))
#Sample size, Dimension of Y, Dimension of fixed covariates in structural equation, Dimension of latent variables, Dimension of outcome latent variables
#Dimension of explanatory variables, Number of maximum categories of ordered categorical variables, Number of maximum categories of unordered categorical variables
#Number of unknown parameters

#knots
knotss=as.integer(c(25, 25, 2))
#Number of knots: fixed covariates in the structural equation, explanatory latent variables

Direc="F:/Run_Spline/"
#Working Directory

name=paste(Direc, "GIBBS.dll", sep="")
dyn.load(name)
path=c(Direc)
.Call("GIBBS", path, DIM, knotss, gibbs, prior)
dyn.unload(name)