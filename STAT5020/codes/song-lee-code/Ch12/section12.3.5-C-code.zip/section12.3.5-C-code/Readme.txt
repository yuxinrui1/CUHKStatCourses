R version 2.8.0 or after.


*******************
LIST OF R FUNCTION
*******************

run.R		---- main program

*******************
LIST OF dll file
*******************
GIBBS.dll	---- compiled C code	

*******************
LIST OF dll file
*******************

XO_R.txt	---- data
ind_R.txt	---- indicator
int1_R.txt	---- iniitial values
int2_R.txt	---- iniitial values
Prior_R.txt	---- Priors
Accept_R.txt	---- Tuning parameters

*****
USAGE
*****

step 1: In all txt files:	Change indicator, initial vaules, priors, tuning parameters, and so on according to model.
				Please follow the descriptions of the files.

step 2: Run the run.R.

*******
Results
*******

The acceptance rates and DIC value will be printed on R screen.

Estimation of parameters are written in txt files with names begin with 'E' in the working directory.

Standard error of parameters are written in txt files with names begin with 'S' in the working directory.

Estimated functions are written in txt files with names begin with 'fun' in the working directory.
