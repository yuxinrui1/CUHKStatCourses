for(g in 1:MCMAX){
gm<-g-N.burn
	#update omega_i
	PI.z<-diag(1,NM)-PI
	dH0<-fstd(rep(0,NZ),NG,NZ,scale.s*KNOT.XI,scale.s*BOUN.XI)
	sqrt.ISG<-matrix(0,nrow=NM,ncol=NK)
	sqrt.ISG[,1:NM]<-PI.z
	sqrt.ISG[,(NM+1):NK]<--PB%*%dH0
	ISG<-crossprod(inv.sqrt.PSD*sqrt.ISG)+crossprod(inv.sqrt.PSX*LY)
  #NOTE: when PI \neq 0, this method is problematic.
	ISG[(NM+1):NK,(NM+1):NK]<-ISG[(NM+1):NK,(NM+1):NK]+inv.PHI
	ISG<-ISG*VAR1
	SIG<-chol2inv(chol(ISG))
	cSIG<-chol(SIG)
	OMEN<-Omega+crossprod(cSIG,matrix(rnorm(N*NK,0,1),nrow=NK,ncol=N))
	nlN.S<-non.lin(OMEN[(NM+1):NK,],scale.s*KNOT.XI,scale.s*BOUN.XI)

	#calculate acceptance rate of MH algorithm of omega_i
	if(IDMUA==T)Ycen<-Y-MU
	if(NANA>0){Ycen<-Ycen-AD%*%AZ}
	r1<-log.likelihood(Ycen,LY,Omega,XIB[(ND+NM+1):NB,],BZ,inv.sqrt.PSX,PI.z,PB,BD,inv.sqrt.PSD,c.inv.PHI)
	r2<-log.likelihood(Ycen,LY,OMEN,nlN.S,BZ,inv.sqrt.PSX,PI.z,PB,BD,inv.sqrt.PSD,c.inv.PHI)
	r<-exp(0.5*(r1-r2))
	comr<-runif(N)
	crit<-(comr<r)
	Omega[,crit]<-OMEN[,crit]			##revised.
	AC.XI<-AC.XI+crit
	XIB[(ND+1):(ND+NM),crit]<-Omega[1:NM,crit]
	XIB[(ND+NM+1):NB,crit]<-nlN.S[1:NG,crit]

	#update MU
	if(IDMUA==T){
		calsm<-chol2inv(chol(diag(N*iPSX+rep(sigmu,NY))))
		Ycen<-Y-LY%*%Omega
		if(NANA>0){Ycen<-Ycen-AD%*%AZ}
		temp<-rowSums(Ycen)
		mumu<-calsm%*%(iPSX*temp+rep(sigmu,NY)*PMU)
		MU<-mvrnorm(1,mumu,Sig=calsm)
	}
	#update LY and PSX
	count.n<-1	
	for(j in 1:NY){
		subs<-(IDY[j,]==1)
		len<-length(LY[j,subs])
		Ycen<-Y[j,]-MU[j]
		if(NANA>0){Ycen<-Ycen-AD[j,]%*%AZ}
		Ycen<-Ycen-LY[j,(!subs),drop=F]%*%Omega[(!subs),,drop=F]
		Ycen<-as.vector(Ycen)
		alpha.star<-alpha.x[j]+N/2
		beta.star<-beta.x[j]+1/2*sum(Ycen^2)
	
		if(len>0){
			if(len==1){omesub=matrix(Omega[subs,],nrow=1)}
			if(len>1){omesub<-Omega[subs,]}
			PSiginv<-rep(sigly,len)
			Pmean<-PLY[j,subs]
			calsmnpsx<-chol2inv(chol((tcrossprod(omesub)+diag(PSiginv))))
      #LY posterior covariance matrix
			temp<-(omesub%*%Ycen+PSiginv*Pmean)
			LYnpsx<-calsmnpsx%*%temp
      #LY posterior mean
			beta.star<-beta.star+1/2*(sum(Pmean*(PSiginv*Pmean))-
				sum(temp%*%LYnpsx))
		}#end if
		iPSX[j]<-rgamma(1,shape=alpha.star,rate=beta.star)
		PSX[j]<-1/iPSX[j]
		if(len>0){
			LY[j,subs]<-mvrnorm(1,LYnpsx,Sig=(calsmnpsx*PSX[j]))
			if((gm>0)&&(gm%%nthin==0)){ELY[gm/nthin,count.n:(count.n+len-1)]<-LY[j,subs]}
			count.n<-count.n+len
		}#end if
	}#end j NY
		inv.sqrt.PSX<-sqrt(iPSX)
	

	#update AD
	if(NANA>0){
		count.n<-1
		for(j in 1:NY){
			subs<-(IDA[j,]==1)
			len<-length(AD[j,subs])
			if(len>0){
				PSiginv<-rep(sigsa,len)
				AZsub<-AZ[subs,,drop=F]
				Ycen<-as.vector(Y[j,]-MU[j]-LY[j,]%*%Omega)
				calsm<-chol2inv(chol((tcrossprod(AZsub)*iPSX[j]+diag(PSiginv))))
				ADmu<-calsm%*%(AZsub%*%Ycen*iPSX[j]+PSiginv*PAD[j,subs])
				AD[j,subs]<-mvrnorm(1,ADmu,Sig=calsm)
				if((gm>0)&&(gm%%nthin==0)){EAD[gm/nthin,count.n:(count.n+len-1)]<-AD[j,subs]}
				count.n<-count.n+len
			}#end if
		}
	}

	#update BI and PSD
	count.n<-1
	for(j in 1:NM){
		etacen<-Omega[j,,drop=FALSE]
		#update b_j
		if(ND>0){
			for(k in 1:ND.BZ){
				bzsub<-ss.BZ[1:NSD.BZ[k],k]
  				etacen1<-etacen-BI[j,-bzsub,drop=F]%*%XIB[-bzsub,,drop=FALSE]
        			if(NKN.BZ[k]>0){
	        			PSiginv<-PMS.BZ[k,1:NSD.BZ[k],1:NSD.BZ[k]]
          			calsmnpsd<-chol2inv(chol(iPSD[j]*BZ2[bzsub,bzsub]+PSiginv/plam.BZ[k]))
          			temp<-iPSD[j]*tcrossprod(BZ[bzsub,],etacen1)
          			IBnsp<-calsmnpsd%*%temp
          			IB.tmp<-mvrnorm(1,IBnsp,Sig=(calsmnpsd))
          			Q<-BZS[1,bzsub,drop=FALSE]
          			SQt<-tcrossprod(calsmnpsd,Q)
          			H<-SQt%*%chol2inv(chol(Q%*%SQt))%*%Q
          			BD[j,bzsub]<-BI[j,bzsub]<-IB.tmp-H%*%IB.tmp
        			}#if NKN.BZ>0                                        
		  	}#k 1 ND.BZ
		}#if ND>0

		#update beta_j and s_j
		subs<-(IDB[j,]==1)
		len<-length(IB[j,subs])
		alpha.star.d<-alpha.d[j]+N/2
		if(len>0){
			for(k in 1:NG.XI){
				xisub<-ss.XI[1:NSD.XI[k],k]
				etacen1<-etacen-BI[j,-xisub,drop=F]%*%XIB[-xisub,,drop=FALSE]
  			n.scale.s<-scale.s
      	u.int<-runif(1)
      	pos.rw<-function(x,u=u.int){
	        		return(((x-int.l.s[k])+log(int.r.s[k]*x)-
        			u*((int.r.s[k]-int.l.s[k])+2*log(int.r.s[k])))^2)
	     	}
      	f.s<-optimize(pos.rw,c(int.r.s[k],int.l.s[k]))$minimum
      	n.scale.s[k]=scale.s[k]*f.s
				PSiginv<-PMS.XI[k,1:NSD.XI[k],1:NSD.XI[k]]
				nlN.S<-non.lin.1(Omega[(NM+k),],n.scale.s*KNOT.XI,n.scale.s*BOUN.XI,k)
      	ch.cm1<-chol((iPSD[j]*tcrossprod(nlN.S)+PSiginv/plam.XI[k]))
				calsmnpsd<-chol2inv(ch.cm1)
				temp<-iPSD[j]*tcrossprod(nlN.S,etacen1)
				IBnsp<-calsmnpsd%*%temp
				IB.tmp<-mvrnorm(1,IBnsp,Sig=(calsmnpsd))
				Q<-tcrossprod(matrix(rep(1,N),nrow=1),nlN.S)
				SQt<-tcrossprod(calsmnpsd,Q)
				H<-SQt%*%chol2inv(chol(Q%*%SQt))%*%Q
				IB.cor<-IB.tmp-H%*%IB.tmp
				t.new<-(-1)*log(prod(diag(ch.cm1)))+0.5*crossprod(temp,IBnsp)-
        				0.5*sum((log(abs(n.scale.s[k]*ALL.KNOT.XI[k,1:NSD.XI[k]])))^2)/plam.s[k]
        
      	ch.cm1<-chol((iPSD[j]*tcrossprod(XIB[xisub,])+PSiginv/plam.XI[k]))
				calsmnpsd<-chol2inv(ch.cm1)
				temp<-iPSD[j]*tcrossprod(XIB[xisub,],etacen1)
				IBnsp<-calsmnpsd%*%temp			
				t.cur<-(-1)*log(prod(diag(ch.cm1)))+0.5*crossprod(temp,IBnsp)-
				       0.5*sum((log(abs(scale.s[k]*ALL.KNOT.XI[k,1:NSD.XI[k]])))^2)/plam.s[k]
      
      	if(runif(1)<exp(t.new-t.cur)){
        		BI[j,xisub]<-IB.cor
        		scale.s[k]<-n.scale.s[k]
        		XIB[xisub,]<-nlN.S
        		AC.beta[k]<-AC.beta[k]+1
        		if(gm>0){AC.beta.ab[k]<-AC.beta.ab[k]+1}
      	}       	                                  
			}#k 1 NG.XI
		}#end if len>0		

		#update psi_delta
		beta.star.d<-beta.d[j]+0.5*sum((Omega[j,]-BI[j,,drop=FALSE]%*%XIB)^2)
		iPSD[j]<-rgamma(1,shape=alpha.star.d,rate=beta.star.d)

		#update tau_beta
		for(k in 1:NG.XI){
			beta.star.p.XI<-beta.plam.XI+0.5*sum((PMS.XI[k,1:NSD.XI[k],1:NSD.XI[k]]%*%BI[j,ss.XI[1:NSD.XI[k],k]])*BI[j,ss.XI[1:NSD.XI[k],k]])
			alpha.star.p.XI<-alpha.plam.XI+(NSD.XI[k]-1)/2
			plam.XI[k]<-1/rgamma(1,shape=alpha.star.p.XI,rate=beta.star.p.XI)
		}

		#update tau_s
		for(k in 1:NG.XI){
			beta.s.p<-beta.s+0.5*sum((log(abs(scale.s[k]*ALL.KNOT.XI[k,1:NSD.XI[k]])))^2)	
    			plam.s[k]<-1/rgamma(1,shape=alpha.s+NSD.XI[k]/2,rate=beta.s.p)
		}
		
		#update tau_b
		for(k in 1:ND.BZ){
			beta.star.p.BZ<-beta.plam.BZ+0.5*sum((PMS.BZ[k,1:NSD.BZ[k],1:NSD.BZ[k]]%*%BI[j,ss.BZ[1:NSD.BZ[k],k]])*BI[j,ss.BZ[1:NSD.BZ[k],k]])
			alpha.star.p.BZ<-alpha.plam.BZ+(NSD.BZ[k]-1)/2
			plam.BZ[k]<-1/rgamma(1,shape=alpha.star.p.BZ,rate=beta.star.p.BZ)
 		}
	}#end j NM
	
	PSD<-1/iPSD
	inv.sqrt.PSD<-sqrt(iPSD)
	
	if(ND>0){BD<-matrix(BI[,1:ND],nrow=NM)}
	if(NM>0){PI<-matrix(BI[,(ND+1):(ND+NM)],nrow=NM)}
	if(NG>0){PB<-matrix(BI[,(ND+NM+1):NB],nrow=NM)}	

	#update PHI
	inv.PHI<-rwish(rou.zero+N, solve(tcrossprod(Omega[(NM+1):NK,,drop=F])+R.zero))  
	PHI<-chol2inv(chol(inv.PHI))
	c.inv.PHI<-chol(inv.PHI)

	if((gm>0)&&(gm%%nthin==0)){
		gm<-gm/nthin
		EPHI[gm,]<-as.vector(PHI)
		EPSD[gm,]<-PSD
		EPSX[gm,]<-PSX
		EMU[gm,]<-MU
		Eplam.BZ[gm,]<-plam.BZ
		Eplam.XI[gm,]<-plam.XI
		Escale[gm,]<-as.vector(scale.s)
		Eplam.s[gm,]<-as.vector(plam.s)            
		for(k in 1:NG.XI){
			temp<-ns(xx,knots=scale.s[k]*KNOT.XI[k,1:NKN.XI[k]],
             		intercept=TRUE,Bou=scale.s[k]*BOUN.XI[k,])%*%
				PB[1,fst.LOC.XI[k]:(fst.LOC.XI[k]+NSD.XI[k]-1)]
			EXIF[gm,k,]<-temp
    		}
    		for(k in 1:ND.BZ){
      		temp<-Bzz[k,,1:NSD.BZ[k]]%*%BD[1,fst.LOC.BZ[k]:(fst.LOC.BZ[k]+NSD.BZ[k]-1)]
        		EBZF[gm,k,]<-temp
    		}    
      	EXI[gm,,]<-Omega[(NM+1):NK,]
	}
	
if(g%%1000==0)print(g)
}#end of g MCMAX

