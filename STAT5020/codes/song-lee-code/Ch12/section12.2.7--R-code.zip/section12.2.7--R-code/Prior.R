######Hyperparameter of prior distribution.

#Measurement equation.

#Prior mean of Lambda
PLY<-matrix(c(
1,0,0,0,
0.0,0,0,0,
0.0,0,0,0,
0,1,0,0,
0,0.0,0,0,
0,0.0,0,0,
0,0,1,0,
0,0,0.0,0,
0,0,0.0,0,
0,0,0,1,
0,0,0,0.0,
0,0,0,0.0
),ncol=NK,byr=T)

PMU<-rep(0,NY)		#Prior mean of Mu
PAD<-array(rep(0,NY*NANA),dim=c(NY,NANA))	#Prior mean of A
					

alpha.x<-rep(9,NY)	#alpha_j0 
beta.x<-rep(4,NY)		#beta_j0
sigly<-1				#inverse prior variance of free elements in Lambda
sigmu<-1				#inverse prior variance of Mu
sigsa<-1				#inverse prior variance of A

#Structural equation

rou.scale<-3			
rou.zero<-rou.scale+NZ+1	#rho_0, hyperparameters of Wishart distribution

R.zero<-rou.scale*diag(1,NZ)	#matrix R_0, hyperparameters of Wishart distribution
alpha.d<-rep(9,NM)		#alpha_delta0
beta.d<-rep(4,NM)			#beta_delta0
alpha.plam.BZ<-1			#alpha_b0
beta.plam.BZ<-0.005		#beta_b0
alpha.plam.XI<-1			#alpha_beta0
beta.plam.XI<-0.005		#beta_beta0
alpha.s<-1				#alpha_tau0
beta.s<-0.005				#beta_tau0
