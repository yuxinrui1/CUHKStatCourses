#####Parameter in measurement equation

#Initial value of Lambda, 
LY<-matrix(c(
1,0,0,0,
1,0,0,0,
1,0,0,0,
0,1,0,0,
0,1,0,0,
0,1,0,0,
0,0,1,0,
0,0,1,0,
0,0,1,0,
0,0,0,1,
0,0,0,1,
0,0,0,1
),ncol=NK,byr=T)


MU<-rep(1,NY)								#initial value of Mu
AD<-array(rep(0.6,NY*NANA),dim=c(NY,NANA))	#initial value of A

#####Parameter in structural equation
plam.BZ<-rep(0.5,ND.BZ)		#initial value of tau_b
plam.XI<-rep(0.5,NG.XI)		#initial value of tau_beta	
plam.s<-rep(0.5,NG.XI)		#initial value of tau_s
scale.s<-rep(0.5,NG.XI)		#initial value of s

	#####initial value of coefficients in structural equation 
	PB<-matrix(rep(0.2,NM*NG),ncol=NG,byr=T)	#initial value of beta_j
	PI<-matrix(rep(0,NM*NM),ncol=NM,byr=T)		#fixed at zero.
	IB<-cbind(PI,PB)				
	BD<-array(rep(-2,NM*ND),dim=c(NM,ND))		#initial value of b_j
	BI<-cbind(BD,IB)

PSD<-rep(0.1,NM)					#initial value of psi_delta
PSX<-rep(0.1,NY)					#initial value of psi_j

PHI<-matrix(0.1,nrow=NZ,ncol=NZ)
diag(PHI)<-0.5					#initial value of Phi


#####Automatic part.
inv.PHI=chol2inv(chol(PHI))			#initial value of Phi^(-1)
c.inv.PHI<-chol(inv.PHI)			#initial value of Phi^(-1/2)
iPSX<-1/PSX						#initial value of 1/psi_j
iPSD<-1/PSD						#initial value of 1/psi_delta
inv.sqrt.PSX<-1/sqrt(PSX)			#initial value of sqrt(1/psi_j)
inv.sqrt.PSD<-1/sqrt(PSD)			#initial value of sqrt(1/psi_delta)
if(IDMUA==F)MU<-rep(0,NY)