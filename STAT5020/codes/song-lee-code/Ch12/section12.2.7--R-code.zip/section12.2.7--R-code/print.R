print(paste(c("Factor loading Lambda based on ", CNUM, " replications:"),collapse=""))
EE=colMeans(EmLY)
SE=colMeans(SELY)

k=1
for(i in 1:NY){
	for(j in 1:NK){
		if(IDY[i,j]!=0){
			print(paste(c("Estimates of lambda_{",i,",",j,"} is: ",EE[k]," (",SE[k],")"),collapse=""))
			k=k+1
		}
	}
}

if(NANA>0){
print(paste(c("Covariates coefficients A based on ", CNUM, " replications:"),collapse=""))
EE=colMeans(EmAD)
SE=colMeans(SEAD)
k=1
for(i in 1:NY){
	for(j in 1:NANA){
		if(IDY[i,j]!=0){
			print(paste(c("Estimates of a_{",i,",",j,"} is: ",EE[k]," (",SE[k],")"),collapse=""))
			k=k+1
		}
	}
}
}

print("Mean in measurement equations:")
print(paste(c("estimates based on ", CNUM, " replications:"),collapse=""))
print(colMeans(EmMU))
print(paste(c("Standard errors based on ", CNUM, " replications:"),collapse=""))
print(colMeans(SEMU))

print("error variance in measurement equations:")
print(paste(c("estimates based on ", CNUM, " replications:"),collapse=""))
print(colMeans(EmPSX))
print(paste(c("Standard errors based on ", CNUM, " replications:"),collapse=""))
print(colMeans(SEPSX))

print("error variance in structural equations:")
print(paste(c("estimates based on ", CNUM, " replications:"),collapse=""))
print(colMeans(EmPSD))
print(paste(c("Standard errors based on ", CNUM, " replications:"),collapse=""))
print(colMeans(SEPSD))

print("Covariance matrix in latent variables xi:")
print(paste(c("estimates based on ", CNUM, " replications:"),collapse=""))
print(colMeans(EmPHI))
print(paste(c("Standard errors based on ", CNUM, " replications:"),collapse=""))
print(colMeans(SEPHI))