R version 2.8.1 or after. Package 'msm' and 'MCMCpack' are used.
*************************
LIST OF R FUNCTION
******************

main.R		---- main program
def_con.R	---- Define constant.
def_rec.R	---- Allocation of computation variables.
function.R	---- Define some functions used in main.R.
Gibbs.R	---- Details of Gibbs sampler steps.
ind.R		---- Define value concerning model identification.
init1.R		---- Set initial value.
Prior.R		---- Set hyperparameters of prior distribution.
read_initial.R	---- Read data.
print.R           ---- Output parametric parameters.
plot.R            ---- Plot estimated curves.
*****
USAGE
*****

step 1: In def_con.R, 	change constant according to model.
step 2: In ind.R, 	change identification variable according to model specification.
step 3: In Prior.R, 	change hyperparameters according to prior input.
step 4: In init1.R,	change initial value of parameters.
step 5: In read_initial.R
			change the source of data input.
step 6: Run the main.R.
step 7: Run the print.R.
step 8: In the plot.R, there are two parts. 
		The first in if(CNUM>1){} is for simulation 
		which usually contains more than one replication.

		The second in if(CNUM==1){} is for readdata
		which usually contains only one replication.


*******
Results
*******
Graph are ploted to some jpeg file. Name of functions of covariates begin with g. 
Name of functions of latent variables begin with f.

