if(!require(MCMCpack))
install.packages(pkgs="MCMCpack",repos="http://cran.r-project.org")
if(!require(msm))
install.packages(pkgs="msm",repos="http://cran.r-project.org")

library(stats)
library(MASS)
library(MCMCpack)
library(splines)
library(msm)
source("function.R")

set.seed(1)

source("def_con.R")
source("Prior.R")
source("ind.R")

source("def_rec.R")

Npart=1:CNUM

for(CIR in Npart){
source("read_initial.R")

source("Gibbs.R")

EmLY[CIR,]=apply(ELY,FUN=mean,MAR=c(2))
EmMU[CIR,]=apply(EMU,FUN=mean,MAR=c(2))
EmAD[CIR,]=apply(EAD,FUN=mean,MAR=c(2))
EmPSD[CIR,]=apply(EPSD,FUN=mean,MAR=c(2))
EmPSX[CIR,]=apply(EPSX,FUN=mean,MAR=c(2))
EmPHI[CIR,]=apply(EPHI,FUN=mean,MAR=c(2))
Emplam.BZ[CIR,]=apply(Eplam.BZ,FUN=mean,MAR=c(2))
Emplam.XI[CIR,]=apply(Eplam.XI,FUN=mean,MAR=c(2))
Emscale[CIR,]=apply(Escale,FUN=mean,MAR=c(2))
Emplam.s[CIR,]=apply(Eplam.s,FUN=mean,MAR=c(2))
EmXI[CIR,,]=apply(EXI,FUN=mean,MAR=c(2,3))
EmXIF[CIR,,]=apply(EXIF,FUN=mean,MAR=c(2,3))
EmBZF[CIR,,]=apply(EBZF,FUN=mean,MAR=c(2,3))

SELY[CIR,]=apply(ELY,FUN=sd,MAR=c(2))
SEMU[CIR,]=apply(EMU,FUN=sd,MAR=c(2))
SEAD[CIR,]=apply(EAD,FUN=sd,MAR=c(2))
SEPSD[CIR,]=apply(EPSD,FUN=sd,MAR=c(2))
SEPSX[CIR,]=apply(EPSX,FUN=sd,MAR=c(2))
SEPHI[CIR,]=apply(EPHI,FUN=sd,MAR=c(2))

print(CIR)
}#end of GIBs


#source("plot.R")