#########Revise the parts below according to dimension of measurement equation.

#Matrix indicating whether each element in Lambda is free(1) or fixed(0) 
IDY<-matrix(c(
0,0,0,0,
1,0,0,0,
1,0,0,0,
0,0,0,0,
0,1,0,0,
0,1,0,0,
0,0,0,0,
0,0,1,0,
0,0,1,0,
0,0,0,0,
0,0,0,1,
0,0,0,1
),ncol=NK,byr=T)

#vector indicating whether Mu should be added to each measurement equation or not. 
#Added(1), remove(0).
IDMU<-rep(1,NY)
IDMUA<-any(as.logical(IDMU))

######################### The parts below are automatically done. No need to change.
IDA<-array(1,dim=c(NY,NANA))
IDB<-array(c(rep(0,NM),rep(1,NG)),dim=c(NM,NM+NG))
IDBD<-array(1,dim=c(NM,ND))
IDSE<-cbind(IDBD,IDB)
