#####read y_i, x_i, c_i. 

Y[,]<-matrix(scan("Y.txt",skip=(CIR-1)*N,nlines=N,sep=","),nrow=NY,ncol=N)			
#read Y. Dimension is NY*N, each row contains n samples of one response variable.

BZ.ori<-matrix(scan("BZori.txt"),nrow=ND.BZ,ncol=N)	
#read x_j. Dimension is ND.BZ*N, each row contains n samples of one covariate in structural equation.

if(NANA>0)AZ<-matrix(scan("AZ.txt",skip=(CIR-1)*N,nlines=N),nrow=NANA,ncol=N)			
#read c_i. Dimension is NANA*N, each row contains n samples of one covariate in measurement equation.


source("init1.R")											
#input initial value of parameters

#####Automatic done below.
BZ<-matrix(nrow=ND,ncol=N)
if(ND>0)XIB[1:ND,]<-BZ[1:ND,1:N]<-non.lin.bz(BZ.ori)
BZ2<-tcrossprod(BZ)
BZS<-matrix(rowSums(BZ),nrow=1)

zz<-matrix(0,nrow=ND.BZ,ncol=lzz)
Bzz<-array(0,dim=c(ND.BZ,lzz,max(NSD.BZ)))
for(k in 1:ND.BZ){
zz[k,]<-seq(min(BZ.ori[k,]),max(BZ.ori[k,]),length=lzz)
Bzz[k,,1:NSD.BZ[k]]<-bs(zz[k,],knots=seq(min(BZ.ori[k,]),max(BZ.ori[k,]),
                      length=NKN.BZ[k]+2)[-c(1,NKN.BZ[k]+2)]
                      ,int=T,Bou=c(min(BZ.ori[k,]),max(BZ.ori[k,])))
}

#####generate initial value for parameters and latent variables.
xi<-t(mvrnorm(N,rep(0,NZ),Sigma=PHI))		#generate xi
Omega[((NM+1):NK),]<-xi
XIB[(ND+NM+1):NB,]<-Fxi<-non.lin(xi,scale.s*KNOT.XI,scale.s*BOUN.XI) #generate N_j(xi_j)

bdzs<-matrix(0,nrow=NM,ncol=N)
if(ND>0){bdzs<-BD%*%BZ}
muxi<-(PB%*%Fxi+bdzs)

for(j in 1:NM){Omega[j,]<-rnorm(N,muxi[j,],sqrt(PSD[j]))}
XIB[(ND+1):(ND+NM),]<-Omega[1:NM,]<-chol2inv(chol(diag(1,NM)-PI))%*%Omega[1:NM,]

#check whether input procedure is right
write(Y,file="yr.txt",ncol=NY,append=T)				
if(ND>0){
	write(BZ.ori,file="BZr.txt",ncol=ND.BZ,append=T)
	write(BZ,file="BZspr.txt",ncol=ND.BZ,append=T)
}
if(NANA>0)write(AZ,file="AZr.txt",ncol=NANA,append=T)
