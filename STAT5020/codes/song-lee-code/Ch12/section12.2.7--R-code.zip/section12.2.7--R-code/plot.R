if(CNUM>1){
########change############
quan.n<-c(0.05,0.5,0.95)

########change end############


for(k in 1:NG.XI){
qu<-matrix(0,nrow=3,ncol=lxx)
for(l in 1:lxx){
qu[,l]<-quantile(EmXIF[,k,l],prob=quan.n)
}
jpeg(paste(c("f",k,".jpeg"),collapse=""))
plot(c(min(xx)-0.5,max(xx)+0.5),
  c(min(qu[1,]),max(qu[3,])),type="n")

lines(xx,qu[1,],lty=4)
lines(xx,qu[2,],lty=2)
lines(xx,qu[3,],lty=4)
dev.off()
}

#IF the the covariates has been standardized, put the mean and sd in me and std.

me<-rep(0,ND.BZ)
std<-rep(1,ND.BZ)
for(k in 1:ND.BZ){
qu<-matrix(0,nrow=3,ncol=lzz)
for(l in 1:lzz){
qu[,l]<-quantile(EmBZF[,k,l],prob=quan.n)
}
jpeg(paste(c("g",k,".jpeg"),collapse=""))
plot(c(min(std[k]*zz[k,]+me[k])-0.5,max(std[k]*zz[k,]+me[k])+0.5),
  c(min(EmBZF[,k,]),max(EmBZF[,k,])),type="n")
temp<-std[k]*zz[k,]+me[k]

lines(temp,qu[1,],lty=4)
lines(temp,qu[2,],lty=2)
lines(temp,qu[3,],lty=4)
dev.off()
}
}#if(CNUM>1)







if(CNUM==1){

########change############
me<-c(64.14,72.47)		#sample mean of x_j 
std<-c(9.33,4.96)			#sample standard deviation of x_j
tit<-c("","")				#title of graph of g_j(x_j)

quan.n<-c(0.05,0.5,0.95)	#Pointwise quantiles

########change end############




###############done
if(length(tit)!=ND.BZ){
tit<-rep("",ND.BZ)
print("Not correct number of labels for g_j(x_j)")
}
for(k in 1:ND.BZ){
jpeg(paste(c("g",k,".jpeg"),collapse=""))
qu<-matrix(0,nrow=3,ncol=lzz)
for(l in 1:lzz){
qu[,l]<-quantile(EBZF[,k,l],prob=quan.n)
}
ma<-(max(qu[3,])-min(qu[1,]))/5
plot(c(min(std[k]*zz[k,]+me[k])-0.5,max(std[k]*zz+me[k])+0.5),
  c(min(qu[1,])-ma,max(qu[3,])+ma),main=tit[k],type="n")
lines(std[k]*zz[k,]+me[k],qu[1,],lty=2)
lines(std[k]*zz[k,]+me[k],qu[2,],lty=3)
lines(std[k]*zz[k,]+me[k],qu[3,],lty=4)
dev.off()
}
###############end done


tit<-c("","","","")	#title of graph of f_j(xi_j)

####################done
if(length(tit)!=NG.XI){
tit<-rep("",NG.XI)
print("Not correct number of labels for f_j(xi_j)")
}
xrange<-list()
length(xrange)=NG.XI
for(k in 1:NG.XI){
xrange[[k]]=(abs(xx)<=3*sqrt(EmPHI[1,k+(k-1)*NG.XI]))
qu<-matrix(0,nrow=3,ncol=lxx)
for(l in 1:lxx){
qu[,l]<-quantile(EXIF[,k,l],prob=quan.n)
}
jpeg(paste(c("f",k,".jpeg"),collapse=""))

ma<-(max(qu[3,])-min(qu[1,]))/5

plot(c(min(xx[xrange[[k]]])-0.5,max(xx[xrange[[k]]])+0.5),
  c(min(qu[1,xrange[[k]]])-ma,max(qu[3,xrange[[k]]])+ma),main=tit[k],type="n")
lines(xx[xrange[[k]]],qu[1,xrange[[k]]],lty=2)
lines(xx[xrange[[k]]],qu[2,xrange[[k]]],lty=3)
lines(xx[xrange[[k]]],qu[3,xrange[[k]]],lty=4)
dev.off()
}
}#if(CNUM==1)
####################end done

