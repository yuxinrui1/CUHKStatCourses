N<-300				#sample size.(n)
NY<-12				#number of observed variables.(p)
#The program is for NM=1 only.
NM<-1					#dimension of eta.(q_1)
						#Note: The program is for q_1=1, please refer to the paper.

NZ<-3					#dimension of xi.(q_2)
NK<-NM+NZ				#dimension.(q)
NANA<-0					#dimension of covariate(c_i) in ME.

NKN.XI<-c(20,20,20)		#number of knots of B-spline basis of natural cubic spline.(K_j-2)
NSD.XI<-NKN.XI+2			#number of B-spline basis function of natural cubic spline.(K_j)
NG.XI<-length(NKN.XI)		#number of additive functions of xi.(q_2)
NG<-sum(NSD.XI)			#total number of basis function of natural cubic spline.(sum_j(K_j))

NKN.BZ<-c(20)			#number of knots of B spline basis of functions of each element of x.(K_bd-4)
NSD.BZ<-NKN.BZ+4			#number of B-spline basis of each element of x.(K_bd)
ND.BZ<-length(NSD.BZ)		#number of additive functions of c.(D)
ND<-sum(NSD.BZ)			#number of additive functions.(sum_d(K_bd))
NB<-ND+NM+NG			    #total number of splines in structural equation.

CNUM<-1					#number of replication
N.burn<-20000				#number of burn-in MCMC samples. Discarded
MCMAX<-40000				#number of MCMC samples for inference.
nthin<-1				#pick a sample for inference every nthin samples.

VAR1<-1					#control acceptance rate for omega, sigam^2_omega

int.r.s<-c(1.45,1.2,1.35)		#C, tuning parameters of s_j in MH algorithm
int.l.s<-1/int.r.s		#1/C

xx<-seq(-3.0,3.0,by=0.15)	#location to evaluate f_j(xi_j) for graph
lxx<-length(xx)			
lzz<-30					#number of location to evaluate g_j(x_j) 


########Automatic done
fst.LOC.XI<-matrix(c(1),nrow=NM,ncol=NZ)
j=2
while(j<=NG.XI){
fst.LOC.XI[j]=sum(NSD.XI[1:(j-1)])+1
j=j+1
}
					#When putting all B-spline basis functions of natural cubic spline 
					#of all elements of xi in one big matrix, this marks the first column 
					#of the set of basis function related to  the same element of xi.
fst.LOC.BZ<-matrix(c(1),nrow=NM,ncol=ND.BZ)
j=2
while(j<=ND.BZ){
fst.LOC.BZ[j]=sum(NSD.BZ[1:(j-1)])+1
j=j+1
}

					#When putting all B-spline basis functions  
					#of all elements of c in one big matrix, this marks the first column 
					#of the set of basis function related to  the same element of c.
