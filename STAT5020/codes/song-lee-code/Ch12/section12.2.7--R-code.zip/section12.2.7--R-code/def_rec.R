############################## Automatic done
Y<-array(0,dim=c(NY,N))				#Observe data
xi<-array(dim=c(NZ,N))				#independent latent variable xi
eta<-array(dim=c(NM,N))				#dependent latent variable eta
TUE<-Omega<-array(dim=c(NK,N))		#latent variable omega
XIB<-array(dim=c(NB,N))				#All basis in structural equation.

NMU<-sum(IDMU)					#Number of Mu in measurement equation.
NLY<-sum(IDY)						#Number of free lambda in Lambda.
NAD<-sum(IDA)						#Number of free a in A.
NBD<-sum(IDBD)					#Number of coefficients of basis of covariates in structural equation.
NPIBI<-sum(IDB)					#Number of coefficients of basis of latent variables in structural equation.
Nrec<-(MCMAX-N.burn)/nthin			#Number of samples after burn-in.

EMU<-array(0,dim=c(Nrec,NMU))			#Store retained trace of Mu
ELY<-array(0,dim=c(Nrec,NLY))			#Store retained trace of Lambda
EAD<-array(0,dim=c(Nrec,NAD))			#Store retained trace of A
EPSX<-array(0,dim=c(Nrec,NY))			#Store retained trace of psi_j
EPSD<-array(0,dim=c(Nrec,NM))			#Store retained trace of psi_delta
EPHI<-array(0,dim=c(Nrec,(NZ*NZ)))		#Store retained trace of Phi
Eplam.BZ<-array(0,dim=c(Nrec,ND.BZ))	#Store retained trace of tau_b
Eplam.XI<-array(0,dim=c(Nrec,NG.XI))	#Store retained trace of tau_beta
Escale<-array(0,dim=c(Nrec,NG.XI))		#Store retained trace of s
Eplam.s<-array(0,dim=c(Nrec,NG.XI))	#Store retained trace of tau_s
EXI<-array(0,dim=c(Nrec,NZ,N))			#Store retained trace of xi
EXIF<-array(0,dim=c(Nrec,NZ,lxx))		#Store retained trace of f_j(xi_j)
EBZF<-array(0,dim=c(Nrec,ND.BZ,lzz))	#Store retained trace of g_j(x_j)


EmMU<-array(0,dim=c(CNUM,NMU))				#Store estimates of Mu 
EmLY<-array(0,dim=c(CNUM,NLY))				#Store estimates of Lambda 
EmAD<-array(0,dim=c(CNUM,NAD))				#Store estimates of A
EmPSX<-array(0,dim=c(CNUM,NY))				#Store estimates of psi_j 
EmPSD<-EPI<-array(0,dim=c(CNUM,NM))		#Store estimates of psi_delta
EmPHI<-array(0,dim=c(CNUM,(NZ*NZ)))		#Store estimates of Phi
Emplam.BZ<-array(0,dim=c(CNUM,ND.BZ))		#Store estimates of tau_b
Emplam.XI<-array(0,dim=c(CNUM,NG.XI))		#Store estimates of tau_beta
Emscale<-array(0,dim=c(CNUM,NG.XI))		#Store estimates of s 
Emplam.s<-array(0,dim=c(CNUM,NG.XI))		#Store estimates of tau_s
EmXI<-array(0,dim=c(CNUM,NZ,N))			#Store estimates of xi
EmXIF<-array(0,dim=c(CNUM,NZ,lxx))			#Store estimates of f_j(xi_j)
EmBZF<-array(0,dim=c(CNUM,ND.BZ,lzz))		#Store estimates of g_j(x_j)


SEMU<-array(0,dim=c(CNUM,NMU))		#Store standard error of estimates of Mu 
SELY<-array(0,dim=c(CNUM,NLY))		#Store standard error of estimates of Lambda
SEAD<-array(0,dim=c(CNUM,NAD))		#Store standard error of estimates of A
SEPSX<-array(0,dim=c(CNUM,NY))		#Store standard error of estimates of psi_j
SEPSD<-array(0,dim=c(CNUM,NM))		#Store standard error of estimates of psi_delta
SEPHI<-array(0,dim=c(CNUM,(NZ*NZ)))#Store standard error of estimates of Phi


AC.XI<-integer(N)					#MH acceptance rate of xi
AC.K<-rep(0,NG.XI)				
AC.beta<-rep(0,NG.XI)				#MH acceptance rate of block beta_j and s_j

AC.XI.ab<-integer(N)				#MH acceptance rate of xi after burn-in
AC.K.ab<-rep(0,NG.XI)
AC.beta.ab<-rep(0,NG.XI)			#MH acceptance rate of block beta_j and s_j after burn-in

KNOT.XI<-matrix(0,nrow=NZ,ncol=max(NKN.XI))		#interior knots of natural cubic spline basis for f_j(xi_j)
BOUN.XI<-matrix(0,nrow=NZ,ncol=2)				#Boundary knots of natural cubic spline basis for f_j(xi_j)
ALL.KNOT.XI<-matrix(0,nrow=NZ,ncol=max(NKN.XI)+2)	#All knots of natural cubic spline basis for f_j(xi_j)
for(k in 1:NG.XI){
ALL.KNOT.XI[k,1:(NKN.XI[k]+2)]<-qnorm(seq(0.001,0.999,length=NKN.XI[k]+2))
KNOT.XI[k,1:NKN.XI[k]]<-ALL.KNOT.XI[k,1:(NKN.XI[k]+2)][-c(1,NKN.XI[k]+2)]
BOUN.XI[k,]<-ALL.KNOT.XI[k,c(1,NKN.XI[k]+2)]
}											#initialize.

ss.XI<-matrix(0,nrow=max(NKN.XI)+2,ncol=NZ)		#subscript of coefficient beta_j in structural equation.
for(k in 1:NG.XI){
		ss.XI[1:NSD.XI[k],k]<-NM+ND+seq(fst.LOC.XI[k],by=1,length=NSD.XI[k])
}											#Assignemt of subscript.

if(is.null(NSD.BZ)){tn<-1}
if(!is.null(NSD.BZ)){tn<-max(NSD.BZ)}
ss.BZ<-matrix(0,nrow=tn,ncol=ND.BZ)			#subscript of random loading.
for(k in 1:ND.BZ){
ss.BZ[1:NSD.BZ[k],k]<-seq(fst.LOC.BZ[k],by=1,length=NSD.BZ[k])
}											#Assignemt of subscript.

PMS.BZ<-array(0,dim=c(ND.BZ,max(NSD.BZ),max(NSD.BZ)))
PMS.XI<-array(0,dim=c(NG.XI,max(NSD.XI),max(NSD.XI)))

for(k in 1:ND.BZ)PMS.BZ[k,1:NSD.BZ[k],1:NSD.BZ[k]]<-Pen.Mat(NSD.BZ[k])
for(k in 1:NG.XI)PMS.XI[k,1:NSD.XI[k],1:NSD.XI[k]]<-Pen.Mat(NSD.XI[k])
