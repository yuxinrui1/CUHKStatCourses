############self defined function#############

#generate B-spline basis for natural cubic spline for each element in xi_i.
non.lin<-function(xi,K,B){
	nxi<-matrix(0,nrow=NG,ncol=N)
  	for(nlk in 1:NG.XI){
		nxi[(fst.LOC.XI[nlk]):(fst.LOC.XI[nlk]+NSD.XI[nlk]-1),]<-
		t(ns(xi[nlk,],knots=K[nlk,1:NKN.XI[nlk]],intercept=TRUE,Bou=B[nlk,]))    
	}
	return(nxi)
}

#generate B-spline basis to model function of covariates.
non.lin.bz<-function(bz){
	bzs<-matrix(0,nrow=ND,ncol=N)
	fst<-1
	for(bzm in 1:ND.BZ){
		knot<-seq(min(bz[bzm,]),max(bz[bzm,]),length=NKN.BZ[bzm]+2)[-c(1,NKN.BZ[bzm]+2)]
		bzs[fst:(fst+NSD.BZ[bzm]-1),]<-t(bs(bz[bzm,],knots=knot,int=TRUE))
		fst<-fst+NSD.BZ[bzm]
	}
	return(bzs)
}

#generate B-spline basis for natural cubic spline for each element in xi_i.
non.lin.1<-function(xi,K,B,fn){
	nxi<-t(ns(xi,knots=K[fn,1:NKN.XI[fn]],intercept=TRUE,Bou=B[fn,]))
	return(nxi)
}

#function fsd calculated Delta in MH algorithm of omega_i
fstd<-function(x,ng,nz,K,B){
	d<-matrix(0,ng,nz)
	for(fk in 1:NG.XI){
		d[(fst.LOC.XI[fk]):(fst.LOC.XI[fk]-1+NSD.XI[fk]),fk]<-
		as.vector(ns(x[fk]+0.01,knots=K[fk,1:NKN.XI[fk]],intercept=TRUE,Bou=B[fk,])-
		ns(x[fk],knots=K[fk,1:NKN.XI[fk]],intercept=TRUE,Bou=B[fk,]))/0.01
	}
	return(d)
}

#calculate the log likelihood of complete data({y_i},{c_i},{z_i},{omega_i})
log.likelihood<-function(y,ly,omega,fxi,bz,ispsx,piz,gam,bd,ispsd,ciphi){
	log.like1<-colSums((ispsx*(y-ly%*%omega))^2)
	
	if(ND==0)temp<-ispsd*(piz%*%omega[1:NM,]-gam%*%fxi)
	if(ND>0)temp<-ispsd*(piz%*%omega[1:NM,]-gam%*%fxi-bd%*%bz)

	log.like2<-colSums(temp^2)

	log.like3<-colSums((ciphi%*%omega[(NM+1):NK,])^2)

	return(log.like1+log.like2+log.like3)
}

#calculate penalty matrix M
Pen.Mat<-function(d,loc=rep(1,d-ord),ord=2){
  if(ord==1){	
	P<-diag(-1,nrow=d-1,ncol=d)
  diag(P[,2:d])<-1
	}
  if(ord==2){
	P<-diag(1,nrow=d-2,ncol=d)
	diag(P[,-1])<-(-2)
	diag(P[,-(1:2)])<-1
	}
  P<-crossprod(P,loc*P)  
	return(P)
}    



