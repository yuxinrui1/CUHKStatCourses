library(splines)
Ni<-100
MCMAX2<-MCMAX1-N.burn
NYind<-which(ind.y==0)
ma<-mi<-numeric(NY)
quant<-array(0,dim=c(NY,3,Ni))
trac<-numeric(MCMAX2)
for(j in NYind){
ma[j]<-max(OY[j,])
mi[j]<-min(OY[j,])
yy<-seq(mi[j],ma[j],length=Ni)
byy<-bs(yy,knots=KNOTY[j,1:NYK[j]],Boun=c(mi[j],ma[j]),int=T)
for(k in 1:Ni){
temp<-Ebetay[1:MCMAX2,j,]%*%byy[k,]
quant[j,,k]<-quantile(temp,probs=c(0.025,0.5,0.975))
jpeg(paste(c(j,"y_fitted",k,".jpg"),collapse=""))
par(mfrow=c(2,1))
plot(as.ts(temp))
acf(as.ts(temp))
dev.off()
}
jpeg(paste(c("transform of repsonse",j,".jpg"),collapse=""))
plot(c(mi[j],ma[j]),c(min(quant[j,,])-0.1,max(quant[j,,])+0.1),type="n",
main="",sub="",xlab="",ylab="")
lines(yy,quant[j,1,],lty=3)
lines(yy,quant[j,2,],lty=1)
lines(yy,quant[j,3,],lty=3)
dev.off()
}