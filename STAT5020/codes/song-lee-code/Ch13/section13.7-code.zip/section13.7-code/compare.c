double dmin2();
double dmax2();
int imin2();
int imax2();
double dmaxv();

double dmin2(double x , double y)
    {
     if(x<y)
        return(x);
     else
        return(y);
      }

double dmax2(double x , double y)
    {
     if(x>y)
        return(x);
     else
        return(y);
      }

int imin2(int x , int y)
    {
     if(x<y)
        return(x);
     else
        return(y);
      }

int imax2(int x , int y)
    {
     if(x>y)
        return(x);
     else
        return(y);
      }

double dmaxv(double *v, int n){
    int i;
    double temp;
    temp=v[0];
    for(i=1;i<n;i++)temp=dmax2(temp,v[i]);
    return temp;
}
