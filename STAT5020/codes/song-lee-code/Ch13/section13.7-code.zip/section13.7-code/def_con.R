################carefully revised when changing model
RD<-0							#0--not real data; 1--real data

N<-as.integer(500)	#sample size
NYn<-as.integer(9)	#number of continuous y
NYp<-0				#number of poisson y
NYb<-0				#number of binomial y
NYc<-0				#number of order categorical y
NY<-NYp+NYn+NYb+NYc		#p, dimension of y
NM<-as.integer(1)			#dim of eta
NZ<-as.integer(2)			#dim of xi
NG<-as.integer(2)			#dimension of nonlinear function in structure equation
NK<-as.integer(NM+NZ)		#dimension of xi
ND<-as.integer(2)			#dim of covariate in SE
NANA<-as.integer(1)		#dim of covariate in ME
NB<-as.integer(ND+NM+NG)

NYKE<-as.integer(rep(8,NY))		#number of knots placed uniformly
NYK<-as.integer(rep(11,NY))		#number of all knots for Y (including NYKE)

NYK1<-NYK+as.integer(4)			#number of cubic splines for Y, don't change
NYK2<-NYK+as.integer(3)			#don't change
ORD<-as.integer(2)				#order of random walk penalty.
NYKO<-NYK1-ORD					#don't change

alpha.loc<-rep(1,NY)			#1st hyper parameter of the gamma prior for local smoothing parameters
beta.loc<-rep(1,NY)				#2nd hyper parameter of the gamma prior for local smoothing parameters

CTOT<-100
CNUM<-100
CBEG<-1

Nbeg=1					# begin MCMC iteration
N.burn<-10000			# number of burn in sample
MCMAX<-25000			# number of total MCMC iteraction
MCMAX1<-15000			# number of iteraction to form a estimate of the mean of B-spline coefficient


nch<-1				#number of chains

sigly<-1			#precision (inverse variance) of prior for Lambda
sigmu<-1			#precision of prior for mu
sigbi<-1			#precision of prior for coefficients in structure equations
sigsa<-1			#precision of coefficients of covariates in measurement equation
sigphi<-1

rou.scale<-5		#rho in wishart prior for \Phi
rou.zero<-rou.scale-NZ-1

R.zero<-rou.zero*matrix(c(1,0.2,0.2,1),nrow=2,ncol=2)	# R in wishart prior for \Phi

alpha.x<-9	#1st hyperparameter of inverse gamma prior for error variance in measurement equation
beta.x<-4	#2nd hyperparameter of inverse gamma prior for error variance in measurement equation
alpha.d<-9	#1st hyperparameter of inverse gamma prior for error variance in structural equation
beta.d<-2.5	#2nd hyperparameter of inverse gamma prior for error variance in structural equation


alpha.tau.y<-1	#1st hyperparameter of inverse gamma prior for smoothing parameter for y
beta.tau.y<-0.005	#2nd hyperparameter of inverse gamma prior for smoothing parameter for y


VAR1<-1				#control acceptance rate for xi VAR1*ISG

mtk<-10				#number of multiple try samples
mt.s<-c(6.5,6.5,6,7,6.5,5.0,5.0,5.0,5.0)	#standard deviation used in the mtm proposal
mt.is<-1/mt.s


pmiss<-0			#probability of missing data occur
is.SIMA<-1/sqrt(rep(0.07,NY))	#MH tuning of threshold

ind.y<-(rep(0,NY))	#indicator of data type of y. 0--continuous <0 binomial (binary) >1 order categorical

#some stuff for exponential and order categorical y.
fy.az<-which(ind.y>0)
NNN<-length(fy.az)
fz.ay<-numeric(NY)
if(NNN>0)fz.ay[ind.y>0]<-1:NNN
simaly=c(1,1,1,1,1,1,1,1,1)
obn.y<-integer(NY)
NTS<-0            #total number of free threshold
for(j in 1:NY){
  NTS<-NTS+max(0,ind.y[j]-3)
}
NYind<-1:NY

OYFILE="OY.txt"		#input observed Y file
YFILE="y.txt"		
ZFILE="Z.txt"

OYread="OY_r.txt"
Yread="y_r.txt"
Zread="Z_r.txt"

AZFILE="AZ.txt"
BZFILE="BZ.txt"

Bandw<-3		#bandwith of the posterior covariance matrix of the b-spline coefficients


