/*090715*/

void mul_vS(double *a, double *c, int n, int p, int *ab, int *ae, 
double *res)
/*sa-- Sparse matrix, sc--vector, snr--nrow of matrix,
 sab--vector with length=nrow, indicate begin of nonzero of each row of A,
 sae--vector with length=nrow, indicate end of nonzero of each row of A.*/
{
     int i,j,b,e;

     for(j=0;j<p;j++)res[j]=0.0;
     for(i=0;i<n;i++){
          b=ab[i]-1;e=ae[i]-1;
          for(j=b;j<=e;j++)
               res[j]+=a[j*n+i]*c[i];
     }
}

void mul_Sv(double *a, double *c,int n, int *ab, int *ae, double *res)
/*sa-- Sparse matrix, sc--vector, snr--nrow of matrix,
 sab--vector with length=nrow, indicate begin of nonzero of each row of A,
 sae--vector with length=nrow, indicate end of nonzero of each row of A.*/
{   
     int i,j,b,e;
     for(i=0;i<n;i++){
          b=ab[i]-1;e=ae[i]-1;
          res[i]=0.0;
          for(j=b;j<=e;j++)
               res[i]+=a[j*n+i]*c[j];                           
     }
}     

void band_choldc(double *Q, double *L, int n, int p)
{
     int i,j,k,l,m;
     double *v;
     double sv;
     v=doubleArray(n);
     
     for(j=0; j<n; j++){
          for(k=0;k<j;k++)L[j*n+k]=0.0;
          l=imin2(j+p,n-1);
          for(k=j;k<=l;k++)v[k]=Q[j*n+k];
          for(k=imax2(0,j-p);k<=j-1;k++){
              i=imin2(k+p,n-1);
              for(m=j;m<=i;m++)
                  v[m]-=L[k*n+m]*L[k*n+j];
          }
          if(v[j]<=0.0)Rprintf("choldc failed\n");
          sv=sqrt(v[j]);
          for(k=j;k<=l;k++){
              L[j*n+k]=v[k]/sv;
          }
     }
     free(v);
}

void band_choldc_c(double  *Q, double *L, int *pn, int *pp)
{
     int i,j,k,l,m;
     int n,p;
     n=*pn;p=*pp;
     double *v;
     double sv;
     v=doubleArray(n);
     
     for(j=0; j<n; j++){
          for(k=0;k<n;k++)L[j*n+k]=0.0;  
          l=imin2(j+p,n-1);         
          for(k=j;k<=l;k++)v[k]=Q[j*n+k];
          for(k=imax2(0,j-p);k<=j-1;k++){
              i=imin2(k+p,n-1);
              for(m=j;m<=i;m++)
                  v[m]-=L[k*n+m]*L[k*n+j];                            
          }
          if(v[j]<=0.0)Rprintf("choldc failed\n");
          sv=sqrt(v[j]);
          for(k=j;k<=l;k++){
              L[j*n+k]=v[k]/sv;
          }
     }
     free(v);
}

void backward_sol_c(double *L, double *x, double *b, int *pn, int *pp)
  {
     int i, k, j, n, p;
     n=*pn;p=*pp;
     double sum;
      for (i=n-1; i>=0; i--){
	  j=imin2(n-1,i+p);
      for (sum=b[i], k=i+1; k<=j; k++)  sum-=L[i*n+k]*x[k];
	  if(L[i*n+i]==0.0)Rprintf("Backward solve fail due to zero diagnonal.\n");
      x[i]=sum/L[i*n+i];
	  }
}

void band_cholsl_mat_bt_c(double *L, double *x, double *b, int *pn, int *pp, int *pn2)
  {
     int i, k, j, m, s, n, p, n2;
     n=*pn;p=*pp;n2=*pn2;
     double sum;
     for(m=0; m<n2; m++){
     s=m*n;
     for (i=0; i<n;i++){
      j=imax2(0,i-p);   
	  for(sum=b[i*n2+m], k=i-1; k>=j;k--)  sum-=L[k*n+i]*x[s+k];
	  x[s+i]=sum/L[i*n+i];
      }
      for (i=n-1; i>=0; i--){
	  j=imin2(n-1,i+p);
      for (sum=x[s+i], k=i+1; k<=j; k++)  sum-=L[i*n+k]*x[s+k];
	  x[s+i]=sum/L[i*n+i];
	  }	  
      }
}

void band_solbychol_bt_c(double  *Q, double *x, double *b,int *pn, int *pp, int *pn2)
{
     int i, k, j, l, m, s, n, p, n2;
     n=*pn;p=*pp;n2=*pn2;
     double *v, *L;
     double sv;
     double sum;
     
     v=doubleArray(n);
     L=doubleArray(n*n);
     
     for(j=0; j<n; j++){
          for(k=0;k<n;k++)L[j*n+k]=0.0;  
          l=imin2(j+p,n-1);         
          for(k=j;k<=l;k++)v[k]=Q[j*n+k];
          for(k=imax2(0,j-p);k<=j-1;k++){
              i=imin2(k+p,n-1);
              for(m=j;m<=i;m++)
                  v[m]-=L[k*n+m]*L[k*n+j];                            
          }
          if(v[j]<=0.0)Rprintf("choldc failed in band_solbychol_bt_c\n");
          sv=sqrt(v[j]);
          for(k=j;k<=l;k++){
              L[j*n+k]=v[k]/sv;
          }
     }

     for(m=0; m<n2; m++){
     s=m*n;
     for (i=0; i<n;i++){
      j=imax2(0,i-p);   
	  for(sum=b[i*n2+m], k=i-1; k>=j;k--)  sum-=L[k*n+i]*x[s+k];
	  x[s+i]=sum/L[i*n+i];
      }
      for (i=n-1; i>=0; i--){
	  j=imin2(n-1,i+p);
      for (sum=x[s+i], k=i+1; k<=j; k++)  sum-=L[i*n+k]*x[s+k];
	  x[s+i]=sum/L[i*n+i];
	  }	  
      }
      
      free(v);free(L);      
      return ;
}

void MtDM(double *M,double *D, int n, int d, int *beg, int *end, double *resM)
{
     int i1, i2, i3, be, en;

     for(i1=0;i1<d;i1++)
         for(i2=0;i2<d;i2++)
             resM[i1+i2*d]=0.0;

     for(i1=0;i1<n;i1++){
         be=beg[i1]-1;en=end[i1]-1;
         for(i2=be;i2<=en;i2++)
             for(i3=be;i3<=en;i3++)
                 resM[i2+i3*d]+=M[i1+i2*n]*M[i1+i3*n]/D[i1];
     }
}

void MtDmDmM(double *M,double *D, int n, int d, int *beg, int *end, double *resM)
{
     int i1, i2, i3, be, en;

     for(i1=0;i1<d;i1++)
         for(i2=0;i2<d;i2++)
             resM[i1+i2*d]=0.0;

     for(i1=0;i1<n;i1++){
         be=beg[i1]-1;en=end[i1]-1;
         for(i2=be;i2<=en;i2++)
             for(i3=be;i3<=en;i3++)
                 resM[i2+i3*d]+=M[i1+i2*n]*M[i1+i3*n]/(D[i1]*D[i1]);
     }
}
