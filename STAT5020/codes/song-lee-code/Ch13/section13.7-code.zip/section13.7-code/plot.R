source("itransdef.R")
for(j in which(ind.y==0)){
xr<-range(OY[j,])
yr<-range(iflist[[j]](OY[j,]))
o<-order(OY[j,])
jpeg(paste(c("y",j,".jpeg"),collapse=""))
plot(xr,yr,type="n")
lines(OY[j,o],iflist[[j]](OY[j,o]))
lines(OY[j,o],BY1[j,o,]%*%Embetay[1,j,],col=3)
dev.off()
}