Y[,]<-matrix(scan(YFILE,skip=(CIR-1)*N,nlines=N),nrow=NY,ncol=N)		#read initial values of transformed Y
OY[,]<-matrix(scan(OYFILE,skip=(CIR-1)*N,nlines=N),nrow=NY,ncol=N)		#read observed Y
if(NNN>0)Z[,]<-matrix(scan(ZFILE,skip=(CIR-1)*N,nlines=N),nrow=NNN,ncol=N)	#read order categorical variables

#covariates in structure eqution
BZ<-matrix(0,nrow=ND,ncol=N)
if(NM>=1){
BZ<-matrix(scan(BZFILE,skip=(CIR-1)*N,nlines=N),nrow=ND)
if(ND>0)XIB[1:ND,]<-BZ[1:ND,1:N]
BZ2<-tcrossprod(BZ)
BZS<-matrix(rowSums(BZ),nrow=1)
}

#covariates in measurement eqution
AZ<-matrix(0,nrow=NANA,ncol=N)
if(NANA>0){
AZ[,]<-matrix(scan(AZFILE,skip=(CIR-1)*N,nlines=N),nrow=NANA)
AZ2<-tcrossprod(AZ)
}

#record what just read for verification
write(OY,file=OYread,ncol=NY,append=T)
if(RD-1)write(Y,file=Yread,ncol=NY,append=T)
if(NNN>0)write(Z,file=Zread,ncol=NNN,append=T)

#draw graphs
jpeg(paste(c("hist",CIR,".jpeg"),collapse=""))
par(mfrow=c(3,3))

for(j in 1:NY)
if(ind.y[j]==0)	#if continuous
{
temp<-seq(min(OY[j,]),max(OY[j,]),length=NYKE[j]+2)[-c(1,NYKE[j]+2)]
for(k in 1:(NYK[j]-NYKE[j])){
tbreak<-c(min(OY[j,]),temp,max(OY[j,]))			#uniformly placed

#place the rest according to quantiles
thi<-hist(OY[j,],breaks=tbreak,plot=FALSE)
tind<-which.max(thi$counts)
app_point<-
quantile(OY[j,OY[j,]>=tbreak[tind]&OY[j,]<tbreak[tind+1]],probs=c(0.5))
temp1<-append(tbreak,app_point,after=tind)
#app_point<-(tbreak[tind]+tbreak[tind+1])/2
temp1<-append(tbreak,app_point,after=tind)
temp<-temp1[-c(1,length(temp1))]
}
KNOTY[j,1:NYK[j]]<-temp


#KNOTY[j,1:NYK[j]]<-quantile(OY[j,], probs = seq(0, 1, length=NYK[j]+2))[-c(1,NYK[j]+2)]
hY[j]<-KNOTY[j,2]-KNOTY[j,1]

#generate matrix containing Basis functions 
BY1[j,,1:(NYK1[j])]<-bs(OY[j,],knots=KNOTY[j,1:NYK[j]],Boun=range(OY[j,]),int=T)
BY12[j,1:(NYK1[j]),1:(NYK1[j])]<-crossprod(BY1[j,,1:(NYK1[j])])
tempknot<-c(rep(min(OY[j,]),4),KNOTY[j,1:NYK[j]],rep(max(OY[j,]),4))
BY2[j,,1:(NYK1[j])]<-spline.des(tempknot,OY[j,],ord=4,der=rep(1,N))$design
#PenY[j,1:NYK1[j],1:NYK1[j]]<-Pen.Mat(NYK1[j])
hist(OY[j,])

if(ind.y[j]==0){
for(i in 1:N){
temp1<-which(BY1[j,i,1:(NYK1[j])]>0)
bey1[i,j]<-as.integer(max(temp1))
bby1[i,j]<-as.integer(min(temp1))
temp1<-which(BY2[j,i,1:(NYK1[j])]!=0)
bey2[i,j]<-as.integer(max(temp1))
bby2[i,j]<-as.integer(min(temp1))
}
}

BY1m[j,1:(NYK1[j])]<-colSums(BY1[j,,1:(NYK1[j])])

}
dev.off()

