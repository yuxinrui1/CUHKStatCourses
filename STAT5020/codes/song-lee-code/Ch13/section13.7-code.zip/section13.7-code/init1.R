###################need careful revision when model changed

#initial values of parameters

LY<-matrix(c(
1,0,0,
1,0,0,
1,0,0,
0,1,0,
0,1,0,
0,1,0,
0,0,1,
0,0,1,
0,0,1),
ncol=NK,nrow=NY,byr=T)

MU<-rep(0,NY)
AD<-matrix(c(
1,
1,
1,
1,
1,
1,
1,
1,
1
),nrow=NY,ncol=NANA,byrow=T)


COE<-cbind(MU,AD,LY)


##attention is given only if initial value to be changed, structure automatic.
tau.y<-rep(0.5,NY)
#betay<-matrix(rep(seq(-5,5,length=max(NYK1)),NY),nrow=NY,byrow=T)

betay<-matrix(as.double(0),nrow=NY,ncol=max(NYK1))

#for(j in 1:NY){
#betay[j,1:(Med[j]-1)]<-seq(-1,length=Med[j]-1,by=-1)
#betay[j,(Med[j]+1):NYK1[j]]<-seq(1,length=NYK1[j]-Med[j],by=1)
#}

for(j in 1:NY){
if(ind.y[j]==0){
nj<-NYK1[j]
temp<-gatemp1<-gatemp<-rep(0.1,NYK1[j])

for(k in 2:NYK1[j]){
gatemp1[k]<-sum(BY1m[j,k:NYK1[j]])
}
temp[1]<--sum(gatemp1[-1]*gatemp[-1])/sum(BY1m[j,1:nj])
for(k in 2:NYK1[j]){
temp[k]<-temp[1]+sum(gatemp[2:k])
}
print(
sum(abs(temp-(diag(1,NYK1[j])-(BY1m[j,1:nj])%*%t(BY1m[j,1:nj])/
sum((BY1m[j,1:nj])^2))%*%temp)))
betay[j,1:NYK1[j]]<-temp*2
}
}


PSX<-rep(1,NY)
iPSX<-1/PSX
inv.sqrt.PSX<-1/sqrt(PSX)

COE<-cbind(matrix(MU,ncol=1),AD,LY)

if(NZ>0){
PHI<-matrix(0.0,nrow=NZ,ncol=NZ)
diag(PHI)<-1
inv.PHI=chol2inv(chol(PHI))
c.inv.PHI<-chol(inv.PHI)
}

if(NM>=1){
PB<-array(rep(0.4,NM*NG),dim=c(NM,NG))
PI<-array(rep(0,NM*NM),dim=c(NM,NM))
IB<-cbind(PI,PB)
BD<-array(rep(0.4,NM*ND),dim=c(NM,ND))
BI<-cbind(BD,IB)
PSD<-rep(0.3,NM)
iPSD<-1/PSD
inv.sqrt.PSD<-1/sqrt(PSD)
}

thres<-t(matrix(
c(
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0  
  ),nrow=max(ind.y)+1,ncol=NY))
#-200,-2,1,1.5,2,200

delta<-matrix(1,nrow=NY,ncol=max(NYKO))
for(j in 1:NY){
nj<-NYK1[j]
PenY[j,1:nj,1:nj]<-Pen.Mat.loc(d=nj,loc=delta[j,1:NYKO[j]],ord=ORD)
}
