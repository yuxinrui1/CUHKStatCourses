###############attention must be given to structure.

#varaible names simmilar to C program

PLY<-matrix(c(
1,0,0,
0.8,0,0,
0.8,0,0,
0,1,0,
0,0.8,0,
0,0.8,0,
0,0,1,
0,0,0.8,
0,0,0.8
),ncol=NK,nrow=NY,byr=T)

#####################structure automatic, change when changing value.

PMU<-rep(0,NY)
PAD<-matrix(c(
1.2,1.2,
1.2,1.2,
1.2,1.2,
1.2,1.2,
1.2
),nrow=NY,ncol=NANA,byrow=T)


PCOE<-cbind(matrix(PMU,ncol=1),PAD,PLY)

if(NM>=1){
PBD<-array(rep(1.0,NM*ND),dim=c(NM,ND))
PPI<-array(rep(0,NM*NM),dim=c(NM,NM))
PPB<-array(rep(0.6,NM*NG),dim=c(NM,NG))
PIB<-cbind(PPI,PPB)
PBI<-cbind(PBD,PIB)
}



