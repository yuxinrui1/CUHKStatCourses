for(g in Nbeg:MCMAX1){
gm<-g-N.burn

mo[,]<-AD%*%AZ+LY%*%Omega+MU	#mean on the right hand side of the model

if(TRANS){		#if transformation applies
for(j in NYind)
if(ind.y[j]==0)	#for continuous Y
{
#self<-as.logical(rbinom(1,1,0.5)
self<-T
if(self){	#use c complied dll
#if(g%%MTN>=MHN){

nj<-NYK1[j]
#MTM in C
temp<-.Call("MTM_RCD_BMCONST",
as.double(BY1[j,,1:nj]),
as.double(BY1m[j,1:nj]),
as.double(BY12[j,1:nj,1:nj]),
as.double(BY2[j,,1:nj]),
as.double(iPSX[j]),
as.double(PenY[j,1:nj,1:nj]),
as.double(tau.y[j]),
as.integer(bby1[,j]),
as.integer(bey1[,j]),
as.integer(bby2[,j]),
as.integer(bey2[,j]),
as.integer(Bandw),
as.integer(N),
as.integer(nj),
as.integer(10),
as.double(mo[j,]),
as.double(betay[j,1:nj]),
as.double(mt.is[j]),
as.double(0),
as.double(0.00001),
as.double(betay0[j,1:nj]),
c(as.integer(g>N.burn),as.integer(MTM.rep[j])))

if(g<=N.burn)betay0=betay0+betay
if(g==N.burn)betay0=betay0/N.burn

if(temp[1]){
AC.betay[j]<-AC.betay[j]+as.integer(temp[1])#first element of the return vector is acceptance indicator
bemu<-temp[2]	#2nd element of the return vector is the mean indicator
betay[j,1:nj]<-temp[-c(1,2)]	# the rest are 
betan<-temp[-c(1,2)]-bemu

Y[j,]<-.Call("mul_Sv_Call",BY1[j,,1:nj],betan,N,bby1[,j],bey1[,j])
}


}

if(!self){		#native R code without C, doing the same thing
	nj<-NYK1[j]
	icalsm<-BY12[j,1:nj,1:nj]*iPSX[j]+PenY[j,1:nj,1:nj]/tau.y[j]
	betam<-.Call("mul_vS_Call",
		BY1[j,,1:nj],
		as.double(mo[j,]*iPSX[j]),
		N,nj,bby1[,j],bey1[,j])

	indtemp<-sample(x=c(1,2,3),size=1,prob=c(1,1,1))
	re<-numeric(nj)
	re[Med[j]]<-0
	if(indtemp==1)re[-Med[j]]<-runif(n=nj-1,min=-1,max=1)
	if(indtemp==2){
		re[1:(Med[j]-1)]<-sort(runif(n=Med[j]-1,min=-1,max=0-tol))
		re[(Med[j]+1):nj]<-sort(runif(n=nj-Med[j],min=0+tol,max=1))
	}
	if(indtemp==3){
		re[nj:(Med[j]+1)]<-sort(runif(n=nj-Med[j],min=-1,max=0-tol))
		re[(Med[j]-1):1]<-sort(runif(n=Med[j]-1,min=0+tol,max=1))
	}

	re<-re/sqrt(sum(re*re))

	rmino<--20000
	rmaxo<-20000
	dre<-re[2:nj]-re[1:(nj-1)]
	betao<-betay[j,1:nj]
	idbetao<-betao[1:(nj-1)]-betao[2:nj]
	renbo<-idbetao/dre
	rmino<-max(rmino,renbo[dre>0])+tol
	rmaxo<-min(rmaxo,renbo[dre<0])-tol

#	rn[1:mtk]<-rtnorm(mtk,rep(0,mtk),rep(mt.s[j],mtk),rep(rmino,mtk),rep(rmaxo,mtk))
	rn[]<-.Call("trunomcall",as.integer(mtk),rep(as.numeric(0),mtk),
    		rep(as.numeric(mt.is[j]),mtk),rep(as.numeric(rmino),mtk),
		rep(as.numeric(rmaxo),mtk))

	for(l in 1:mtk){
#		rn[l]<-.Call("trunomcall",as.integer(1),as.numeric(0),
#      		as.numeric(mt.is[j]),as.numeric(rmino),as.numeric(rmaxo))
		mt.betan[l,1:nj]<-tbeta<-betao+rn[l]*re	
		mt.log.like[l]<-(-0.5)*tbeta%*%icalsm%*%tbeta+tbeta%*%betam+
			sum(log(.Call("mul_Sv_Call",
				BY2[j,,1:(NYK1[j])],tbeta,N,bby2[,j],bey2[,j])))
#		mt.boun[1,l]<-rmino+rn[l]
#		mt.boun[2,l]<-rmaxo-rn[l]
		idbetan<-mt.betan[l,1:(nj-1)]-mt.betan[l,2:nj]
		renbn<-idbetan/dre
		mt.boun[1,l]<--20000
		mt.boun[2,l]<-20000
		mt.boun[1,l]<-max(mt.boun[1,l],renbn[dre>0])+tol
		mt.boun[2,l]<-min(mt.boun[2,l],renbn[dre<0])-tol
	}
	TK<-exp(-0.5*rn^2*mt.is[j]^2)/(pnorm(mt.boun[2,],0,mt.s[j])-pnorm(mt.boun[1,],0,mt.s[j]))
	mean.mtlogl.n<-max(mt.log.like)
	WKN<-exp(mt.log.like-mean.mtlogl.n)*TK
	ind.beta<-sample(1:mtk,size=1,replace=T,prob=WKN)

	betan<-mt.betan[ind.beta,1:nj]
	rminn<-mt.boun[1,ind.beta]
	rmaxn<-mt.boun[2,ind.beta]

	ro[mtk]<-(-rn[ind.beta])
	mt.betao[mtk,1:nj]<-betao[1:nj]
	mt.log.like[mtk]<-(-0.5)*betao%*%icalsm%*%betao+betao%*%betam+
		sum(log(.Call("mul_Sv_Call",BY2[j,,1:(nj)],betao,N,bby2[,j],bey2[,j])))

	mt.boun[1,mtk]<-rmino
	mt.boun[2,mtk]<-rmaxo

#	ro[1:(mtk-1)]<-rtnorm(mtk-1,rep(0,mtk-1),
#   		rep(mt.s[j],mtk-1),rep(rminn,mtk-1),rep(rmaxn,mtk-1))
	ro[1:(mtk-1)]<-.Call("trunomcall",as.integer(mtk-1),
		rep(as.numeric(0),mtk-1),rep(as.numeric(mt.is[j]),mtk-1),
		rep(as.numeric(rminn),mtk-1),rep(as.numeric(rmaxn),mtk-1))

	for(l in 1:(mtk-1)){
#		ro[l]<-.Call("trunomcall",as.integer(1),as.numeric(0),
#      		as.numeric(mt.is[j]),as.numeric(rminn),as.numeric(rmaxn))
		mt.betao[l,1:nj]<-tbeta<-betan+ro[l]*re	
		mt.log.like[l]<-(-0.5)*tbeta%*%icalsm%*%tbeta+tbeta%*%betam+
			sum(log(.Call("mul_Sv_Call",BY2[j,,1:(NYK1[j])],
				tbeta,N,bby2[,j],bey2[,j])))
#		mt.boun[1,l]<-rminn+ro[l]
#		mt.boun[2,l]<-rmaxn-ro[l]
		idbetao<-mt.betao[l,1:(nj-1)]-mt.betao[l,2:nj]
		renbo<-idbetao/dre
		mt.boun[1,l]<--20000
		mt.boun[2,l]<-20000
		mt.boun[1,l]<-max(mt.boun[1,l],renbo[dre>0])+tol
		mt.boun[2,l]<-min(mt.boun[2,l],renbo[dre<0])-tol
	}
	TK<-exp(-0.5*ro^2*mt.is[j]^2)/(pnorm(mt.boun[2,],0,mt.s[j])-pnorm(mt.boun[1,],0,mt.s[j]))
	mean.mtlogl.o<-max(mt.log.like)
	WKO<-exp(mt.log.like-mean.mtlogl.o)*TK
	actemp<-(runif(1)<(exp(mean.mtlogl.n+log(sum(WKN))-
(mean.mtlogl.o+log(sum(WKO))))))
	if(actemp){
		AC.betay[j]<-AC.betay[j]+1
		#if(gm>0)AC.betay.ab[j]<-AC.betay.ab[j]+1
		betay[j,1:nj]<-betan
		Y[j,]<-.Call("mul_Sv_Call",BY1[j,,1:nj],betan,N,bby1[,j],bey1[,j])
	}
}

	alpha.star=alpha.tau.y+(nj-2)/2
	beta.star=beta.tau.y+0.5*betay[j,1:nj]%*%PenY[j,1:nj,1:nj]%*%betay[j,1:nj]
	tau.y[j]<-1/rgamma(1,shape=alpha.star,rate=beta.star)

	betatemp<-betay[j,2:nj]-betay[j,1:(nj-1)]
	if(ORD==2)betatemp<-betatemp[2:(nj-1)]-betatemp[1:(nj-2)]
	delta[j,1:NYKO[j]]<-rgamma(NYKO[j],shape=0.5*rep(alpha.loc[j],NYKO[j])+0.5,
		rate=0.5*rep(beta.loc[j],NYKO[j])+0.5*betatemp^2/tau.y[j])
	PenY[j,1:nj,1:nj]<-Pen.Mat.loc(d=nj,loc=delta[j,1:NYKO[j]],ord=ORD)
  }

}#END if(TRANS)

if(NK>0){
	#update xi
	ISG<-crossprod(inv.sqrt.PSX*LY)
	if(NZ>0)ISG[(NM+1):NK,(NM+1):NK]<-ISG[(NM+1):NK,(NM+1):NK]+inv.PHI
  if(NM>=1){
    PI.z<-diag(1,NM)-PI
    dH0<-fstd(rep(0,NZ),NG,NZ)
    sqrt.ISG<-matrix(0,nrow=NM,ncol=NK)
    sqrt.ISG[,1:NM]<-PI.z
    sqrt.ISG[,(NM+1):NK]<--PB%*%dH0
    ISG<-ISG+crossprod(inv.sqrt.PSD*sqrt.ISG)
  }  
	ISG<-ISG*VAR1

	SIG<-chol2inv(chol(ISG))
	cSIG<-chol(SIG)
	OMEN<-Omega+crossprod(cSIG,matrix(rnorm(N*NK,0,1),nrow=NK,ncol=N))

	if(NM>=1)
  nlN.S<-non.lin(OMEN[(NM+1):NK,])

	Ycen<-MU+AD%*%AZ

	r1<-log.likelihood.exp(Y,Ycen,LY,Omega,XIB[(ND+NM+1):NB,],BZ,inv.sqrt.PSX,PI.z,PB,BD,inv.sqrt.PSD,c.inv.PHI)
	r2<-log.likelihood.exp(Y,Ycen,LY,OMEN,nlN.S,BZ,inv.sqrt.PSX,PI.z,PB,BD,inv.sqrt.PSD,c.inv.PHI)
	r<-exp(0.5*(r1-r2))
	comr<-runif(N)
	crit<-(comr<r)
	COV[(2+NANA):(1+NANA+NK),crit]<-Omega[,crit]<-OMEN[,crit]
	AC.XI<-AC.XI+crit
	if(NM>=1){
    XIB[(ND+1):(ND+NM),crit]<-Omega[1:NM,crit]
    XIB[(ND+NM+1):NB,crit]<-nlN.S[1:NG,crit]
  }
}
	count.ly<-count.ad<-1	
	for(j in NYind){  
		subs<-SICE[j,]
		len<-lencv[j]
		Ycen<-COE[j,(!subs),drop=F]%*%COV[(!subs),,drop=F]

			omesub<-COV[subs,,drop=FALSE]
			PSiginv<-rep(sigly,len)
			Pmean<-PCOE[j,subs]
	#update LY and PSX correponding to normal(include underlying)
      if(ind.y[j]>=0){
        #For first dichotomous, no MU, LY fixed, PSX fixed,
        #nothing to be estimated. no need to compute
          Ycen<-as.vector(Y[j,,drop=FALSE]-Ycen)
          alpha.star<-alpha.x+N/2
          beta.star<-beta.x+1/2*sum(Ycen^2)
        if(len!=0){
          calsmnpsx<-chol2inv(chol((tcrossprod(omesub)+diag(PSiginv,len))))
          temp<-(omesub%*%Ycen+PSiginv*Pmean)
          LYnpsx<-calsmnpsx%*%temp
          beta.star<-beta.star+1/2*(sum(Pmean*PSiginv*Pmean)-sum(temp*LYnpsx))
        }
        #PSX is fixed for dichotomous data(ind.y==2)
        if(ind.y[j]>=3){
#        if(ind.y[j]!=2){
          iPSX[j]<-rgamma(1,shape=alpha.star,rate=beta.star)
          PSX[j]<-1/iPSX[j]
          inv.sqrt.PSX[j]<-sqrt(iPSX[j])
        }
        # PSX for dichotomous is set to 1.
        if(len!=0){
          COE[j,subs]<-mvrnorm(1,LYnpsx,Sig=(calsmnpsx*PSX[j]))
        }
      }#if(ind.y[j]>=0)
      #update LY and PSX correponding to exponential Binary.
      if(ind.y[j]<0){
        if(ind.y[j]<=(-1)){
			temp<-exp(Ycen[,,drop=T])
			temp<-(-ind.y[j])*temp/(1+temp^2)
		}
		if(ind.y[j]>-1)temp<-exp(Ycen[,,drop=T])
        calsmnpsx<-chol2inv(chol(tcrossprod(omesub*
			outer(rep(1,lencv[j]),temp),omesub)+iPSX[j]*PSiginv))
        #complete random walk proposal for COE
        LYnpsx<-mvrnorm(1,COE[j,subs],Sig=(calsmnpsx*simaly[j]))
        #2--new, 1--old
        OMEN.n<-Ycen+LYnpsx%*%COV[subs,,drop=FALSE]
        OMEN.o<-Ycen+COE[j,subs]%*%COV[subs,,drop=FALSE]
		if(ind.y[j]<=(-1)){
			b.OMEN.n<-(-ind.y[j])*log(1+exp(OMEN.n))
			b.OMEN.o<-(-ind.y[j])*log(1+exp(OMEN.o))
		}
		if(ind.y[j]>(-1)){
			b.OMEN.n<-exp(OMEN.n)
			b.OMEN.o<-exp(OMEN.o)
		}
        #r2--new, r1--old
        r2<-sum(Y[j,]*OMEN.n-b.OMEN.n)*iPSX[j]-
			0.5*sum((LYnpsx-Pmean)^2*PSiginv)
        r1<-sum(Y[j,]*OMEN.o-b.OMEN.o)*iPSX[j]-
			0.5*sum((COE[j,subs]-Pmean)^2*PSiginv)
        #Proposal cancelled out due to random walk.
        r<-exp(r2-r1)
        if(runif(1)<r){
          AC.LY[j]<-AC.LY[j]+1
          COE[j,subs]<-LYnpsx
        }
      }#if(ind.y[j]<0)

		if(lencv[j]>0){
			MU[j]<-COE[j,1]
			if(NANA>0)AD[j,]<-COE[j,2:(1+NANA)]
			LY[j,]<-COE[j,(2+NANA):(1+NANA+NK)]
			if(gm>0){
				if(lenly[j]>0)ELY[gm,count.ly:(count.ly+lenly[j]-1)]<-LY[j,SIDY[j,]]
				if(lenad[j]>0)EAD[gm,count.ad:(count.ad+lenad[j]-1)]<-AD[j,SIDA[j,]]
			}
			count.ad<-count.ad+lenad[j]
			count.ly<-count.ly+lenly[j]
		}#end if

#update categorical threshold and observed categorical Y
#(include observed dichotomous variable)
		if(ind.y[j]>0){
      crit<-(mind.y[j,]==0)
      temp.mu<-as.double((COE[j,]%*%COV[,crit])[,,drop=TRUE])
if(0){
        if(ind.y[j]>3){
        n.thres<-o.thres<-thres[j,1:(ind.y[j]+1)]
        for(k in 3:(ind.y[j]-1))
          n.thres[k]<-rtnorm(1,o.thres[k],0.05,n.thres[k-1],o.thres[k+1])
        r1<-r2<-0
        for(k in 3:(ind.y[j]-1)){
          r2<-r2+log(pnorm(o.thres[k+1],mean=o.thres[k],sd=0.05)-
              pnorm(n.thres[k-1],mean=o.thres[k],sd=0.05))             
          r1<-r1+log(pnorm(n.thres[k+1],mean=n.thres[k],sd=0.05)-
              pnorm(o.thres[k-1],mean=n.thres[k],sd=0.05))             
        }
        Z.crit<-Z[fz.ay[j],crit]
        r2<-r2+sum(log(pnorm(n.thres[Z.crit+1],temp.mu,sqrt(PSX[j]),)
        -pnorm(n.thres[Z.crit],temp.mu,sqrt(PSX[j]))))
        r1<-r1+sum(log(pnorm(o.thres[Z.crit+1],temp.mu,sqrt(PSX[j]),)
        -pnorm(o.thres[Z.crit],temp.mu,sqrt(PSX[j]))))
        if(runif(1)<exp(r2-r1)){
          AC.th[j]<-AC.th[j]+1
          thres[j,1:(ind.y[j]+1)]<-n.thres
          Y[j,crit]<-rtnorm(obn.y[j],temp.mu,sqrt(PSX[j]),
          n.thres[Z.crit],n.thres[(Z.crit+1)])
        }
        }
        if(ind.y[j]<=3){
          Z.crit<-Z[fz.ay[j],crit]
          Y[j,crit]<-rtnorm(obn.y[j],temp.mu,sqrt(PSX[j]),
          thres[j,Z.crit],thres[j,(Z.crit+1)])
        }
}#if()

if(1){
    #SEXP cowles(SEXP obn(s), SEXP nth(s), SEXP Z(v), SEXP ALPHA(v),
    #  SEXP uu(v),  SEXP isPSI(s), SEXP issima(s))
    #s--scalar, v--vector
      #ind.upth indicate whether further update underlying y is to be done.
      #Large number(e.g.100 for convinence) indicate to be done. 
      ind.upth<-100
      if(ind.y[j]>3){
      temp<-.Call("cowles",
      as.integer(obn.y[j]),
      as.integer(ind.y[j]+1),
      as.integer(Z[fz.ay[j],crit]),
      as.numeric(thres[j,1:(ind.y[j]+1)]),
      as.numeric(temp.mu),
      as.numeric(inv.sqrt.PSX[j]),
      as.numeric(is.SIMA[j]))
      ind.upth<-temp[(ind.y[j]+2)]
      if(ind.upth>10){
        AC.th[j]<-AC.th[j]+1
        thres[j,1:(ind.y[j]+1)]<-temp[1:(ind.y[j]+1)]
        }
      }

#The last extra one is used to indicate reject. 
#100 if accepted and 0 rejected.
#SEXP trunomcall(int n(s), double MU(v), double iSD(v),
#double as(v), double bs(v))
      if(ind.upth>10){
        Y[j,crit]<-.Call("trunomcall",
                      (obn.y[j]),
                      temp.mu,
                      (rep(inv.sqrt.PSX[j],obn.y[j])),
                      (thres[j,Z[fz.ay[j],crit]]),
                      (thres[j,(Z[fz.ay[j],crit]+1)]))
#         Y[j,crit]<-rtnorm(obn.y[j],temp.mu,1,
#            thres[j,Z[fz.ay[j],crit]],thres[j,(Z[fz.ay[j],crit]+1)])
                      }
}#if()
}
   
#update missing data
   #continuous, underlying of order categorical and dichotomous variable.
    if(ind.y[j]>0&obn.y[j]<N){    
      crit<-which(mind.y[j,]!=0)
      Y[j,crit]<-rnorm(N-obn.y[j],(COE[j,]%*%COV[,crit])[,,drop=TRUE],
        sqrt(PSX[j]))  
    }
   #Exponential family(Binary variable)
    if(ind.y[j]<0&obn.y[j]<N){
      crit<-which(mind.y[j,]!=0)
      temp<-exp((COE[j,]%*%COV[,crit])[,,drop=TRUE])
      if(ind.y[j]<=(-1))
		Y[j,crit]<-rbinom(N-obn.y[j],(-ind.y[j]),temp/(1+temp))
	  if(ind.y[j]>(-1))
		Y[j,crit]<-rpois(N-obn.y[j],temp)
    }                        
	}#end j NY

	#update BI and PSD
	count.n<-1
	j=1
	while(j<=NM){
		subs<-(IDSE[j,]==1)
		len<-length(BI[j,subs])
		etacen<-Omega[j,]-BI[j,(!subs)]%*%XIB[(!subs),,drop=FALSE]
		etacen<-as.vector(etacen)
		alpha.star<-alpha.d+N/2
		beta.star<-beta.x+1/2*sum(etacen^2)

		if(len>0){
			XIBsub<-XIB[subs,,drop=F]
			PSiginv<-diag(rep(sigbi,len),len)
			Pmean<-PBI[j,subs]
			calsmnpsd<-chol2inv(chol((tcrossprod(XIBsub)+PSiginv)))
			temp<-(XIBsub%*%etacen+rep(sigbi,len)*Pmean)
			BInsp<-calsmnpsd%*%temp
			beta.star<-beta.star+1/2*(Pmean*(PSiginv*Pmean)-sum(temp*BInsp))
		}#end if
	
		iPSD[j]<-rgamma(1,shape=alpha.star,rate=beta.star)
		PSD[j]<-1/iPSD[j]
		if(len>0){
			BI[j,subs]<-mvrnorm(1,BInsp,Sig=(calsmnpsd*PSD[j]))
			if(gm>0){EBI[gm,count.n:(count.n+len-1)]<-BI[j,subs]}
			count.n<-count.n+len
		}#end if
		j=j+1
	}#end j NM
	
if(NM>=1){
	inv.sqrt.PSD<-sqrt(iPSD)
	
	if(ND>0){BD<-(BI[,1:ND,drop=F])}
	if(NM>0){PI<-(BI[,(ND+1):(ND+NM),drop=F])}
	if(NG>0){PB<-(BI[,(ND+NM+1):NB,drop=F])}
}

	#update PHI
if(NZ>0){
		inv.PHI<-rwish(rou.zero+N, solve(tcrossprod(
      Omega[(NM+1):NK,,drop=F])+R.zero))  
		PHI<-chol2inv(chol(inv.PHI))
	
	c.inv.PHI<-chol(inv.PHI)
}

	if(gm>0){
		if(NZ>0)EPHI[gm,]<-as.vector(PHI)
		EPSX[gm,]<-PSX
		Etauy[gm,]<-tau.y
		Ebetay[gm,,]<-betay
    		if(NMU>=1)EMU[gm,]<-MU[IDMU.lgc]
    		Ethres[gm,]<-thres[IDth]		
		Edelta[gm,,]<-delta
		Eomega[,]<-Eomega+Omega
    if(NM>=1){
    EPSD[gm,]<-PSD
    }#if(NM>=1)                 
}
	
if(g%%1000==0)print(g)
}#end of g MCMAX
