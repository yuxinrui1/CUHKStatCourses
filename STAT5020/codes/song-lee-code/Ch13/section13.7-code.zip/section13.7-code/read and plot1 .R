library(splines)
source("def_con.R")
source("ind.R")
Ni<-100
Cp<-10
ma<-mi<-numeric(NY)
quant<-array(0,dim=c(NY,3,Ni))
trac<-numeric(Cp*MCMAX)
trans_id<-which(ind.y==0)

iter<-MCMAX-N.burn
sample.begin.part<-4
sample.end.part<-10
sample.trace<-(1+(sample.begin.part-1)*iter):((sample.end.part)*iter)

Mean_betay<-matrix(0,NY,max(NYK1))

NMU<-sum(IDMU)
NLY<-sum(IDY)
NAD<-sum(IDA)
if(NM>=1){
NBD<-sum(IDBD)
NPIBI<-sum(IDB)
}

#read and plot
OY<-matrix(scan("RES2factor_NoNA_notrans_jit1.txt",sep=""),nrow=NY,ncol=N)
KNOTY<-matrix(0,nrow=NY,ncol=max(NYK))
#BY1<-array(0,dim=c(NY,N,max(NYK1)))
#BY12<-array(0,dim=c(NY,max(NYK1),max(NYK1)))
#BY2<-array(0,dim=c(NY,N,max(NYK1)))
source("gen_knot_basis.R")

for(j in trans_id){
temp<-matrix(scan(paste(c("tr_betay",j,".txt"),collapse=""),skip=(sample.begin.part-1)*iter),nrow=NYK1[j])
for(k in 1:NYK1[j]){
jpeg(paste(c("tr_betay_",j,"_",k,".jpeg"),collapse=""))
#plot(as.ts(temp[k,sample.trace]))
plot(temp[k,],type="l")
dev.off()
}

#me_betay<-rowMeans(temp[,sample.trace])
Mean_betay[j,1:NYK1[j]]<-rowMeans(temp[,])


ma[j]<-max(OY[j,])
mi[j]<-min(OY[j,])
yy<-seq(mi[j],ma[j],length=Ni)
byy<-bs(yy,knots=KNOTY[j,1:NYK[j]],Boun=c(mi[j],ma[j]),int=T)
for(k in 1:Ni){
#temp1<-byy[k,]%*%temp[,sample.trace]
temp1<-byy[k,]%*%temp[,]
quant[j,,k]<-quantile(temp1,probs=c(0.05,0.5,0.95))

#quant[j,,k]<-quantile(temp1,probs=c(0.025,0.5,0.975))
#jpeg(paste(c(j,"y_fitted",k,".jpg"),collapse=""))
#par(mfrow=c(2,1))
#plot(as.ts(as.vector(temp1)))
#acf(as.ts(as.vector(temp1)))
#dev.off()
}
jpeg(paste(c("transform of repsonse X",j,".jpg"),collapse=""))
plot(c(mi[j],ma[j]),c(min(quant[j,,])-0.1,max(quant[j,,])+0.1),type="n",
main="",sub="",xlab="",ylab="")
lines(yy,quant[j,1,],lty=3)
lines(yy,quant[j,2,],lty=1)
lines(yy,quant[j,3,],lty=3)
dev.off()
print(j)
}


temp<-matrix(scan("tr_ly.txt"),nrow=NLY)
for(k in 1:NLY){
jpeg(paste(c("tr_ly_",k,".jpeg"),collapse=""))
plot(as.ts(temp[k,sample.trace]))
dev.off()
print(mean(temp[k,sample.trace]))
print(sd(temp[k,sample.trace]))
}


temp<-matrix(scan("tr_ad.txt"),nrow=NAD)
for(k in 1:NAD){
jpeg(paste(c("tr_ad_",k,".jpeg"),collapse=""))
plot(as.ts(temp[k,sample.trace]))
dev.off()
print(mean(temp[k,sample.trace]))
print(sd(temp[k,sample.trace]))
}


temp<-matrix(scan("tr_phi.txt"),nrow=NZ^2)
for(k in 1:(NZ^2)){
jpeg(paste(c("tr_phi_",k,".jpeg"),collapse=""))
plot(as.ts(temp[k,sample.trace]))
dev.off()
print(mean(temp[k,sample.trace]))
print(sd(temp[k,sample.trace]))
}

