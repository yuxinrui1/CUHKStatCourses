#ind=sample.int(n=2,size=N,prob=c(0.3,0.7),replace=T)

BZ<-matrix(0,nrow=ND,ncol=N)
if(ND>=0){
#BZ[,]<-matrix(rnorm(N*ND),nrow=ND)
#BZ[,]<-matrix(rnorm(N*ND,-2,1),nrow=ND)*as.numeric(ind==1)+
#matrix(rnorm(N*ND,2,0.1),nrow=ND)*as.numeric(ind==2)
BZ[,]<-(rexp(N*ND,0.2))#-3
XIB[1:ND,]<-BZ[1:ND,1:N]
BZ2<-tcrossprod(BZ)
BZS<-matrix(rowSums(BZ),nrow=1)
}

#gen True xi
if(NZ>0){
xi<-t(mvrnorm(N,rep(0,NZ),Sigma=PHI))
TUE[((NM+1):NK),]<-xi
}
if(NM>=1){
muxi<-BD%*%BZ+PB%*%non.lin(xi)
j=1
while(j<=NM){
TUE[j,]<-rnorm(N,muxi[j,],sd=sqrt(PSD[j]))
j=j+1
}
TUE[1:NM,]<-chol2inv(chol(diag(1,NM)-PI))%*%TUE[1:NM,]
}# if(NM>=1)

ind=sample.int(n=2,size=N,prob=c(0.7,0.3),replace=T)


AZ<-matrix(0,nrow=NANA,ncol=N)
if(NANA>0){
#AZ<-matrix(rnorm(N*NANA),nrow=NANA)
#AZ[,]<-matrix(rnorm(N*NANA,-2,1),nrow=NANA)*as.numeric(ind==1)+
#matrix(rnorm(N*NANA,2,0.1),nrow=NANA)*as.numeric(ind==2)
AZ[,]<-(rexp(N*NANA,0.2))#-3
AZ2<-tcrossprod(AZ)
}



theta<-LY%*%TUE+MU
if(NANA>0){theta<-theta+AD%*%AZ}
for(j in 1:NY){
if(ind.y[j]>=0){
	Y[j,]<-rnorm(N,theta[j,],sqrt(PSX[j]))
	#if(j==NY)Y[j,]<-Y[j,]+Y[j-1,]
	if(ind.y[j]==0)OY[j,]<-flist[[j]](Y[j,])
    if(ind.y[j]>0){
      for(i in 1:N){
        for(k in 1:ind.y[j]){
          if((Y[j,i]>thres[j,k])&(Y[j,i]<=thres[j,k+1]))
            {Z[fz.ay[j],i]<-as.integer(k)}
          }
        }
      }
}#if ind.y[j]>=0
if(ind.y[j]<0){
	if(ind.y[j]<=(-1))  
		Y[j,]<-rbinom(N,-ind.y[j],exp(theta[j,])/(1+exp(theta[j,])))
	if(ind.y[j]>(-1))
		Y[j,]<-rpois(N,exp(theta[j,]))
}
}#for j in 1:NY

if(NNN>0)write(Z,file="z.txt",ncol=dim(Z)[1],append=T)
write(OY,file=OYFILE,ncol=NY,append=T)
write(Y,file=YFILE,ncol=NY,append=T)

if(NANA>0){
#AZ[NANA,]<-Y[NY-1,]
write(AZ,"AZ.txt",ncol=NANA,append=T)
}
if(ND>0){
write(BZ,"BZ.txt",ncol=ND,append=T)
}

