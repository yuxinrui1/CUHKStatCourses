/*090715*/

void nrerror(char error_text[])
{
	void exit();
	fprintf(stderr,"Numerical Recipes run-time error...\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"...now exiting to system...\n");
	exit(1);
}


double onetn(double as)
{
double aa, rz, zz, uu, vv;
/*long idum;*/
int flag=0;
if(as>=0.0)
   while(flag==0)
     {
     aa=0.5*as+0.5*sqrt(as*as+4.0);
/*     idum=rand();*/
     zz=rexp(1)/aa+as;
     rz=-(zz-aa)*(zz-aa)/2.0;
/*     uu=rand()/(RAND_MAX+1.0);*/
     uu=runif(0,1);
     if(uu<=0.0) vv=uu;
     else  vv=log(uu);
     if(vv<=rz)  flag=1;
     }
     else
       while(flag==0)
          {
/*         idum=rand();
           zz=gasdev(&idum);*/
           zz=rnorm(0,1);           
           if(zz>as) flag=1;
          }
  return(zz);
}

double trunom_s(double as, double bl)
{
  double  rz, zz, uu, vv, re=0.0;
  int flag=0;
if(as>bl){
   printf("as=%14f, bl=%14f\n", as, bl);
   nrerror("Error: as>bl\n");  }
if(bl>=8)
   while(flag==0)
      {
       zz=onetn(as);
       if(zz<= bl){
          flag=1;  re=zz;  }
      }
if(as<=-8)
   while(flag==0)
      {
       zz=-1.0*onetn(-1.0*bl);
       if(zz>as){
          flag=1;  re=zz;  }
      }
if(as>-8 && bl<8.0)
  while(flag==0)
   {
/*   zz=as+(bl-as)*rand()/(RAND_MAX+1.0);*/
   zz=as+(bl-as)*runif(0,1);
   if(bl<0.0)
     rz=(bl*bl-zz*zz)/2.0;
   else
     if(as>0.0)  rz=(as*as-zz*zz)/2.0;
       else   rz=-zz*zz/2.0;
/*   uu=rand()/(RAND_MAX+1.0);*/
   uu=runif(0,1);
   if(uu<=0.0)  vv=0.0;
     else   vv=log(uu);
   if(vv<=rz){
        flag=1;
        re=zz;
      }
   }
   return(re);
 }/* end */

double trunom(double MU, double iSD, double as, double bs)
{
    return MU+trunom_s((as-MU)*iSD,(bs-MU)*iSD)/iSD;
}

void rnorm_prec_constr(double *Q, double *L, double *u, 
double *A, double *ee, int *np, int p, int nc, double *x)
/*generate x|Ax=e where x~N(u,Q^-1) from RUE p.38 algorithm 2.6;
pQ--Precision matrix in vector by column; 
pL--Cholesky decomposition of Q with diagonal part;
mu--mean vector; pA--constrain matrix with each row a constrain;
pe--vector e used as pA%*%x=pe;
pn--dimension of Q;  pp--bandwith of Q; pnc--# of constraint=# of rows of A*/
{
     int i,j,k,n=*np,n2=(*np)*(*np);
     double *V, *W, *U;
     double *v, *c, *z;
/*     Rprintf("d*d=%d\n",n2);*/
     V=doubleArray(n2);
     W=doubleArray(n2);
     U=doubleArray(n2);
     v=doubleArray(n);
     c=doubleArray(n);
     z=doubleArray(n);

     for(i=0;i<n;i++)z[i]=rnorm(0,1);            
     band_choldc_c(Q, L, &n, &p);
     /*Cholesky decompposition of matrix Q to be stored in L.*/
     backward_sol_c(L, v, z, &n, &p);
     /*Use Cholesky decomposition to solve t(L)v=z.*/
     for(i=0;i<n;i++){
         v[i]+=u[i];
     /*v~N(u,t(L)-1L-1)=N(u,Q^-1))*/          
         /*Rprintf("%f,",v[i]);*/
     }
     band_cholsl_mat_bt_c(L, V, A, &n, &p, &nc);
     /*Use Cholesky decomposition to solve Qx=t(b) with available L.*/
     /*Rprintf("V=\n");
     for(i=0; i<n; i++){
     for(j=0; j<nc; j++){
        Rprintf("%f ",V[j*n+i]);                
     }
     Rprintf("\n");
     }
          
     Rprintf("W=\n");*/
     for(i=0; i<nc; i++){
     for(j=0; j<nc; j++){
        W[j*nc+i]=0.0;
        for(k=0; k<n; k++){
            W[j*nc+i]+=A[k*nc+i]*V[j*n+k];
        }
        /*Rprintf("%f ",W[j*nc+i]);                */
     }
     /*Rprintf("\n");*/
     }
     
     band_solbychol_bt_c(W, U, V, &nc, &p, &n); 
     /*Use Cholesky decomposition Q_pn^2(bandw=pp)=Lt(L) to solve Qx=t(b_pn2*pn) 
     with no L available.*/     
     /*Rprintf("U=\n");
     for(i=0; i<nc; i++){
     for(j=0; j<n; j++){
        Rprintf("%f ",U[j*nc+i]);                
     }
     Rprintf("\n");
     }
     */
     for(i=0; i<nc; i++){
     c[i]=-ee[i];
     for(j=0; j<n; j++)
     c[i]+=A[i+j*nc]*v[j];
     }
     for(i=0; i<n; i++){
        x[i]=v[i];    
        for(j=0; j<nc; j++)
            x[i]-=U[j+i*nc]*c[j];
     }
     
     free(V);
     free(W);
     free(U);
     free(v);
     free(c);
     free(z);

}

void rnorm_prec(double *Q, double *L,double *mu, int *pn, int *pp, double *x)
/*generate x~N(u,Q^-1) from RUE p.38 algorithm 2.6;
pQ--Precision matrix in vector by column;
pL--Cholesky decomposition of Q with diagonal part;
mu--mean vector; pA--constrain matrix with each row a constrain;
pe--vector e used as pA%*%x=pe;
pn--dimension of Q;  pp--bandwith of Q; pnc--# of constraint=# of rows of A*/
{
     int i;
     int n=*pn,p=*pp;
     double *z;

     z=doubleArray(n);

     for(i=0;i<n;i++)z[i]=rnorm(0,1);
     band_choldc_c(Q, L, &n, &p);
     /*Cholesky decompposition of matrix Q to be stored in L.*/
     backward_sol_c(L, x, z, &n, &p);
     /*Use Cholesky decomposition to solve t(L)v=z.*/
     for(i=0;i<n;i++){
         x[i]+=mu[i];
     /*v~N(u,t(L)-1L-1)=N(u,Q^-1))*/
         /*Rprintf("%f,",v[i]);*/
     }
     free(z);
}

