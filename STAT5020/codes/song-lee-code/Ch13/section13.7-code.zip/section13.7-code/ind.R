###################need careful revised when changing model

#variable name similar to C

IDD<-0
ROAL<-0

IDY<-matrix(c(
0,0,0,
1,0,0,
1,0,0,
0,0,0,
0,1,0,
0,1,0,
0,0,0,
0,0,1,
0,0,1
),ncol=NK,nrow=NY,byr=T)
SIDY<-IDY>0
lenly<-rowSums(IDY)

IDMU.lgc<-ind.y!=0
IDMU<-as.integer(IDMU.lgc)


IDA<-matrix(c(
1,1,
1,1,
1,1,
1,1,
1
),nrow=NY,ncol=NANA,byrow=T)
SIDA<-IDA>0
lenad<-rowSums(IDA)
######################### automatic below

ICE<-cbind(IDMU,IDA,IDY)
SICE<-ICE>0
lencv<-rowSums(ICE)

if(NM>=1){
IDBD<-array(1,dim=c(NM,ND))
IDB<-array(c(rep(0,NM),rep(1,NG)),dim=c(NM,NM+NG))
IDSE<-cbind(IDBD,IDB)
}

#for order categorical stuff
IDth<-matrix(F,nrow=NY,ncol=max(ind.y+1))
for(i in 1:NY){
  for(j in 1:max(ind.y+1)){
    if(ind.y[i]>3&j>2&j<(ind.y[i]))IDth[i,j]<-T
  }
}