
fun1<-function(x){
return(logit(x,0.25,18))
}

fun2<-function(x){
return(logit(x,0.25,18))
}

fun3<-function(x){
return(logit(x,0.25,18))
}

fun4<-function(x){
return(logit(x,0.25,18))
}


fun5<-function(x){
return(logit(x,0.25,18))
}

fun6<-function(x){
return(logit(x,0.25,18))
}

fun7<-function(x){
return(logit(x,0.25,18))
}

fun8<-function(x){
return(logit(x,0.25,18))
}

fun9<-function(x){
return(logit(x,0.25,18))
}


flist<-list(fun1,fun2,fun3,fun4,fun5,fun6,fun7,fun8,fun9)


