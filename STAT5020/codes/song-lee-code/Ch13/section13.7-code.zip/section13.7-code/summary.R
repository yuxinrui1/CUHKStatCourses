Ntest=46


mean(EmLY[1:Ntest,1]*sqrt(EmPSX[1:Ntest,1])/sqrt(EmPSX[1:Ntest,2]))
mean(EmLY[1:Ntest,2]*sqrt(EmPSX[1:Ntest,1])/sqrt(EmPSX[1:Ntest,3]))
mean(EmLY[1:Ntest,3]*sqrt(EmPSX[1:Ntest,4])/sqrt(EmPSX[1:Ntest,5]))
mean(EmLY[1:Ntest,4]*sqrt(EmPSX[1:Ntest,4])/sqrt(EmPSX[1:Ntest,6]))
mean(EmLY[1:Ntest,5]*sqrt(EmPSX[1:Ntest,7])/sqrt(EmPSX[1:Ntest,8]))
mean(EmLY[1:Ntest,6]*sqrt(EmPSX[1:Ntest,7])/sqrt(EmPSX[1:Ntest,9]))


colMeans(EmAD[1:Ntest,]/sqrt(EmPSX[1:Ntest,]))

mean(EmBI[1:Ntest,2]*sqrt(EmPSX[1:Ntest,4])/sqrt(EmPSX[1:Ntest,1]))
mean(EmBI[1:Ntest,3]*sqrt(EmPSX[1:Ntest,7])/sqrt(EmPSX[1:Ntest,1]))
mean(EmBI[1:Ntest,1]/sqrt(EmPSX[1:Ntest,1]))
