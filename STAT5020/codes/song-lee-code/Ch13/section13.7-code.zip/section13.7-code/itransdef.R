ifun1<-function(x){
return(-log(-x)/0.4)
}

ifun2<-function(x){
return(-log(-x)/0.5)
}

ifun3<-function(x){
return(-log(-x)/0.7)
}

ifun4<-function(x){
return(log(x)/0.4)
}

ifun5<-function(x){
return(log(x)/0.5)
}

ifun6<-function(x){
return(log(x)/0.5)
}

ifun7<-function(x){
return(qnorm(pt(x,df=10),sd=sqrt(2)))
}

ifun8<-function(x){
return(tan(x)/5+1)
}

ifun9<-function(x){
return(-log(-x)/0.4)
}

#iflist<-list(ifun6,ifun4,ifun5,ifun9,ifun7,ifun8,ifun3,ifun1,ifun2)
iflist<-list(ifun1,ifun2,ifun3,ifun4,ifun5,ifun6,ifun7,ifun8,ifun9)

