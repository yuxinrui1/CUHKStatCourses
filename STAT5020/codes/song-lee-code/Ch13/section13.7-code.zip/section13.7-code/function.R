############function#############

###############################these need careful revised when model changed 

#nonlinear functions in structure eqution
non.lin<-function(xi){
	nxi<-matrix(0,nrow=NG,ncol=N)
#  for(k in 1:NG.XI){
#    if(NSD.XI[k]==1)
#      nxi[(fst.LOC.XI[k]),]<-xi[k,]
#    if(NSD.XI[k]>1){
#      nxi[(fst.LOC.XI[k]):(fst.LOC.XI[k]+NSD.XI[k]-1),]<-
#      t(ns(xi[k,],knots=K[k,1:NKN.XI[k]],intercept=TRUE,Bou=B[k,]))
#    }    
#  }
	nxi<-xi
	return(nxi)
}

#1st derivative of nonlinear functions in structure eqution
fstd<-function(x,ng,nz){
	d<-matrix(0,ng,nz)
#  for(kx in 1:NG.XI){
#    if(NSD.XI[kx]==1)d[(fst.LOC.XI[kx]),kx]<-1
#    if(NSD.XI[kx]>=2)
#    d[(fst.LOC.XI[kx]):(fst.LOC.XI[kx]-1+NSD.XI[kx]),kx]<-
#		as.vector(ns(x[kx]+0.01,knots=K[kx,1:NKN.XI[kx]],intercept=TRUE,Bou=B[kx,])-
#		ns(x[kx],knots=K[kx,1:NKN.XI[kx]],intercept=TRUE,Bou=B[kx,]))/0.01
#		}
	d<-diag(1,ng)
	return(d)
}

#-2*complete log-likelihood if all y is continuous
log.likelihood<-function(y,ly,omega,fxi,bz,ispsx,piz,gam,bd,ispsd,ciphi){
	log.like1<-colSums((ispsx*(y-ly%*%omega))^2)
	
	log.like2<-0
	if(NM>=1){
    if(ND==0)temp<-ispsd*(piz%*%omega[1:NM,]-gam%*%fxi)
    if(ND>0)temp<-ispsd*(piz%*%omega[1:NM,]-gam%*%fxi-bd%*%bz)
    log.like2<-colSums(temp^2)
    }

	log.like3<-colSums((ciphi%*%omega[(NM+1):NK,])^2)

	return(log.like1+log.like2+log.like3)
}

#-2*complete log-likelihood if all y is from exponential family with continuous and binomial
log.likelihood.exp<-function(y,ycen,ly,omega,fxi,bz,ispsx,piz,gam,bd,ispsd,ciphi){

 	it<-(ind.y>=0)
	log.like1.1<-colSums((ispsx[it]*(y[it,]-ycen[it,]-ly[it,]%*%omega))^2)
 	it<-(ind.y<=(-1))	
	temp<-ycen[it,]+ly[it,]%*%omega
	log.like1.2<-(-2)*colSums(y[it,]*temp-log(1+exp(temp))*(-ind.y[it]))
	it<-(ind.y<0&ind.y>(-1))
	temp<-ycen[it,]+ly[it,]%*%omega
	log.like1.3<-(-2)*colSums(y[it,]*temp-exp(temp))
	
	log.like1<-log.like1.1+log.like1.2+log.like1.3

	log.like2<-0
	if(NM>=1){
    if(ND==0)temp<-ispsd*(piz%*%omega[1:NM,]-gam%*%fxi)
    if(ND>0)temp<-ispsd*(piz%*%omega[1:NM,]-gam%*%fxi-bd%*%bz)
    log.like2<-colSums(temp^2)
    }
	
	log.like3<-0
	if(NZ>=1)
	log.like3<-colSums((ciphi%*%omega[(NM+1):NK,])^2)

	return(log.like1+log.like2+log.like3)
}

#Generate the penalty matrix for P-spline
#d--matrix dimension, row=column
#ord--order of random walk penalty
Pen.Mat<-function(d,ord=2){
	P<-diag(-1,nrow=d-1,ncol=d)
  diag(P[,2:d])<-1
  if(ord==2)P<-P[2:(d-1),2:d]%*%P
  P<-crossprod(P)  
	return(P)
}      

#Generate the penalty matrix with local smoothing parameters for P-spline
#d--matrix dimension, row=column
#ord--order of random walk penalty
#loc--a vector of local smoothing parameters
Pen.Mat.loc<-function(d,loc,ord=2){
  if(ord==1){	
	P<-diag(-1,nrow=d-1,ncol=d)
  diag(P[,2:d])<-1
	}
  if(ord==2){
	P<-diag(1,nrow=d-2,ncol=d)
	diag(P[,-1])<-(-2)
	diag(P[,-(1:2)])<-1
	}
  P<-crossprod(P,loc*P)  
	return(P)
}      

