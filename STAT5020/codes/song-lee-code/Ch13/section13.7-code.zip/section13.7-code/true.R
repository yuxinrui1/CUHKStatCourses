###########pay attention to structure

LY<-matrix(c(
1,0,0,
0.8,0,0,
0.8,0,0,
0,1,0,
0,0.8,0,
0,0.8,0,
0,0,1,
0,0,0.8,
0,0,0.8
),ncol=NK,nrow=NY,byr=T)

MU<-rep(0,NY)

AD<-matrix(c(
1.0,1.0,
1.0,1.2,
1.2,1.2,
1.2,1.2,
1.2
),nrow=NY,ncol=NANA,byrow=T)

COE<-cbind(MU,AD,LY)

##########structure automatic, only change when true value is changed.


PSX<-rep(1,NY)

if(NZ>0){
PHI<-matrix(0.2,nrow=NZ,ncol=NZ)
diag(PHI)<-1
}

if(NM>=1){
PB<-array(rep(0.6,NM*NG),dim=c(NM,NG))
PI<-array(rep(0,NM*NM),dim=c(NM,NM))
BD<-array(rep(1.0,NM*ND),dim=c(NM,ND))
PSD<-rep(0.3,NM)

IB<-cbind(PI,PB)
BI<-cbind(BD,IB)

}

thres<-t(matrix(
c(
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0,
  -200,200,0,0,0,0
  ),nrow=max(ind.y)+1,ncol=NY))