Eomega[,]<-0
#initial values of parameters
if(nch>1){source(paste(c("init",CIR,".R"),collapse=""))}
if(nch==1){source("init1.R")}

##################USE TRUE TUE (latent variables)
if(0){
Omega<-TUE
if(NM>=1){
XIB[(ND+NM+1):NB,]<-Fxi<-non.lin(xi)
XIB[(ND+1):(ND+NM),]<-Omega[1:NM,]
}
}

#gen initial xi
if(1){
if(NZ>0){
xi<-t(mvrnorm(N,rep(0,NZ),Sigma=PHI))
Omega[((NM+1):NK),]<-xi
}
if(NM>=1){
XIB[(ND+NM+1):NB,]<-Fxi<-non.lin(xi)
if(ND>0){bdzs<-BD%*%XIB[1:ND,]}
muxi<-(PB%*%Fxi+bdzs)

j=1
while(j<=NM){
Omega[j,]<-rnorm(N,muxi[j,],sqrt(PSD[j]))
j=j+1
}
Omega[1:NM,]<-chol2inv(chol(diag(1,NM)-PI))%*%Omega[1:NM,]
XIB[(ND+1):(ND+NM),]<-Omega[1:NM,]
}
}
#initialize Y  (the underlying normal variable u=sum(beta*B(y)))

COV<-rbind(rep(1,N),AZ,Omega)

for(j in 1:NY){    
   crit<-(runif(N)<pmiss)
   mind.y[j,crit]<-as.integer(1)    #1 indicate missing
   obn.y[j]<-as.integer(N-sum(crit))#number of not missing
}

#initial  values of Y for ordered categorical, missing order categorical and binomial

for(j in 1:NY){
if(ind.y[j]==0)
Y[j,]<-BY1[j,,1:(NYK1[j])]%*%betay[j,1:(NYK1[j])]

#simulate initial value of underlying y of observed categorical variables
#trunomcall(int n, double *MU, double, *inv.sqrt.psx(vector),
#double *lower bound, double *upper bound)    
    if(ind.y[j]>0){
      crit<-(mind.y[j,]==0)
      Y[j,crit]<-.Call("trunomcall",
      (obn.y[j]),
      (COE[j,]%*%COV[,crit])[,,drop=TRUE],
      (rep(inv.sqrt.PSX[j],obn.y[j])),
      (thres[j,Z[fz.ay[j],crit]]),
      (thres[j,(Z[fz.ay[j],crit]+1)]))
    }
#simulate initial value of underlying y for missing categorical variables
#and missing y for continuous variables    
    if(ind.y[j]>0&obn.y[j]<N){    
      crit<-(mind.y[j,]==1)
      Y[j,crit]<-rnorm(N-obn.y[j],(COE[j,]%*%COV[,crit])[,,drop=TRUE],
        sqrt(PSX[j]))  
    }
#simulate initial value of Missing Binary variables.    
    if(ind.y[j]<0&obn.y[j]<N){
      crit<-(mind.y[j,]==1)
      temp<-exp((COE[j,]%*%COV[,crit])[,,drop=TRUE])
      if(ind.y[j]<=(-1))
		Y[j,crit]<-rbinom(N-obn.y[j],(-ind.y[j]),temp/(1+temp))
		if(ind.y[j]>(-1))
		Y[j,crit]<-rexp(N-obn.y[j],temp)
    }
 }





