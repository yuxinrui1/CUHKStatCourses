/*
#define dis 0.000001
#define dis2 0.00000000001
#define dis22 0.00000000002
#define LOWERB 0.0000000000000001
*/

#include<R.h>
#include<Rdefines.h>
#include<Rmath.h>
#include<Rinternals.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#include "vector.h"
#include "vector.c"
/*
#include "pnorm.c"
*/
#include "compare.c"
#include "mat_opt.c"
#include "trunom.c"


double marginal_mean_like();
void range_sol();
int sample_int();

SEXP MTM_RCD_BMCONST(SEXP rBY1, SEXP rBY1m, SEXP rBY12, SEXP rBY2, SEXP ripsx, 
SEXP rPEN, SEXP rtauy, SEXP rbeg1, SEXP rend1, SEXP rbeg2, SEXP rend2, 
SEXP rbanw, SEXP rn_sample, SEXP rd, 
SEXP rnmtm, SEXP rmo, SEXP rbetay, SEXP rmtis, SEXP rmu0, SEXP rmu0_ipsx,
SEXP rbeta0,SEXP rder_M)
{
    /*input parameters*/
     double *BY1, *BY1m, *BY12, *BY2, ipsx, *PEN, tauy, *mo, *betay, mtis;
     double *beta0;
     double mu0, mu0_ipsx;
     int *beg1, *end1, *beg2, *end2, banw, n, dim_bet, nmtm, d2, dnmtm;
/*     int der_M;*/
     int *der_M;
     
     double *new_betay;
     SEXP nbetay;
     
     /*MTM parameters*/

     double *cical_mt, *icala_mt, *ical_mt, *icalt_mt;
     double *betam_mt, *mop_mt, *betao_mt, *betan_mt, *betat_mt;
     double *mtbetan_mt, *mtbetao_mt, *mt_log_like, *prop_mt;
     double *tempv_mt, *tempv1_mt, *WKO_mt, *WKN_mt, *drec_mt;
     double *rn_mt, *ro_mt;
     
     double *mopp;
     double maxlog_n, maxlog_o;    
     double temp, temp1, temp2;
     double range_o[2], range_n[2], range_t[2];

     
     int i1, i2, i3, nmtm1, n_within, i_within, flag_mt=0;
     double *betawi_mt;
     
     BY1=NUMERIC_POINTER(rBY1);
     BY1m=NUMERIC_POINTER(rBY1m);     
     BY12=NUMERIC_POINTER(rBY12);
     BY2=NUMERIC_POINTER(rBY2);
     PEN=NUMERIC_POINTER(rPEN);     
     beg1=INTEGER_POINTER(rbeg1);
     end1=INTEGER_POINTER(rend1);
     beg2=INTEGER_POINTER(rbeg2);
     end2=INTEGER_POINTER(rend2);
     banw=INTEGER_VALUE(rbanw);          
     n=INTEGER_VALUE(rn_sample);     
     dim_bet=INTEGER_VALUE(rd);          
     nmtm=INTEGER_VALUE(rnmtm);                        
     ipsx=NUMERIC_VALUE(ripsx);               
     tauy=NUMERIC_VALUE(rtauy);    
     mo=NUMERIC_POINTER(rmo);                     
     betay=NUMERIC_POINTER(rbetay);                          
     mtis=NUMERIC_VALUE(rmtis);                    
     mu0=NUMERIC_VALUE(rmu0);
     mu0_ipsx=NUMERIC_VALUE(rmu0_ipsx);
     beta0=NUMERIC_POINTER(rbeta0);
     der_M=INTEGER_POINTER(rder_M);
/*     der_M=INTEGER_VALUE(rder_M);*/
/*    Rprintf("%d\n",n);
    Rprintf("%d\n",dim_bet);
    Rprintf("%d\n",banw);
    Rprintf("%d\n",nmtm);            
*/    

     d2=dim_bet*dim_bet; dnmtm=dim_bet*nmtm;
     n_within=der_M[1];
        
     cical_mt=doubleArray(d2);
/*     for(i1=1;i1<dim_bet;i1++){
     for(i2=1;i2<dim_bet;i2++)Rprintf("%f ",cical_mt[i1+dim_bet*i2]);
     Rprintf("\n");
     }
          Rprintf("\n");*/
     icala_mt=doubleArray(d2);
     ical_mt=doubleArray(d2);
     icalt_mt=doubleArray(d2);     
     betam_mt=doubleArray(dim_bet);
     mop_mt=doubleArray(n);
     betao_mt=doubleArray(dim_bet);
     betan_mt=doubleArray(dim_bet);
     betat_mt=doubleArray(dim_bet);     
     mtbetan_mt=doubleArray(dnmtm);
     mtbetao_mt=doubleArray(dnmtm);
     mt_log_like=doubleArray(nmtm);
     prop_mt=doubleArray(nmtm);
     tempv_mt=doubleArray(n);
     tempv1_mt=doubleArray(n);
     WKO_mt=doubleArray(nmtm);
     WKN_mt=doubleArray(nmtm);
     drec_mt=doubleArray(dim_bet);     
     rn_mt=doubleArray(nmtm);
     ro_mt=doubleArray(nmtm);
     betawi_mt=doubleArray(dim_bet);
     

     PROTECT(nbetay=NEW_NUMERIC(dim_bet+2));
 
     new_betay=NUMERIC_POINTER(nbetay);
     new_betay[0]=0.0;
     for(i1=1;i1<dim_bet+2;i1++)new_betay[i1]=0.0;
/*     Rprintf("1:dim_bet=%d\n",dim_bet);*/
     nmtm1=nmtm-1;
     
     if(ipsx!=1){
         for(i1=0;i1<n;i1++)mop_mt[i1]=mo[i1]*ipsx;
         mopp=mop_mt;
     }     
     else mopp=mo;
   
     GetRNGstate();       

    /*icala_mt store precision matrix in exp{}*/

    temp1=(n*ipsx+mu0_ipsx);
    
    temp2=ipsx*ipsx/temp1;
/*    Rprintf("2:=%d\n",dim_bet);*/

/*
Rprintf("1:BY2:\n");
for(i1=0;i1<n;i1++){
for(i2=0;i2<dim_bet;i2++)
Rprintf("%f ", BY2[i1+i2*n]);
Rprintf("\n");
}
*/

    if(der_M[0]==1){
        mul_Sv(BY2,beta0,n,beg2,end2,tempv_mt);
/*        Rprintf("tempv_mt:\n");
        for(i1=0;i1<n;i1++)Rprintf("%f\n",tempv_mt[i1]);*/
        MtDmDmM(BY2,tempv_mt,n,dim_bet,beg2,end2,icalt_mt);
    }
/*
Rprintf("icalt_mt:\n");
for(i1=0;i1<dim_bet;i1++){
for(i2=0;i2<dim_bet;i2++)
Rprintf("%f ", icalt_mt[i1+i2*dim_bet]);
Rprintf("\n");
}
*/    
    for(i1=0;i1<dim_bet;i1++){
         for(i2=0;i2<dim_bet;i2++){
             i3=i1+i2*dim_bet;
             temp=BY12[i3]*ipsx+PEN[i3]/tauy;
             ical_mt[i3]=temp;
             if(der_M[0]==1)ical_mt[i3]+=icalt_mt[i3];                
             icala_mt[i3]=temp-BY1m[i1]*BY1m[i2]*temp2;
         }        
    }

    
    mul_vS(BY1, mopp, n, dim_bet, beg1, end1, betam_mt);
    temp2=0.0;
    for(i1=0;i1<n;i1++)temp2+=mopp[i1];
    temp2*=ipsx;temp2-=mu0*mu0_ipsx;
    temp2*=ipsx/temp1;
    for(i1=0;i1<dim_bet;i1++){
        betam_mt[i1]*=ipsx;
        betam_mt[i1]-=BY1m[i1]*temp2;
    }

     for(i1=0;i1<dim_bet;i1++)tempv1_mt[i1]=tempv_mt[i1]=0.0;    


 
     for(i1=0;i1<dim_bet;i1++)betawi_mt[i1]=betay[i1];
     
for(i_within=0;i_within<n_within;i_within++){


     for(i1=0;i1<dim_bet;i1++)betao_mt[i1]=betawi_mt[i1];

     rnorm_prec_constr(ical_mt, cical_mt, tempv_mt, BY1m, tempv1_mt, &dim_bet, banw, 1, drec_mt);
/*
Rprintf("ical_mt:\n");
for(i1=0;i1<dim_bet;i1++){
for(i2=0;i2<dim_bet;i2++)
Rprintf("%f ", ical_mt[i1+i2*dim_bet]);
Rprintf("\n");
}

Rprintf("cical_mt:\n");
for(i1=0;i1<dim_bet;i1++){
for(i2=0;i2<dim_bet;i2++)
Rprintf("%f ", cical_mt[i1+i2*dim_bet]);
Rprintf("\n");
}
*/
     temp=0.0;
     for(i1=0;i1<dim_bet;i1++)temp+=drec_mt[i1]*drec_mt[i1];
     temp=sqrt(temp);
     for(i1=0;i1<dim_bet;i1++)drec_mt[i1]/=temp;

     range_sol(drec_mt,betao_mt,dim_bet,0.00000001,range_o);
/*
     for(i1=0;i1<dim_bet;i1++)Rprintf("%f, %f\n",drec_mt[i1],betao_mt[i1]);
*/
   
     for(i2=0;i2<nmtm;i2++){       

         rn_mt[i2]=trunom(0,mtis,range_o[0],range_o[1]);
/*  
         Rprintf("%f, %f, %f\n ", range_o[0], range_o[1], mtis);
         rn_mt[i2]=0.0;
*/
         for(i1=0;i1<dim_bet;i1++){
             betat_mt[i1]=mtbetan_mt[i1+i2*dim_bet]=betao_mt[i1]+rn_mt[i2]*drec_mt[i1];
         }
         range_sol(drec_mt,betat_mt,dim_bet,0.00000001,range_t);
         mt_log_like[i2]=marginal_mean_like(BY2,beg2,end2,banw,n,dim_bet,betat_mt,icala_mt,betam_mt); 
         prop_mt[i2]=-0.5*rn_mt[i2]*rn_mt[i2]*mtis*mtis-
             log(pnorm(range_t[1],0,1/mtis,1,0)-pnorm(range_t[0],0,1/mtis,1,0));                                        
             
     }


    
     maxlog_n=dmaxv(mt_log_like,nmtm);
     for(i2=0;i2<nmtm;i2++){
            WKN_mt[i2]=exp(mt_log_like[i2]-maxlog_n+prop_mt[i2]);
     }

     i2=sample_int(WKN_mt,nmtm);
     

     for(i1=0;i1<dim_bet;i1++){
         betan_mt[i1]=mtbetan_mt[i1+i2*dim_bet];
         mtbetao_mt[i1+(nmtm1)*dim_bet]=betao_mt[i1];
     }
     range_sol(drec_mt,betan_mt,dim_bet,0.00000001,range_n);
     ro_mt[nmtm1]=rn_mt[i2];
     mt_log_like[nmtm1]=marginal_mean_like(BY2,beg2,end2,banw,n,dim_bet,
         betao_mt,icala_mt,betam_mt);
     prop_mt[nmtm1]=-0.5*rn_mt[i2]*rn_mt[i2]*mtis*mtis-
         log(pnorm(range_o[1],0,1/mtis,1,0)-pnorm(range_o[0],0,1/mtis,1,0));       

     for(i2=0;i2<nmtm1;i2++){
         ro_mt[i2]=trunom(0,mtis,range_n[0],range_n[1]);
         for(i1=0;i1<dim_bet;i1++){
             mtbetao_mt[i1+i2*dim_bet]=betan_mt[i1]+ro_mt[i2]*drec_mt[i1];
         }
         range_sol(drec_mt,mtbetao_mt+i2*dim_bet,dim_bet,0.00000001,range_t);
         mt_log_like[i2]=marginal_mean_like(BY2,beg2,end2,banw,n,dim_bet,
             mtbetao_mt+i2*dim_bet,icala_mt,betam_mt); 
         prop_mt[i2]=-0.5*ro_mt[i2]*ro_mt[i2]*mtis*mtis-
             log(pnorm(range_t[1],0,1/mtis,1,0)-pnorm(range_t[0],0,1/mtis,1,0));              
     }
     maxlog_o=dmaxv(mt_log_like,nmtm);
     for(i2=0;i2<nmtm;i2++)WKO_mt[i2]=exp(mt_log_like[i2]-maxlog_o+prop_mt[i2]);

     temp1=0.0;for(i1=0;i1<nmtm;i1++)temp1+=WKN_mt[i1];
     temp2=0.0;for(i1=0;i1<nmtm;i1++)temp2+=WKO_mt[i1];
     if(runif(0,1)<exp(maxlog_n+log(temp1)-(maxlog_o+log(temp2)))){
         for(i2=0;i2<dim_bet;i2++)betawi_mt[i2]=betan_mt[i2];
         temp1=1/(n*ipsx+mu0_ipsx);
         temp=0.0;
         for(i1=0;i1<n;i1++)temp-=mopp[i1];
         for(i1=0;i1<dim_bet;i1++)temp+=betan_mt[i1]*BY1m[i1];
         temp*=ipsx;
         temp+=mu0*mu0_ipsx;
         temp*=temp1;
         new_betay[1]=rnorm(temp,sqrt(temp1));
         flag_mt=1;
     }

}     
     
     new_betay[0]=flag_mt;
     if(flag_mt==1)
         for(i2=0;i2<dim_bet;i2++)new_betay[i2+2]=betawi_mt[i2];
     
     PutRNGstate();  

     UNPROTECT(1);

     free(cical_mt);
     free(icala_mt);
     free(ical_mt);
     free(icalt_mt);
     free(betam_mt);
     free(mop_mt);
     free(betao_mt);
     free(betan_mt);
     free(betat_mt);     
     free(mtbetan_mt);
     free(mtbetao_mt);
     free(mt_log_like);
     free(prop_mt);
     free(tempv_mt);
     free(tempv1_mt);
     free(WKO_mt);
     free(WKN_mt);
     free(drec_mt);
     free(rn_mt);
     free(ro_mt);       
     free(betawi_mt);

   
     return nbetay;     
/*    return R_NilValue;*/
}


double marginal_mean_like(double *BY2,
int *beg, int *end, int banw, int n, int dim_bet,
double *betay,  double *icala_mt, double *betam_mt)
{
    int i1, i2;
    double temp3;
    double *tempv1_mt;
    
    tempv1_mt=doubleArray(n);
    
    mul_Sv(BY2,betay,n,beg,end,tempv1_mt);

    temp3=0.0;

    for(i1=0;i1<dim_bet;i1++)
        for(i2=0;i2<dim_bet;i2++)
            temp3+=betay[i1]*icala_mt[i1+i2*dim_bet]*betay[i2];
    temp3*=-0.5;
    for(i1=0;i1<dim_bet;i1++)temp3+=betay[i1]*betam_mt[i1];

    for(i1=0;i1<n;i1++)temp3+=log(tempv1_mt[i1]);
  
    free(tempv1_mt);
    return temp3;               
}

void range_sol(double *drec_mt, double *betao_mt, int dim_bet, double tol, double range[])
{
    double dre, ratio_bet;
    int i1;

    range[0]=-200000000;range[1]=200000000;
    for(i1=0;i1<dim_bet-1;i1++){
        dre=drec_mt[i1+1]-drec_mt[i1];
        ratio_bet=(betao_mt[i1]-betao_mt[i1+1])/dre;
        if(dre>0)range[0]=dmax2(range[0],ratio_bet);
        else range[1]=dmin2(range[1],ratio_bet);
/*        Rprintf("%f,%f,%f\n",betao_mt[i1]-betao_mt[i1+1],dre,ratio_bet);        */
    }
    range[0]+=tol;range[1]-=tol;      
}

int sample_int(double *v, int nmtm)
{
     int i2, i3;
     double *vs,temp;
     vs=doubleArray(nmtm);

     for(i2=nmtm-1;i2>=0;i2--){
         vs[i2]=v[i2];
         for(i3=i2-1;i3>=0;i3--)vs[i2]+=v[i3];
     }
     
     temp=runif(0,vs[nmtm-1]);
     i3=0;
     for(i2=nmtm-2;i2>=0;i2--){
         if(temp>vs[i2]){
             i3=i2+1;break;                    
         }
     }   
/*     for(i2=0;i2<nmtm;i2++)Rprintf("%f,%f\n",v[i2],vs[i2]);
     Rprintf("\n");
*/     
     free(vs);
     return i3;
}


void pno(double *x, double *mean, double *sd)
{
GetRNGstate();
*x=pnorm(0,*mean,*sd,1,0);

PutRNGstate();         
}



