TRANS=T				#Indicator of using transformation
platform="W"		#"W" indicate Windows, "U" indicate linux or unix in server

#R Libraries used
library(stats)
library(MASS)
library(splines)
if(!require(msm))
install.packages(pkgs="msm",repos="http://cran.r-project.org")
library(msm)
if(!require(MCMCpack))
install.packages(pkgs="MCMCpack",repos="http://cran.r-project.org")
library(MCMCpack)

source("function.R")	#contains self-define functions
source("def_con.R")		#define constants
set.seed(1)				#set random seed

#load dyanmic libraries complied from c codes.
if(platform=="W"){
dyn.load("cowles.dll")
dyn.load("mul.dll")
dyn.load("MTM_margmean_RCD_within.dll")
}
if(platform=="U"){
dyn.load("cowles.so")
dyn.load("mul.so")
dyn.load("MTM_margmean_RCD_within.so")
}

source("Prior.R")		#contains prior information
source("ind.R")			#identification constraints for SEM
source("def_rec.R")		#define some variables

#generate data if simualtion

#source("transdef.R")
#if(RD-1)
#for(CIR in 1:CTOT){
#source("true.R")
#source("gendata.R")
#print(CIR)
#}

set.seed(1)		#set random seed

Nrep=1:100		#number of replications
for(CIR in Nrep){

source("readdata.R")	#read data
source("initial.R")		#read initial values
#if no transformation, read data.
if(!TRANS){
	Y[,]<-matrix(scan(YFILE,skip=(CIR-1)*N,nlines=N),nrow=NY,ncol=N)
}

MTM.rep=as.integer(c(5,5,5,5,5,5,5,5,5))	#repeat the MTM samples in each Gibbs iteration

source("MCMC.R")	#MCMC iteractions


#mean of estimates
EmLY[CIR,]=apply(ELY[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))
EmMU[CIR,]=apply(EMU[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))
EmAD[CIR,]=apply(EAD[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))		
EmPSX[CIR,]=apply(EPSX[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))
EmPHI[CIR,]=apply(EPHI[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))
Embetay[CIR,,]=apply(Ebetay[1:(MCMAX1-N.burn),,,drop=F],FUN=mean,MAR=c(2,3))
Emtauy[CIR,]=apply(Etauy[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))
Emthres[CIR,]=apply(Ethres[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))

if(NM>=1){
EmPSD[CIR,]=apply(EPSD[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2))
EmBI[CIR,]=apply(EBI[1:(MCMAX1-N.burn),,drop=F],FUN=mean,MAR=c(2)) 
}

Emomega[CIR,,]<-Eomega/Nrec


#sd of estimates
SELY[CIR,]=apply(ELY[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))
SEMU[CIR,]=apply(EMU[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))
SEAD[CIR,]=apply(EAD[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))
SEPSX[CIR,]=apply(EPSX[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))
SEPHI[CIR,]=apply(EPHI[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))
SEbetay[CIR,,]=apply(Ebetay[1:(MCMAX1-N.burn),,,drop=F],FUN=sd,MAR=c(2,3))
SEtauy[CIR,]=apply(Etauy[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))
SEthres[CIR,]=apply(Ethres[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))

if(NM>=1){
SEPSD[CIR,]=apply(EPSD[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2))
SEBI[CIR,]=apply(EBI[1:(MCMAX1-N.burn),,drop=F],FUN=sd,MAR=c(2)) 
}

#save R workspace
save.image(paste(CIR,".RData",sep=""))

}#end of GIBs



