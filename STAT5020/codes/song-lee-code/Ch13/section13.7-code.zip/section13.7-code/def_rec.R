############################## Automatic done

OY<-Y<-array(0,dim=c(NY,N))		#observed Y
xi<-array(dim=c(NZ,N))			#xi, latent var
eta<-array(dim=c(NM,N))			#eta, dependent lat var
TUE<-Omega<-array(dim=c(NK,N))	#true latent in simulation
KNOTY<-matrix(0,nrow=NY,ncol=max(NYK))	#knots for spline for observed Y
BY1<-array(as.double(0),dim=c(NY,N,max(NYK1)))	#Basis of Y
BY12<-array(as.double(0),dim=c(NY,max(NYK1),max(NYK1)))	#qudratic product of BY1
BY2<-array(as.double(0),dim=c(NY,N,max(NYK1)))		#first derivative of BY1
bey1<-matrix(as.integer(0),nrow=N,ncol=NY)			#location of last nonzero elements of each row of BY1 
bby1<-matrix(as.integer(0),nrow=N,ncol=NY)			#location of first nonzero elements of each row of BY1 
bey2<-matrix(as.integer(0),nrow=N,ncol=NY)			#location of last nonzero elements of each row of BY2 
bby2<-matrix(as.integer(0),nrow=N,ncol=NY)			#location of first nonzero elements of each row of BY2 
hY<-numeric(NY)
PenY<-array(0,dim=c(NY,max(NYK1),max(NYK1)))		#penalty matrix of each Y
betaY<-array(0,dim=c(NY,max(NYK1)))					#b-spline coefficient of basis functions of each Y
betay0<-array(0,dim=c(NY,max(NYK1)))				#rough estimate of b-spline coefficient of basis functions of each Y for the proposal covariance matrix
if(NM>=1){
XIB<-array(dim=c(NB,N))			#all functions in struture euqtions
nlN.S<-array(0,dim=c(NG,N))		#nonlinear functions of xi in structure equations
}
BY1m<-array(as.double(0),dim=c(NY,max(NYK1)))	#column sum of By1

#order categorical Z
Z<-matrix(integer(0),nrow=NNN,ncol=N)
mind.y<-(matrix(as.integer(rep(0,NY*N)),nrow=NY,ncol=N))

#some variables in mtm
mt.betan<-mt.betao<-matrix(0,nrow=mtk,ncol=max(NYK1))
rn<-ro<-numeric(mtk)
mt.log.like<-numeric(mtk)
mt.boun<-matrix(0,nrow=2,ncol=mtk)

#number of elements in each parameter arrays, Lambda, AD, MU, BD, PI, PB
NMU<-sum(IDMU)
NLY<-sum(IDY)
NAD<-sum(IDA)
if(NM>=1){
NBD<-sum(IDBD)
NPIBI<-sum(IDB)
}
Nrec<-(MCMAX-N.burn)	#number of samples after burnin

#MCMC samples of parameters and latent variables
Eomega<-array(0,dim=c(NK,N))
EMU<-array(0,dim=c(Nrec,NMU))
ELY<-array(0,dim=c(Nrec,NLY))
EAD<-array(0,dim=c(Nrec,NAD))
EPSX<-array(0,dim=c(Nrec,NY))
EPHI<-array(0,dim=c(Nrec,(NZ*NZ)))
Ebetay<-array(0,dim=c(Nrec,NY,max(NYK1)))
Etauy<-array(0,dim=c(Nrec,NY))
Ethres<-array(0,dim=c(Nrec,NTS))
Edelta<-array(0,dim=c(Nrec,NY,max(NYKO)))

if(NM>=1){
EBI<-array(0,dim=c(Nrec,NBD+NPIBI))
EPSD<-EPI<-array(0,dim=c(Nrec,NM))
}

#mean of parameters and latent variables
Ebemu<-array(0,dim=c(Nrec,NY))

Emomega<-array(0,dim=c(CNUM,NK,N))
EmMU<-array(0,dim=c(CNUM,NMU))
EmLY<-array(0,dim=c(CNUM,NLY))
EmAD<-array(0,dim=c(CNUM,NAD))
EmPSX<-array(0,dim=c(CNUM,NY))
EmPHI<-array(0,dim=c(CNUM,(NZ*NZ)))
Embetay<-array(0,dim=c(CNUM,NY,max(NYK1)))
Emtauy<-array(0,dim=c(CNUM,NY))
Emthres<-array(0,dim=c(CNUM,NTS))
Emdelta<-array(0,dim=c(CNUM,NY,max(NYKO)))

if(NM>=1){
EmBI<-array(0,dim=c(CNUM,NBD+NPIBI))
EmPSD<-EPI<-array(0,dim=c(CNUM,NM))
}

Embemu<-numeric(NY)

#standard errors of parameters and latent variables

SEMU<-array(0,dim=c(CNUM,NMU))
SELY<-array(0,dim=c(CNUM,NLY))
SEAD<-array(0,dim=c(CNUM,NAD))
SEPSX<-array(0,dim=c(CNUM,NY))
SEPHI<-array(0,dim=c(CNUM,(NZ*NZ)))
SEbetay<-array(0,dim=c(CNUM,NY,max(NYK1)))
SEtauy<-array(0,dim=c(CNUM,NY))
SEthres<-array(0,dim=c(CNUM,NTS))

if(NM>=1){
SEBI<-array(0,dim=c(CNUM,NBD+NPIBI))
SEPSD<-EPI<-array(0,dim=c(CNUM,NM))
}

SEbemu<-numeric(NY)

#acceptance rates
AC.XI<-integer(N)
AC.XI.ab<-integer(N)
AC.betay.ab<-AC.betay<-integer(NY)
AC.th<-rep(0,NY)
AC.LY<-rep(0,NY)

MTM.I<-array(0,dim=c(NY,MCMAX,2))			#interval of MTM
MTM.D<-array(0,dim=c(NY,MCMAX,max(NYK1)))	#direction MTM
MTM.IND<-array(0,dim=c(NY,MCMAX))			#When a large move occur
#AC.b.IND<-array(0,dim=c(NY,MCMAX))			#when betay accpeted.

r.ind<-array(0,dim=c(NY,MCMAX,mtk))		#How large is a step.
r.ind.s<-array(0,dim=c(NY,MCMAX))			#How large is a step selected.

mo<-matrix(as.double(0),nrow=NY,ncol=N)		#mean on the right hand side of the model